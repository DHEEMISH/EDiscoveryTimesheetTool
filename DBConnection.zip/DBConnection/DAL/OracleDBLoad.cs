﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBOperation.DAL
{
    public class OracleDBLoad : IDBLoad
    {
        public int ExecuteNonQuery(string query)
        {
            throw new NotImplementedException();
        }

        public DataTable LoadDBTableSQL(string query)
        {
            throw new NotImplementedException();
        }

       public void GetWFConnectionString()
        {
          
        }
    }
}
