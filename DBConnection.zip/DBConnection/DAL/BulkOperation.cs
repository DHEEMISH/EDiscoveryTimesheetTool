﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace DBOperation.DAL
{
    class BulkOperation : IBulkOperations
    {

       // string conString = EncryptionUtility.Decrypt(ConfigurationManager.AppSettings[ConfigurationManager.AppSettings["Environment"] + "_ConnectionString"]);
        string ApplyActivityIdFilter = ConfigurationManager.AppSettings["ApplyActivityIdFilter"];
        //  Logger.WriteLogEntry("conString:" + conString, "conString", Enum.MessageType.Information);
        //Logger.WriteLogEntry("Run User Name:" + this.lblUserName.Text, "Run User Name", Enum.MessageType.Information);


        public static string GetEnvironemnt
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["Environment"];
            }
        }


        public string GetWFConnectionString()
        {
            //string m_ConnectionString = System.Configuration.ConfigurationManager.AppSettings[GetEnvironemnt + "eDiscoveryWFDB"];
            string m_ConnectionString = System.Configuration.ConfigurationManager.AppSettings[GetEnvironemnt + "eDiscoveryWFDB"];
            return m_ConnectionString;
        }
        public void BulkCopy(DataTable dataTable, string tableName)
        { 
            try
            {
                Logger.WriteLogEntry("Started Delete Table:" + tableName, "Started Delete Table", Enum.MessageType.Information);

                //deleteTableData(tableName);

                Logger.WriteLogEntry("Completed Delete Table:" + tableName, "Completed Delete Table", Enum.MessageType.Information);

                using (SqlConnection conn = new SqlConnection())
                {

                    conn.ConnectionString = GetWFConnectionString();

                    Logger.WriteLogEntry("DB ConnectionString:" + conn.ConnectionString, "DB ConnectionString", Enum.MessageType.Information);

                    // make sure to enable triggers
                    // more on triggers in next post
                    SqlBulkCopy bulkCopy =
                        new SqlBulkCopy
                        (
                        conn,
                        SqlBulkCopyOptions.TableLock |
                        SqlBulkCopyOptions.FireTriggers |
                        SqlBulkCopyOptions.UseInternalTransaction,
                        null
                        );

                    // set the destination table name
                    bulkCopy.DestinationTableName = tableName;
                    conn.Open();

                    // write the data in the "dataTable"
                    bulkCopy.WriteToServer(dataTable);
                    conn.Close();
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLogEntry("Error in BulkCopy", "Error in BulkCopy", ex, Enum.MessageType.Error);
            }

        }


    }
}
