﻿using DBOperation.DAL;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBOperation.DAL 
{
    public  class DBLoad : IDBLoad
    {
        public static string GetEnvironemnt
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["Environment"];
            }
        }


        public string GetWFConnectionString()
        {
            //string m_ConnectionString = System.Configuration.ConfigurationManager.AppSettings[GetEnvironemnt + "eDiscoveryWFDB"];
            string m_ConnectionString = System.Configuration.ConfigurationManager.AppSettings[GetEnvironemnt + "eDiscoveryWFDB"];
            return m_ConnectionString;
        }
        
    

    public DataTable LoadDBTableSQL(string query)
        {
          //  string conString = ConfigurationManager.AppSettings["Environment"] + "_eDiscoveryWFDB";
            // string ApplyActivityIdFilter = ConfigurationManager.AppSettings["ApplyActivityIdFilter"];


            DataTable dtTable = null;

            try
            {
                using (SqlConnection con = new SqlConnection())
                {
                    con.ConnectionString = GetWFConnectionString(); ;

                    SqlCommand cmd = new SqlCommand(query, con);
                    SqlDataAdapter oda = new SqlDataAdapter(cmd);
                    dtTable = new DataTable();
                    oda.Fill(dtTable);
                    con.Close();
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLogEntry("Error in LoadDBTableSQL", "Error in LoadDBTableSQL" + query, ex, Enum.MessageType.Error);
            }
            return dtTable;

        }


        public int ExecuteNonQuery(string query)
        {
            //string conString = ConfigurationManager.AppSettings["Environment"] + "_eDiscoveryWFDB";
            //string ApplyActivityIdFilter = ConfigurationManager.AppSettings["ApplyActivityIdFilter"];
            int recCount = 0;
            try
            {
                using (SqlConnection con = new SqlConnection())
                {
                    con.ConnectionString = GetWFConnectionString();
                    con.Open();
                    using (SqlCommand command = new SqlCommand(query, con))
                    {
                        recCount = command.ExecuteNonQuery();
                    }
                    con.Close();
                }
            }
            catch (SystemException ex)
            {
                Logger.WriteLogEntry("Error in ExecuteNonQuery", "Error in ExecuteNonQuery" + query, ex, Enum.MessageType.Error);
            }

            return recCount;
        }

     
    }
}
