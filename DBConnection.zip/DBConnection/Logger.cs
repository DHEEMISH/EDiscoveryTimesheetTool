﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace DBOperation
{
    public class Logger
    {

        #region Public Methods
        //public static String AppErrorLogFileName = "ErrorLog.txt";

        /// <summary>
        /// Log any messages from the Application
        /// </summary>
        /// <param name="message"></param>
        /// 

        private static string logPath = string.Empty;  // Backing store

        public static string LogPath
        {
            get
            {
                return logPath;
            }
            set
            {
                logPath = value;
            }
        }


        public static void WriteLogEntry(String messageText, String messageCaption, Enum.MessageType messageType)
        {

            if (isRequiredLog(messageType))
            {
                LogMessage(messageType.ToString() + " | " + "Caption: " + messageCaption + " | " + messageText);

                if (isRequiredDBLog())
                {
                    WriteToDB(null, messageType.ToString(), messageText, messageCaption, "AppUser");
                }
            }
        }

        /// <summary>
        /// Log any messages from the Application with exception
        /// </summary>
        /// <param name="messageText"></param>
        /// <param name="messageCaption"></param>
        /// <param name="messageExeption"></param>
        /// <param name="messageType"></param>
        public static void WriteLogEntry(String messageText, String messageCaption, Exception messageExeption, Enum.MessageType messageType)
        {
            if (isRequiredLog(messageType))
            {
                string exceptionMessge = GetExceptionMessage(messageExeption);
                LogMessage(messageType.ToString() + " | " + "Caption: " + messageCaption + " | " + messageText + " | " + exceptionMessge);

                if (isRequiredDBLog())
                {
                    WriteToDB(messageExeption, messageType.ToString(), messageText + exceptionMessge, messageCaption, "AppUser");
                }
            }
        }
        #endregion

        #region private methods
        private static bool isRequiredLog(Enum.MessageType messageType)
        {
            bool requiredLog = true; //By Default
            switch (GetLogLevel())
            {
                case "W":
                    requiredLog = (messageType == Enum.MessageType.Warning);
                    break;
                case "E":
                    requiredLog = (messageType == Enum.MessageType.Error);
                    break;
                case "I":
                    requiredLog = (messageType == Enum.MessageType.Information);
                    break;
                case "S":
                    requiredLog = (messageType == Enum.MessageType.Success);
                    break;
                case "A":
                    requiredLog = true;
                    break;
                case "N":
                    requiredLog = false;
                    break;
            }
            return requiredLog;
        }
        private static bool isRequiredDBLog()
        {
            bool requiredDBLog = false; //By Default
            //string requiredDBLogString = (string)(new System.Configuration.AppSettingsReader().GetValue("RequiredDBLog", typeof(string)));
            //requiredDBLog = requiredDBLogString == "Y";
            return requiredDBLog;
        }



        private static string GetLogLevel()
        {
            //string logLevel = System.Configuration.ConfigurationSettings.AppSettings["LogLevel"].ToString();
            //string logLevel = (string)(new System.Configuration.AppSettingsReader().GetValue("LogLevel", typeof(string)));
            //if (logLevel.Trim().Length == 0)
            //{
            //    logLevel = "A";
            //}
            //return logLevel.Trim().ToUpper();

            return "A";
        }
        #endregion

        //#region Update Log Health
        //private static void UpdateLogHealth()
        //{
        //    try
        //    {
        //        string folderPath = (string)(new System.Configuration.AppSettingsReader().GetValue("LogFolderPath", typeof(string)));
        //        string fileName = (string)(new System.Configuration.AppSettingsReader().GetValue("LogFileName", typeof(string)));
        //        string logSize = (string)(new System.Configuration.AppSettingsReader().GetValue("LogSize", typeof(string)));

        //        string oldFileName = folderPath + fileName;

        //        string fileNameWOExtn = Path.GetFileNameWithoutExtension(oldFileName);
        //        string backupFileName = folderPath + fileNameWOExtn + "_Backup_" + DateTime.Now.ToString("dd_MMM_yyyy") + "_H" + DateTime.Now.Hour.ToString() + "_M" + DateTime.Now.Minute.ToString() + "_S" + DateTime.Now.Second.ToString() + ".txt";

        //        foreach (FileData item in DirectoryEnumerator.EnumerateFiles(folderPath, "*.txt"))
        //        {
        //            if (item.Name == fileName)
        //            {
        //                if (item.Size / 1024 > HandleNulls.CheckNullLongReturnZero(logSize))
        //                {
        //                    File.Move(oldFileName, backupFileName);
        //                    File.Delete(oldFileName);
        //                }
        //            }
        //        }
        //    }

        //    catch (Exception ex)
        //    {
        //        Logger.WriteLogEntry("Error in UpdateLogHealth", "Error in Logger", ex, Enum.MessageType.Error);

        //    }
        //}
        //#endregion

        #region Log Errors in flat file

        private static void LogMessage(String pMessage)
        {
            bool Successful = false;

            //UpdateLogHealth();

            for (int idx = 0; idx < 10; idx++)
            {
                try
                {
                    // Log message to default log file.
                    //StreamWriter str = new StreamWriter
                    //                    (Functions_ConfigFileHandling.GetSettingsFolderLocation()
                    //    + (string)(new System.Configuration.AppSettingsReader().GetValue("LogFileName", typeof(string))), true);

                    StreamWriter str = new StreamWriter(LogPath, true);


                    str.AutoFlush = true;   // Wri9te text with no buffering
                    str.WriteLine(DateTime.Now.ToString() +
                    //Environment.NewLine
                    ":"
                        + "Message: " + pMessage);
                    str.Close();

                    Successful = true;
                }
                catch (Exception)
                {
                    //if we do that will bacome indefinite loop
                }

                if (Successful == true)     // Logging successful
                    break;
                else                        // Logging failed, retry in 100 milliseconds
                    Thread.Sleep(10);
            }
        }

        private static string GetExceptionMessage(Exception pExeption)
        {
            String str_inner = "";

            string innerExceptionMsg = "N/A";
            string innerExceptionStack = "N/A";
            string exceptionStackTrace = "N/A";
            string exceptionSource = "N/A";
            string exMessage = "N/A";

            try
            {
                if (pExeption.InnerException != null)
                {
                    innerExceptionMsg = pExeption.InnerException.Message;
                    innerExceptionStack = pExeption.InnerException.StackTrace;
                }

                if (pExeption.StackTrace != null)
                {
                    exceptionStackTrace = pExeption.StackTrace;
                }

                if (pExeption.Source != null)
                {
                    exceptionSource = pExeption.Source;
                }

                if (pExeption.Message != null)
                {
                    exMessage = pExeption.Message;
                }


                str_inner = Environment.NewLine + " | Exception Message: " + exMessage +
                            Environment.NewLine + " | Exception Source: " + exceptionSource +
                            Environment.NewLine + " | Inner Exception Msg: " + innerExceptionMsg +
                            Environment.NewLine + " | Inner Exception Stack: " + innerExceptionStack +
                            Environment.NewLine + " | Exception Stack Trace: " + exceptionStackTrace;
            }
            catch (Exception)
            {
                WriteLogEntry("Error Writing LogMessage", "Logger", Enum.MessageType.Error);
            }

            //LogMessage("Exception: " + pExeption.Message + Environment.NewLine +
            //    "Stack: " + str_inner);
            return str_inner;
        }
        #endregion

        #region Log Errors in DB table
        //DB Table Structure

        //CREATE TABLE [dbo].[test_tbl_logger](
        //    [logId] [int] IDENTITY(1,1) NOT NULL,
        //    [logDate] [datetime] NOT NULL,
        //    [pageName] [varchar](200) NULL,
        //    [method] [varchar](200) NULL,
        //    [line_Number] [int] NULL,
        //    [messageType] [varchar](200) NULL,
        //    [userMessage] [varchar](max) NULL,
        //    [userMessageCaption] [varchar](200) NULL,
        //    [exceptionMessage] [varchar](max) NULL,
        //    [createdUser] [varchar](20) NULL,
        //    [createdDate] [datetime] NOT NULL
        //)    

        /// <summary>
        /// Write Logs to SQL DB
        /// </summary>
        /// <param name="excep"></param>
        /// <param name="messageType"></param>
        /// <param name="userMessage"></param>
        /// <param name="messageCaption"></param>
        /// <param name="userName"></param>
        /// <returns></returns>
        private static bool WriteToDB(Exception excep, string messageType, string userMessage, string messageCaption, string userName)
        {
            SqlConnection cn = null;
            string insertLogString = @"INSERT INTO [test_tbl_logger]
                                       ([logDate]
                                       ,[pageName]
                                       ,[method]
                                       ,[line_Number]
                                       ,[messageType]
                                       ,[userMessage]
                                       ,[userMessageCaption]
                                       ,[exceptionMessage]
                                       ,[createdUser]
                                       ,[createdDate])
                                 VALUES
                                       (xxlogDatexx
                                       ,xxpageNamexx
                                       ,xxmethodxx
                                       ,xxline_Numberxx
                                       ,xxmessageTypexx
                                       ,xxuserMessagexx
                                       ,xxuserMessageCaptionxx
                                       ,xxexceptionMessagexx
                                       ,xxcreatedUserxx
                                       ,xxcreatedDatexx)";


            try
            {
                string ErrorMessgage = string.Empty;
                string pagename = string.Empty;
                string method = string.Empty;
                Int32 lineNumber = 0;
                if (excep != null)
                {
                    ErrorMessgage = excep.Message;

                    System.Diagnostics.StackTrace trace = new System.Diagnostics.StackTrace(excep, true);

                    pagename = trace.GetFrame((trace.FrameCount - 1)).GetFileName();

                    method = trace.GetFrame((trace.FrameCount - 1)).GetMethod().ToString();

                    lineNumber = trace.GetFrame((trace.FrameCount - 1)).GetFileLineNumber();

                }

                string dateFormat = (string)(new System.Configuration.AppSettingsReader().GetValue("DateFormat", typeof(string)));
                string connectionString = (string)(new System.Configuration.AppSettingsReader().GetValue("ConnectionString", typeof(string)));



                insertLogString = insertLogString.Replace("xxlogDatexx", "'" + DateTime.Now.ToString(dateFormat) + "'");
                insertLogString = insertLogString.Replace("xxpageNamexx", "'" + pagename + "'");
                insertLogString = insertLogString.Replace("xxmethodxx", "'" + method + "'");
                insertLogString = insertLogString.Replace("xxline_Numberxx", Convert.ToString(lineNumber));
                insertLogString = insertLogString.Replace("xxmessageTypexx", "'" + messageType + "'");
                insertLogString = insertLogString.Replace("xxuserMessagexx", "'" + userMessage + "'");
                insertLogString = insertLogString.Replace("xxuserMessageCaptionxx", "'" + messageCaption + "'");
                insertLogString = insertLogString.Replace("xxexceptionMessagexx", "'" + ErrorMessgage + "'");
                insertLogString = insertLogString.Replace("xxcreatedUserxx", "'" + userName + "'");
                insertLogString = insertLogString.Replace("xxcreatedDatexx", "'" + Convert.ToString(DateTime.Now) + "'");

                using (cn = new SqlConnection(connectionString))
                {
                    cn.Open();
                    SqlCommand cmd = new SqlCommand(insertLogString, cn);
                    int x = cmd.ExecuteNonQuery();
                    cn.Close();
                }
                return true;
            }
            catch (Exception)
            {
                cn.Close();
                //if we do that will bacome indefinite loop
                return false;
            }
        }
        #endregion

    }
}
