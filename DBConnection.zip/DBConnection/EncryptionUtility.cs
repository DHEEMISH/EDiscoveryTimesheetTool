﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace DBOperation
{
    class EncryptionUtility
    {
        static string password = "EDiscoveryEncryptionPassword";

        public static string Encrypt(string input)
        {
            if (input == null || input == String.Empty)
            {
                return "";
            }

            //get the unicode bytes for the input string
            UnicodeEncoding unicode = new UnicodeEncoding();
            byte[] inputBytes = unicode.GetBytes(input);

            //hash the password with MD5 in order to generate the strong key
            MD5CryptoServiceProvider crypto = new MD5CryptoServiceProvider();
            byte[] hashedPWBytes = crypto.ComputeHash(unicode.GetBytes(password));

            //Triple DES is the actual encryption algorithm being used.
            //It creates a default strong key, if we don't provide it with one.
            //In our case, we are providing it with the strong key generated from our password
            TripleDESCryptoServiceProvider cryptoProvider = new TripleDESCryptoServiceProvider();
            cryptoProvider.Key = hashedPWBytes;
            cryptoProvider.Mode = CipherMode.ECB;
            cryptoProvider.Padding = PaddingMode.PKCS7;

            //using our Triple DES algorithm, create the transformer object.
            //The transformer handles the actual encryption.
            ICryptoTransform transformer = cryptoProvider.CreateEncryptor();
            byte[] encryptedInput = transformer.TransformFinalBlock(inputBytes, 0, inputBytes.Length);


            return Convert.ToBase64String(encryptedInput);
        }


        public static string Decrypt(string input)
        {
            if (input == null || input == String.Empty)
            {
                return "";
            }

            //We are essentially doing the same thing as above.
            //Hashing the password with MD5 should generate the same strong key.
            MD5CryptoServiceProvider crypto = new MD5CryptoServiceProvider();
            UnicodeEncoding unicode = new UnicodeEncoding();
            byte[] hasedPWbytes = crypto.ComputeHash(unicode.GetBytes(password));

            TripleDESCryptoServiceProvider cryptoProvider = new TripleDESCryptoServiceProvider();
            cryptoProvider.Key = hasedPWbytes;
            cryptoProvider.Mode = CipherMode.ECB;
            cryptoProvider.Padding = PaddingMode.PKCS7;

            byte[] encryptedBytes = Convert.FromBase64String(input);

            //Here we generate a decryptor instead of an encryptor, which will decrypt the string
            ICryptoTransform decryptor = cryptoProvider.CreateDecryptor();
            byte[] decryptedBytes = decryptor.TransformFinalBlock(encryptedBytes, 0, encryptedBytes.Length);

            return unicode.GetString(decryptedBytes);
        }
    }
}
