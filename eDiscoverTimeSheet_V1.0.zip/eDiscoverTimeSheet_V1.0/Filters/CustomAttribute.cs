﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http.Controllers;
using System.Web.Mvc;

namespace eDiscoverTimeSheet_V1._0.Filters
{
    public class CustomAttribute : ActionFilterAttribute, IActionFilter
    {

        //public override void OnActionExecuting(ActionExecutingContext filterContext)
        //{
        //    OnActionExecuting(filterContext);
        //}


        public override void OnActionExecuted(ActionExecutedContext filterContext)
        {
            filterContext.HttpContext.Response.AddHeader("Access-Control-Allow-Origin", "*");
            filterContext.HttpContext.Response.AddHeader("Content-Type", "application/json");
            filterContext.HttpContext.Response.AddHeader("Access-Control-Allow-Credentials", "true");
            //OnActionExecuted(filterContext);
            
        }
    }
}  