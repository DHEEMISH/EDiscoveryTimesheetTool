﻿using eDiscoverTimeSheet_V1._0.Models.LoginModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Principal;
using System.Text;
using System.Threading;
using System.Web;
using System.Web.Http.Controllers;
using System.Web.Http.Filters;

namespace eDiscoverTimeSheet_V1._0.Filters
{
    public class AuthenticationAttributeFilter : AuthorizationFilterAttribute
    { 
        Login db = new Login();
        public override void OnAuthorization(HttpActionContext actionContext)
        {
         if(actionContext.Request.Headers.Authorization==null)
            {
                actionContext.Response = actionContext.Request.CreateResponse(HttpStatusCode.Unauthorized);
            }
            else
            {
                string AuthenticationToken = actionContext.Request.Headers.Authorization.Parameter;
                string DecodeAuth = Encoding.UTF8.GetString( Convert.FromBase64String(AuthenticationToken));
                string[] UserTokenArray = DecodeAuth.Split(':');
                string DomainLogin = UserTokenArray[0];
                string Pass = UserTokenArray[1];
               
               // string DisplayName = UserTokenArray[2];

           
               Dashboard Userdeatails =  Login.CheckLogin(DomainLogin,Convert.ToInt32(Pass));

               if( Userdeatails.DomainLogin ==DomainLogin && Userdeatails.Id==Convert.ToInt32(Pass))
                {
                    Thread.CurrentPrincipal = new GenericPrincipal(new GenericIdentity(DomainLogin), null);
                }
               else
                {
                    actionContext.Response = actionContext.Request.CreateResponse(HttpStatusCode.Unauthorized);
                }
                 
               
              
            }
        }
    }
}