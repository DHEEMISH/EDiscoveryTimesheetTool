﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using System.Reflection;
using Microsoft.Office.Interop;

namespace DBTableDataCompareTool
{
    class ExportToExcel
    {
        public static void ExportDataExcel(DataSet ds, string primaryTable, string fileName)
        {
            // Exporting the Dataset to an ExcelSpreadsheet.

            Microsoft.Office.Interop.Excel.Application application = null;
            Microsoft.Office.Interop.Excel.Workbook workBook = null;
            Microsoft.Office.Interop.Excel.Worksheet workSheet = null;


            try
            {

                Hashtable tableColumnMapping = new Hashtable();
                //columnNameHash = new ColumnNameHash();
                //application = new Microsoft.Office.Interop.Excel.ApplicationClass();
                application = new Microsoft.Office.Interop.Excel.Application();

                workBook = (Microsoft.Office.Interop.Excel.Workbook)(application.Workbooks.Add(Missing.Value));
                workSheet = (Microsoft.Office.Interop.Excel.Worksheet)workBook.ActiveSheet;

                ////May need to adjust the order of the columns at some point
                //Logger.WriteLogEntry("Begin column headers");
                for (int i = 0; i != ds.Tables.Count; i++)
                {
                    DataTable table = ds.Tables[i];
                    ProcessColumnHeaders(workSheet, table, tableColumnMapping);
                }
                //Logger.WriteLogEntry("End column headers");
                //Logger.WriteLogEntry("Begin rows");
                ProcessRows(workSheet, ds, primaryTable, tableColumnMapping);
                //Logger.WriteLogEntry("End rows");
                workBook.SaveAs(fileName, Microsoft.Office.Interop.Excel.XlFileFormat.xlWorkbookNormal, null, null, false, false, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlShared, false, false, null, null, null);
            }
            catch (Exception ex)
            {
                // Exception Handler 
                //System.Console.WriteLine(ex.StackTrace + " " + ex.Message);
                //Logger.WriteLogEntry("Error ExportToExcel", "Error in ExportToExcel", ex, Enum.MessageType.Error);

            }
            finally
            {
                // Need all following code to clean up and extingush all references!!!
                workBook.Close(null, null, null);
                application.Workbooks.Close();
                application.Quit();
                System.Runtime.InteropServices.Marshal.ReleaseComObject(application);
                System.Runtime.InteropServices.Marshal.ReleaseComObject(workSheet);
                System.Runtime.InteropServices.Marshal.ReleaseComObject(workBook);
                workSheet = null;
                workBook = null;
                application = null;
                GC.Collect(); // force final cleanup!
            }
        }


        private static void ProcessColumnHeaders(Microsoft.Office.Interop.Excel.Worksheet workSheet, DataTable table, Hashtable tableColumnMapping)
        {
            //Hashtable mapHash = (Hashtable) columnNameHash.NameHash("BROKER_MAPPING");
            foreach (DataColumn column in table.Columns)
            {
                string[] mapping = new string[4];
                mapping[0] = table.TableName;
                mapping[1] = column.ColumnName;
                //if (mapHash.Contains(column.ColumnName)){
                //    mapping[2] = (string) mapHash[column.ColumnName];
                //} else {
                mapping[2] = column.ColumnName;
                //}
                if (!tableColumnMapping.Contains(column.ColumnName))
                {
                    mapping[3] = tableColumnMapping.Count.ToString();
                    tableColumnMapping.Add(column.ColumnName, mapping);
                    workSheet.Cells[1, tableColumnMapping.Count] = mapping[2];
                }

                try
                {
                    workSheet.Name = table.TableName;
                }
                catch (Exception ex)
                {
                    Logger.WriteLogEntry("Error Rename Sheet", "Error in ExportToExcel", ex, Enum.MessageType.Error);
                }
            }
        }

        private static void ProcessRows(Microsoft.Office.Interop.Excel.Worksheet workSheet, DataSet ds, string primaryTable, Hashtable tableColumnMapping)
        {
            //Assumes the primary key is the same in all tables
            DataTable table = ds.Tables[primaryTable.ToString()];
            object[] key = new object[table.PrimaryKey.Length];

            object[,] data = new string[table.Rows.Count, tableColumnMapping.Count];
            int primaryRowCount = 0;
            foreach (DataRow row in table.Rows)
            {
                for (int i = 0; i != table.PrimaryKey.Length; i++)
                {
                    DataColumn column = (DataColumn)table.PrimaryKey.GetValue(i);
                    key[i] = row[column.ColumnName];
                }
                foreach (DataColumn column in table.Columns)
                {
                    string[] map = (string[])tableColumnMapping[column.ColumnName];
                    data[primaryRowCount, System.Convert.ToInt32(map[3])] = row[column].ToString();
                }
                foreach (DataTable secondaryTable in ds.Tables)
                {
                    if (table.TableName != secondaryTable.TableName)
                    {
                        DataRow secondaryRow = secondaryTable.Rows.Find(key);
                        foreach (DataColumn column in secondaryTable.Columns)
                        {
                            string[] map = (string[])tableColumnMapping[column.ColumnName];
                            data[primaryRowCount, System.Convert.ToInt32(map[3])] = secondaryRow[column].ToString();
                        }
                    }
                }
                primaryRowCount++;
            }

            for (int i = 0; i != table.Rows.Count; i++)
            {
                for (int j = 0; j != tableColumnMapping.Count; j++)
                {
                    try
                    {
                        workSheet.Cells[i + 2, j + 1] = data[i, j].ToString();
                    }
                    catch (Exception ex)
                    {
                        //System.Console.WriteLine(ex.Message + " " + ex.StackTrace );
                        Logger.WriteLogEntry("Error ProcessRows", "Error in ExportToExcel", ex, Enum.MessageType.Error);

                    }
                }
            }


        }

    }
}
