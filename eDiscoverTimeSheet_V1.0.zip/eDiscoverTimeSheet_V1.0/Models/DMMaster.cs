﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace eDiscoverTimeSheet_V1._0.Models
{
    //public class DMMaster
    //{
  
    //    public DMMasterPage()
    //    {
    //        InitializeComponent();
    //    }

    //    private void btnClose_Click(object sender, EventArgs e)
    //    {
    //        this.Close();
    //    }

    //    private void DMMasterPage_Load(object sender, EventArgs e)
    //    {


    //        Logger.LogPath = ConfigurationManager.AppSettings["LogFilePath"] + "/" + ConfigurationManager.AppSettings["LogFileName"] + "_" + DateTime.Now.Month.ToString() + "_" + DateTime.Now.Day.ToString() + "_" + DateTime.Now.Year.ToString() + "_" + DateTime.Now.Hour.ToString() + "_" + DateTime.Now.Minute.ToString() + "_" + DateTime.Now.Second.ToString() + ".log";

    //        Logger.WriteLogEntry("Welcome to Legal IT eDiscovery Timesheet Tool v.01!!!", "Welcome", Enum.MessageType.Information);


    //        string userName = System.Security.Principal.WindowsIdentity.GetCurrent().Name;
    //        this.lblPPMUserName.Text = userName;
    //        this.lblLoginUser.Text = userName;
    //        string[] parts = userName.Split(new char[] { '\\' });
    //        userName = parts[1];
    //        if (userName.Length > 20)
    //        {
    //            userName = userName.Substring(userName.Length - 20);
    //        }

    //        this.lblUserName.Text = userName;
    //        userName = this.lblUserName.Text;

    //        conString = EncryptionUtility.Decrypt(ConfigurationManager.AppSettings[ConfigurationManager.AppSettings["Environment"] + "_ConnectionString"]);
    //        ApplyActivityIdFilter = ConfigurationManager.AppSettings["ApplyActivityIdFilter"];
    //        Logger.WriteLogEntry("conString:" + conString, "conString", Enum.MessageType.Information);
    //        Logger.WriteLogEntry("Run User Name:" + this.lblUserName.Text, "Run User Name", Enum.MessageType.Information);

    //        this.txtExportPath.Text = ConfigurationManager.AppSettings["ExportFilePath"];

    //        this.LoadActivityId();
    //        this.LoadWeekEnding();
    //        //this.LoadResultGrid();
    //        //this.rdoWeeklyView.Checked = true;
    //        this.chkOveride.Enabled = this.IsSuperUser();
    //        this.chkOveride_CheckedChanged(null, null);
    //        this.rdoMonthlyView_CheckedChanged(null, null);

    //        if (ConfigurationManager.AppSettings["Environment"] == "UAT")
    //        {
    //            this.lblRegion.Text = this.isSuperUser ? "UAT-ADMIN" : "UAT-USER";
    //        }
    //        if (ConfigurationManager.AppSettings["Environment"] == "PROD")
    //        {
    //            this.lblRegion.Text = this.isSuperUser ? "PRODUCTION-ADMIN" : "PRODUCTION-USER";
    //        }

    //        this.btnGenerateInvoice.Enabled = (rdoMonthlyView.Checked && this.isSuperUser);
    //        this.btnRetriveAllUser.Enabled = (rdoMonthlyView.Checked && this.isSuperUser);
    //        this.btnRetriveAll.Enabled = (rdoMonthlyView.Checked && this.isSuperUser);

    //        this.llblAddActivity.Enabled = this.isSuperUser;

    //        this.rdoQuerterly_CheckedChanged(null, null);
    //        this.rdoSemiAnnual_CheckedChanged(null, null);

    //        this.cboQuarter.SelectedIndex = 0;
    //        this.cboSemiAnnual.SelectedIndex = 0;

    //        isPageLoadCompleted = true;
    //        this.LoadResultGrid();
    //    }
    //    bool isPageLoadCompleted = false;
    //    string conString = string.Empty;
    //    string ApplyActivityIdFilter = string.Empty;
    //    private void btnImportScreen_Click(object sender, EventArgs e)
    //    {
    //        try
    //        {
    //            AddRecord();
    //        }
    //        catch (Exception ex)
    //        {
    //            Logger.WriteLogEntry("Error in btnImport_Click", "Error in btnImport_Click", ex, Enum.MessageType.Error);
    //        }
    //    }

    //    private void BulkCopy(DataTable dataTable, string tableName)
    //    {
    //        try
    //        {
    //            Logger.WriteLogEntry("Started Delete Table:" + tableName, "Started Delete Table", Enum.MessageType.Information);

    //            //deleteTableData(tableName);

    //            Logger.WriteLogEntry("Completed Delete Table:" + tableName, "Completed Delete Table", Enum.MessageType.Information);

    //            using (SqlConnection conn = new SqlConnection())
    //            {

    //                conn.ConnectionString = conString;

    //                Logger.WriteLogEntry("DB ConnectionString:" + conn.ConnectionString, "DB ConnectionString", Enum.MessageType.Information);

    //                // make sure to enable triggers
    //                // more on triggers in next post
    //                SqlBulkCopy bulkCopy =
    //                    new SqlBulkCopy
    //                    (
    //                    conn,
    //                    SqlBulkCopyOptions.TableLock |
    //                    SqlBulkCopyOptions.FireTriggers |
    //                    SqlBulkCopyOptions.UseInternalTransaction,
    //                    null
    //                    );

    //                // set the destination table name
    //                bulkCopy.DestinationTableName = tableName;
    //                conn.Open();

    //                // write the data in the "dataTable"
    //                bulkCopy.WriteToServer(dataTable);
    //                conn.Close();
    //            }
    //        }
    //        catch (Exception ex)
    //        {
    //            Logger.WriteLogEntry("Error in BulkCopy", "Error in BulkCopy", ex, Enum.MessageType.Error);
    //        }

    //    }


    //    private int ExecuteNonQuery(string query)
    //    {
    //        int recCount = 0;
    //        try
    //        {
    //            using (SqlConnection con = new SqlConnection())
    //            {
    //                con.ConnectionString = conString;
    //                con.Open();
    //                using (SqlCommand command = new SqlCommand(query, con))
    //                {
    //                    recCount = command.ExecuteNonQuery();
    //                }
    //                con.Close();
    //            }
    //        }
    //        catch (SystemException ex)
    //        {
    //            Logger.WriteLogEntry("Error in ExecuteNonQuery", "Error in ExecuteNonQuery" + query, ex, Enum.MessageType.Error);
    //        }

    //        return recCount;
    //    }

    //    private DataTable LoadDBTableSQL(string query)
    //    {
    //        DataTable dtTable = null;

    //        try
    //        {
    //            using (SqlConnection con = new SqlConnection())
    //            {
    //                con.ConnectionString = conString;

    //                SqlCommand cmd = new SqlCommand(query, con);
    //                SqlDataAdapter oda = new SqlDataAdapter(cmd);
    //                dtTable = new DataTable();
    //                oda.Fill(dtTable);
    //                con.Close();
    //            }
    //        }
    //        catch (Exception ex)
    //        {
    //            Logger.WriteLogEntry("Error in LoadDBTableSQL", "Error in LoadDBTableSQL" + query, ex, Enum.MessageType.Error);
    //        }
    //        return dtTable;

    //    }



    //    private void btnWorkArea_Click(object sender, EventArgs e)
    //    {
    //        WorkArea obj = new WorkArea();
    //        obj.Show();

    //    }



    //    DateTime dtWeekEndingGlobal = DateTime.Now;

    //    private void LoadWeekEnding()
    //    {
    //        try
    //        {
    //            double start = 7 - (int)DateTime.Now.DayOfWeek;
    //            DateTime dtWeekEnding = DateTime.Now.AddDays(start);

    //            dtWeekEndingGlobal = dtWeekEnding;
    //            SetWeekEndingFormat();
    //        }
    //        catch (Exception ex)
    //        {
    //            Logger.WriteLogEntry("Error in LoadWeekEnding", "Error in LoadWeekEnding", ex, Enum.MessageType.Error);
    //        }

    //    }

    //    private void SetWeekEndingFormat()
    //    {
    //        try
    //        {
    //            this.lblWeekending.Text = dtWeekEndingGlobal.DayOfWeek.ToString().Substring(0, 3) + "," + dtWeekEndingGlobal.Month + "/" + dtWeekEndingGlobal.Day + "/" + dtWeekEndingGlobal.Year;
    //            lblDay7.Text = dtWeekEndingGlobal.AddDays(0).DayOfWeek.ToString().Substring(0, 3) + "," + dtWeekEndingGlobal.AddDays(0).Month.ToString() + "/" + dtWeekEndingGlobal.AddDays(0).Day.ToString();
    //            lblDay6.Text = dtWeekEndingGlobal.AddDays(-1).DayOfWeek.ToString().Substring(0, 3) + "," + dtWeekEndingGlobal.AddDays(-1).Month.ToString() + "/" + dtWeekEndingGlobal.AddDays(-1).Day.ToString();
    //            lblDay5.Text = dtWeekEndingGlobal.AddDays(-2).DayOfWeek.ToString().Substring(0, 3) + "," + dtWeekEndingGlobal.AddDays(-2).Month.ToString() + "/" + dtWeekEndingGlobal.AddDays(-2).Day.ToString();
    //            lblDay4.Text = dtWeekEndingGlobal.AddDays(-3).DayOfWeek.ToString().Substring(0, 3) + "," + dtWeekEndingGlobal.AddDays(-3).Month.ToString() + "/" + dtWeekEndingGlobal.AddDays(-3).Day.ToString();
    //            lblDay3.Text = dtWeekEndingGlobal.AddDays(-4).DayOfWeek.ToString().Substring(0, 3) + "," + dtWeekEndingGlobal.AddDays(-4).Month.ToString() + "/" + dtWeekEndingGlobal.AddDays(-4).Day.ToString();
    //            lblDay2.Text = dtWeekEndingGlobal.AddDays(-5).DayOfWeek.ToString().Substring(0, 3) + "," + dtWeekEndingGlobal.AddDays(-5).Month.ToString() + "/" + dtWeekEndingGlobal.AddDays(-5).Day.ToString();
    //            lblDay1.Text = dtWeekEndingGlobal.AddDays(-6).DayOfWeek.ToString().Substring(0, 3) + "," + dtWeekEndingGlobal.AddDays(-6).Month.ToString() + "/" + dtWeekEndingGlobal.AddDays(-6).Day.ToString();
    //        }
    //        catch (Exception ex)
    //        {
    //            Logger.WriteLogEntry("Error in SetWeekEndingFormat", "Error in SetWeekEndingFormat", ex, Enum.MessageType.Error);
    //        }

    //    }


    //    private void llblNext_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
    //    {
    //        try
    //        {
    //            dtWeekEndingGlobal = dtWeekEndingGlobal.AddDays(7);
    //            SetWeekEndingFormat();
    //            LoadResultGrid();
    //            LoadActivityId();
    //        }
    //        catch (Exception ex)
    //        {
    //            Logger.WriteLogEntry("Error in llblNext_LinkClicked", "Error in llblNext_LinkClicked", ex, Enum.MessageType.Error);
    //        }

    //    }

    //    private void llblPrevious_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
    //    {
    //        try
    //        {
    //            dtWeekEndingGlobal = dtWeekEndingGlobal.AddDays(-7);
    //            SetWeekEndingFormat();
    //            LoadResultGrid();
    //            LoadActivityId();
    //        }
    //        catch (Exception ex)
    //        {
    //            Logger.WriteLogEntry("Error in llblPrevious_LinkClicked", "Error in llblPrevious_LinkClicked", ex, Enum.MessageType.Error);
    //        }

    //    }

    //    private void LoadResultGrid()
    //    {
    //        try
    //        {
    //            if (isPageLoadCompleted)
    //            {
    //                //this.gridResult.DataSource = this.LoadDBTableSQL(@"SELECT CaseID as 'Activity Id', Day1 AS '" + this.lblDay1.Text.Replace(",", " | ") + "', Day2 AS '" + this.lblDay2.Text.Replace(",", " | ") + "', Day3 AS '" + this.lblDay3.Text.Replace(",", " | ") + "',Day4 AS '" + this.lblDay4.Text.Replace(",", " | ") + "',Day5 AS '" + this.lblDay5.Text.Replace(",", " | ") + "',Day6 AS '" + this.lblDay6.Text.Replace(",", " | ") + "',Day7 AS '" + this.lblDay7.Text.Replace(",", " | ") + "', CreatedBy as 'LastUpdateBy', CreatedDate as 'LastUpdateDate' from  T_EDIS_TIMESHEET where WeekEnd_ID = " + this.dtWeekEndingGlobal.Month.ToString("D2") + this.dtWeekEndingGlobal.Day.ToString("D2") + this.dtWeekEndingGlobal.Year.ToString("D4") + " and UserName = '" + this.lblPPMUserName.Text + "'");
    //                this.gridResult.DataSource = PopulateWeeklyTotal();
    //                DataGridViewColumn column1 = this.gridResult.Columns["LastUpdateBy"];
    //                column1.Width = 185;
    //                DataGridViewColumn column = this.gridResult.Columns["LastUpdateDate"];
    //                column.Width = 145;
    //                this.ClearTextBox();
    //            }

    //        }
    //        catch (Exception ex)
    //        {
    //            Logger.WriteLogEntry("Error in LoadResultGrid", "Error in LoadResultGrid", ex, Enum.MessageType.Error);
    //        }

    //    }

    //    private DataTable PopulateWeeklyTotal()
    //    {
    //        DataTable dtTable = null;
    //        try
    //        {
    //            dtTable = this.LoadDBTableSQL(@"SELECT CaseID as 'Activity Id', Day1 AS '" + this.lblDay1.Text.Replace(",", " | ") + "', Day2 AS '" + this.lblDay2.Text.Replace(",", " | ") + "', Day3 AS '" + this.lblDay3.Text.Replace(",", " | ") + "',Day4 AS '" + this.lblDay4.Text.Replace(",", " | ") + "',Day5 AS '" + this.lblDay5.Text.Replace(",", " | ") + "',Day6 AS '" + this.lblDay6.Text.Replace(",", " | ") + "',Day7 AS '" + this.lblDay7.Text.Replace(",", " | ") + "', (Day1 + Day2 + Day3 + Day4 + Day5 + Day6 + Day7) as 'Total', CreatedBy as 'LastUpdateBy', CreatedDate as 'LastUpdateDate' from  T_EDIS_TIMESHEET where WeekEnd_ID = " + this.dtWeekEndingGlobal.Month.ToString("D2") + this.dtWeekEndingGlobal.Day.ToString("D2") + this.dtWeekEndingGlobal.Year.ToString("D4") + " and UserName = '" + this.lblPPMUserName.Text + "'");
    //            if (dtTable.Rows.Count > 0)
    //            {
    //                DataRow dr = null;
    //                dr = dtTable.NewRow();
    //                double day1 = 0;
    //                double day2 = 0;
    //                double day3 = 0;
    //                double day4 = 0;
    //                double day5 = 0;
    //                double day6 = 0;
    //                double day7 = 0;
    //                double Total = 0;
    //                for (int i = 0; i < dtTable.Rows.Count; i++)
    //                {
    //                    day1 = day1 + Convert.ToDouble(dtTable.Rows[i][1]);
    //                    day2 = day2 + Convert.ToDouble(dtTable.Rows[i][2]);
    //                    day3 = day3 + Convert.ToDouble(dtTable.Rows[i][3]);
    //                    day4 = day4 + Convert.ToDouble(dtTable.Rows[i][4]);
    //                    day5 = day5 + Convert.ToDouble(dtTable.Rows[i][5]);
    //                    day6 = day6 + Convert.ToDouble(dtTable.Rows[i][6]);
    //                    day7 = day7 + Convert.ToDouble(dtTable.Rows[i][7]);
    //                    Total = Total + Convert.ToDouble(dtTable.Rows[i][8]);
    //                }
    //                dr[0] = "Total:";
    //                dr[1] = day1;
    //                dr[2] = day2;
    //                dr[3] = day3;
    //                dr[4] = day4;
    //                dr[5] = day5;
    //                dr[6] = day6;
    //                dr[7] = day7;
    //                dr[8] = Total;
    //                dr[9] = "eDis-Timesheet Tool";
    //                dr[10] = DateTime.Now;

    //                dtTable.Rows.Add(dr);
    //                dtTable.AcceptChanges();
    //            }
    //        }
    //        catch (Exception ex)
    //        {
    //            Logger.WriteLogEntry("Error in PopulateWeeklyTotal", "Error in PopulateWeeklyTotal", ex, Enum.MessageType.Error);
    //        }

    //        return dtTable;

    //    }


    //    private void ClearTextBox()
    //    {
    //        try
    //        {
    //            this.txtDay1.Text = "0.00";
    //            this.txtDay2.Text = "0.00";
    //            this.txtDay3.Text = "0.00";
    //            this.txtDay4.Text = "0.00";
    //            this.txtDay5.Text = "0.00";
    //            this.txtDay6.Text = "0.00";
    //            this.txtDay7.Text = "0.00";
    //            this.cboActivityID.SelectedIndex = 0;
    //            this.UpdateTotal();
    //        }
    //        catch (Exception ex)
    //        {
    //            Logger.WriteLogEntry("Error in ClearTextBox", "Error in ClearTextBox", ex, Enum.MessageType.Error);
    //        }

    //    }


    //    private void AddRecord()
    //    {
    //        try
    //        {
    //            if (this.cboActivityID.Text.Trim().Length > 0)
    //            {
    //                string query = string.Empty;

    //                query = "Exec speDiscTimeSheet @weekendDate = IP_WEEKENDDATE, @weekendId = IPWEEKENDID, @caseId = IPCASEID, @userName = IPUSERNAME, @day1 = IPDAY1 , @day2 = IPDAY2, @day3 = IPDAY3, @day4 = IPDAY4, @day5 = IPDAY5, @day6 = IPDAY6, @day7 = IPDAY7, @CreatedBy = IPCREATEBY";
    //                query = query.Replace("IP_WEEKENDDATE", "'" + this.dtWeekEndingGlobal.ToShortDateString() + "'");
    //                query = query.Replace("IPWEEKENDID", "'" + this.dtWeekEndingGlobal.Month.ToString("D2") + this.dtWeekEndingGlobal.Day.ToString("D2") + this.dtWeekEndingGlobal.Year.ToString("D4") + "'");
    //                query = query.Replace("IPCASEID", "'" + this.cboActivityID.Text + "'");
    //                query = query.Replace("IPUSERNAME", "'" + this.lblPPMUserName.Text + "'");
    //                query = query.Replace("IPDAY1", this.txtDay1.Text.Trim().Length == 0 ? "0" : this.txtDay1.Text);
    //                query = query.Replace("IPDAY2", this.txtDay2.Text.Trim().Length == 0 ? "0" : this.txtDay2.Text);
    //                query = query.Replace("IPDAY3", this.txtDay3.Text.Trim().Length == 0 ? "0" : this.txtDay3.Text);
    //                query = query.Replace("IPDAY4", this.txtDay4.Text.Trim().Length == 0 ? "0" : this.txtDay4.Text);
    //                query = query.Replace("IPDAY5", this.txtDay5.Text.Trim().Length == 0 ? "0" : this.txtDay5.Text);
    //                query = query.Replace("IPDAY6", this.txtDay6.Text.Trim().Length == 0 ? "0" : this.txtDay6.Text);
    //                query = query.Replace("IPDAY7", this.txtDay7.Text.Trim().Length == 0 ? "0" : this.txtDay7.Text);
    //                query = query.Replace("IPCREATEBY", "'" + this.lblLoginUser.Text + "'");
    //                this.ExecuteNonQuery(query);
    //                this.LoadResultGrid();
    //            }
    //            else
    //            {
    //                MessageBox.Show("Activity Id for the selected month is empty. Unable to Add timesheet. Please contact system ADMIN", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
    //            }
    //        }
    //        catch (Exception ex)
    //        {
    //            Logger.WriteLogEntry("Error in AddRecord", "Error in AddRecord", ex, Enum.MessageType.Error);
    //        }

    //    }

    //    public void LoadActivityId()
    //    {
    //        try
    //        {

    //            string start = string.Empty;
    //            string end = string.Empty;

    //            //DateTime dtstart = this.dtWeekEndingGlobal;
    //            //DateTime dtend = dtstart.AddMonths(1);
    //            DateTime dtend = this.dtWeekEndingGlobal.AddMonths(1);
    //            DateTime dtstart = dtend.AddMonths(-3);


    //            start = dtstart.Year + "-" + dtstart.Month + "-1";
    //            end = dtend.Year + "-" + dtend.Month + "-1";

    //            string query = string.Empty;

    //            if (this.ApplyActivityIdFilter == "Y")
    //            {
    //                query = @"  select absence_Id as CaseID from t_edis_absence_lookup 
    //                            union
    //                            SELECT DISTINCT CONVERT(varchar, Investigation.Id) as CaseID FROM Restores
    //                            INNER JOIN InvUserMsgTypes  ON InvUserMsgTypes.GroupId = Restores.InvUserGroupId INNER JOIN InvAssignmentUser on InvAssignmentUser.id = InvUserMsgTypes.InvUserId INNER JOIN InvAssignment ON InvAssignment.Id = InvAssignmentUser.InvAssignId 
    //                            INNER JOIN Investigation ON Investigation.Id = InvAssignment.InvID INNER JOIN InvUserMsgTypeGroup ON InvUserMsgTypes.GroupId = InvUserMsgTypeGroup.Id left JOIN LCDPeople ON Investigation.LCDSponsorId = LCDPeople.Id 
    //                            INNER JOIN Employees ON InvAssignment.ProjectCordinatorId = Employees.Id 
    //                            INNER JOIN EDiscoveryMsgTypes ON InvUserMsgTypes.InvUserMsgTypeID = EDiscoveryMsgTypes.Id AND InvUserMsgTypeGroup.MsgTypeId = EDiscoveryMsgTypes.Id 
    //                            INNER JOIN LCDRequest on LCDRequest.Id = invassignment.LCDRequestId 
    //                            WHERE (Restores.CreatedOn between '" + start + "' and '" + end + "' or LCDRequest.CreatedOn between '" + start + "' and '" + end + @"')
    //                            union
    //                            select CaseID from t_dis_Case_Investigation
    //                            order by CaseID desc";

    //                //AND Employees.ID in (select id from Employees where PublicDoaminAlias = '" + this.lblPPMUserName.Text + "')"

    //            }
    //            else
    //            {
    //                query = @"
    //                            select absence_Id as CaseID from t_edis_absence_lookup 
    //                            union
    //                            SELECT DISTINCT CONVERT(varchar, Investigation.Id) as CaseID FROM Restores
    //                            INNER JOIN InvUserMsgTypes  ON InvUserMsgTypes.GroupId = Restores.InvUserGroupId INNER JOIN InvAssignmentUser on InvAssignmentUser.id = InvUserMsgTypes.InvUserId INNER JOIN InvAssignment ON InvAssignment.Id = InvAssignmentUser.InvAssignId 
    //                            INNER JOIN Investigation ON Investigation.Id = InvAssignment.InvID INNER JOIN InvUserMsgTypeGroup ON InvUserMsgTypes.GroupId = InvUserMsgTypeGroup.Id left JOIN LCDPeople ON Investigation.LCDSponsorId = LCDPeople.Id 
    //                            INNER JOIN Employees ON InvAssignment.ProjectCordinatorId = Employees.Id 
    //                            INNER JOIN EDiscoveryMsgTypes ON InvUserMsgTypes.InvUserMsgTypeID = EDiscoveryMsgTypes.Id AND InvUserMsgTypeGroup.MsgTypeId = EDiscoveryMsgTypes.Id 
    //                            INNER JOIN LCDRequest on LCDRequest.Id = invassignment.LCDRequestId 
    //                            union
    //                            select CaseID from t_dis_Case_Investigation
    //                            order by CaseID desc";
    //            }

    //            this.cboActivityID.DataSource = this.LoadDBTableSQL(query).DefaultView;
    //            this.cboActivityID.DisplayMember = "CaseID";

    //            this.cboActivityID.BindingContext = this.BindingContext;

    //        }
    //        catch (Exception ex)
    //        {
    //            Logger.WriteLogEntry("Error in LoadActivityId", "Error in LoadActivityId", ex, Enum.MessageType.Error);
    //        }

    //    }


    //    private void rdoMonthlyView_CheckedChanged(object sender, EventArgs e)
    //    {
    //        this.cboYearView.Enabled = !this.rdoWeeklyView.Checked;
    //        this.btnMonthViewRetrive.Enabled = !this.rdoWeeklyView.Checked;
    //        this.btnGenerateInvoice.Enabled = (!this.rdoWeeklyView.Checked && this.isSuperUser);
    //        this.chkIncludeDepartment.Enabled = (!this.rdoWeeklyView.Checked && this.isSuperUser);
    //        this.btnRetriveAllUser.Enabled = (!this.rdoWeeklyView.Checked && this.isSuperUser);
    //        this.btnRetriveAll.Enabled = (!this.rdoWeeklyView.Checked && this.isSuperUser);
    //        this.btnAbsenceByUser.Enabled = !this.rdoWeeklyView.Checked;
    //        this.btnAbsenceAllByUser.Enabled = !this.rdoWeeklyView.Checked;
    //        this.btnAbsenceAll.Enabled = !this.rdoWeeklyView.Checked;

    //        this.cboMonthView.Enabled = this.rdoMonthlyView.Checked;

    //        if (!this.rdoWeeklyView.Checked)
    //        {
    //            LoadMonthDropDown();
    //            this.gridResult.DataSource = null;
    //        }
    //        if (this.rdoWeeklyView.Checked)
    //        {
    //            this.LoadResultGrid();
    //        }

    //    }


    //    private void LoadMonthDropDown()
    //    {
    //        try
    //        {
    //            string query = @"Select distinct month(WeekEndDate) as MONTHNUMBER from T_EDIS_TIMESHEET order by MONTHNUMBER";

    //            this.cboMonthView.DataSource = this.LoadDBTableSQL(query).DefaultView;
    //            this.cboMonthView.DisplayMember = "MONTHNUMBER";

    //            this.cboMonthView.BindingContext = this.BindingContext;

    //            string queryYear = @"Select distinct YEAR(WeekEndDate) AS YEARNUMBER from T_EDIS_TIMESHEET order by YEARNUMBER desc";

    //            this.cboYearView.DataSource = this.LoadDBTableSQL(queryYear).DefaultView;
    //            this.cboYearView.DisplayMember = "YEARNUMBER";

    //            this.cboYearView.BindingContext = this.BindingContext;


    //        }
    //        catch (Exception ex)
    //        {
    //            Logger.WriteLogEntry("Error in LoadActivityId", "Error in LoadActivityId", ex, Enum.MessageType.Error);
    //        }

    //    }

    //    private void btnMonthViewRetrive_Click(object sender, EventArgs e)
    //    {
    //        LoadMonthlyView(true, true, false);
    //    }

    //    private void btnRetriveAllUser_Click(object sender, EventArgs e)
    //    {
    //        LoadMonthlyView(false, true, false);
    //    }

    //    private void btnRetriveAll_Click(object sender, EventArgs e)
    //    {
    //        LoadMonthlyView(false, false, false);
    //    }

    //    private void btnGenerateInvoice_Click(object sender, EventArgs e)
    //    {
    //        llblGenerateInvoice_LinkClicked();
    //    }

    //    private void btnAbsenceByUser_Click(object sender, EventArgs e)
    //    {
    //        LoadMonthlyView(true, true, true);

    //    }

    //    private void btnAbsenceAllByUser_Click(object sender, EventArgs e)
    //    {
    //        LoadMonthlyView(false, true, true);

    //    }

    //    private void btnAbsenceAll_Click(object sender, EventArgs e)
    //    {
    //        LoadMonthlyView(false, false, true);

    //    }

    //    private void LoadMonthlyView(bool currentUserOnly, bool isUserbasedPull, bool isAbsenceView)
    //    {
    //        try
    //        {
    //            this.gridResult.DataSource = GetMonthlyViewTable(currentUserOnly, isUserbasedPull, isAbsenceView); ;
    //        }
    //        catch (Exception ex)
    //        {
    //            Logger.WriteLogEntry("Error in LoadResultGrid", "Error in LoadResultGrid", ex, Enum.MessageType.Error);
    //        }

    //    }

    //    private DataTable GetMonthlyViewTable(bool currentUserOnly, bool isUserbasedPull, bool isAbsenceView)
    //    {
    //        DataTable dtTable = null;
    //        try
    //        {
    //            int month = 0;
    //            int year = 0;
    //            ArrayList alMothList = new ArrayList();
    //            int CycleLength = 0;

    //            year = Convert.ToInt32(this.cboYearView.Text);
    //            if (this.rdoMonthlyView.Checked)
    //            {
    //                month = Convert.ToInt32(this.cboMonthView.Text);
    //                alMothList.Add(month);
    //                CycleLength = 6;
    //            }

    //            if (this.rdoQuerterly.Checked)
    //            {
    //                CycleLength = 15;
    //                if (this.cboQuarter.Text.Contains("Q1"))
    //                {
    //                    month = 1;
    //                }
    //                if (this.cboQuarter.Text.Contains("Q2"))
    //                {
    //                    month = 4;
    //                }
    //                if (this.cboQuarter.Text.Contains("Q3"))
    //                {
    //                    month = 7;
    //                }
    //                if (this.cboQuarter.Text.Contains("Q4"))
    //                {
    //                    month = 10;
    //                }
    //                for (int i = 0; i < 3; i++)
    //                {
    //                    alMothList.Add(month + i);
    //                }
    //            }


    //            if (this.rdoSemiAnnual.Checked)
    //            {
    //                CycleLength = 30;
    //                if (this.cboSemiAnnual.Text.Contains("Jan"))
    //                {
    //                    month = 1;
    //                }
    //                if (this.cboSemiAnnual.Text.Contains("Dec"))
    //                {
    //                    month = 7;
    //                }
    //                for (int i = 0; i < 6; i++)
    //                {
    //                    alMothList.Add(month + i);
    //                }
    //            }

    //            if (this.rdoYearly.Checked)
    //            {
    //                CycleLength = 55;
    //                month = 1;
    //                for (int i = 0; i < 12; i++)
    //                {
    //                    alMothList.Add(month + i);
    //                }
    //            }


    //            string query = "select UserName, [Activity Id], SUM(Day1 + Day2+ Day3+ Day4+ Day5+ Day6+ Day7) as Hours from (";
    //            query = query + GenerateReportQuery(month, year, currentUserOnly, isAbsenceView, CycleLength, alMothList) + " ) a group by UserName, [Activity Id]";

    //            //string query = "select UserName, WeekEnd_ID, WeekEndDate, [Activity Id], Day1 + Day2+ Day3+ Day4+ Day5+ Day6+ Day7 as Hours from (";
    //            //query = query + GenerateReportQuery(month, year, currentUserOnly, isAbsenceView, CycleLength, alMothList) + " ) a ";


    //            if (!isUserbasedPull)
    //            {
    //                query = query.Replace("UserName,", "");
    //            }

    //            dtTable = this.LoadDBTableSQL(query);

    //        }
    //        catch (Exception ex)
    //        {
    //            Logger.WriteLogEntry("Error in GetMonthlyViewTable", "Error in GetMonthlyViewTable", ex, Enum.MessageType.Error);
    //        }
    //        return dtTable;
    //    }

    //    private void btnAllow_Click(object sender, EventArgs e)
    //    {
    //        this.lblPPMUserName.Text = this.cboOverideUser.Text;
    //        this.LoadResultGrid();
    //    }

    //    private void chkOveride_CheckedChanged(object sender, EventArgs e)
    //    {
    //        EnableOverideUserObjects(this.chkOveride.Checked);
    //        LoadOverideUser();
    //    }

    //    private void cboOverideUser_SelectedIndexChanged(object sender, EventArgs e)
    //    {

    //    }

    //    private void EnableOverideUserObjects(bool enable)
    //    {
    //        try
    //        {
    //            //this.chkOveride.Enabled = enable;
    //            this.btnAllow.Enabled = enable;
    //            this.cboOverideUser.Enabled = enable;
    //        }
    //        catch (Exception ex)
    //        {
    //            Logger.WriteLogEntry("Error in EnableOverideUserObjects", "Error in EnableOverideUserObjects", ex, Enum.MessageType.Error);
    //        }

    //    }

    //    private void LoadOverideUser()
    //    {
    //        try
    //        {
    //            if (this.chkOveride.Checked)
    //            {
    //                string query = @"select PublicDoaminAlias as USERS from Employees where isactive = 1";

    //                this.cboOverideUser.DataSource = this.LoadDBTableSQL(query).DefaultView;
    //                this.cboOverideUser.DisplayMember = "USERS";

    //                this.cboOverideUser.BindingContext = this.BindingContext;

    //                this.LoadActivityId();
    //            }
    //            else
    //            {
    //                this.lblPPMUserName.Text = System.Security.Principal.WindowsIdentity.GetCurrent().Name;
    //                this.LoadActivityId();
    //                this.LoadResultGrid();
    //            }

    //        }
    //        catch (Exception ex)
    //        {
    //            Logger.WriteLogEntry("Error in LoadOverideUser", "Error in LoadOverideUser", ex, Enum.MessageType.Error);
    //        }

    //    }
    //    bool isSuperUser = false;
    //    private bool IsSuperUser()
    //    {
    //        try
    //        {
    //            string query = @"select RoleName from dbo.t_edis_UserRole where USERNAME = '" + this.lblPPMUserName.Text + "'";

    //            DataTable dtTable = this.LoadDBTableSQL(query);
    //            if (dtTable.Rows.Count > 0)
    //            {
    //                string LoginUser = dtTable.Rows[0][0].ToString();
    //                isSuperUser = (LoginUser == "ADMIN");
    //            }

    //        }
    //        catch (Exception ex)
    //        {
    //            Logger.WriteLogEntry("Error in IsSuperUser", "Error in IsSuperUser", ex, Enum.MessageType.Error);
    //        }
    //        return isSuperUser;
    //    }

    //    private void gridResult_SelectionChanged(object sender, EventArgs e)
    //    {
    //        try
    //        {
    //            if (this.rdoWeeklyView.Checked)
    //            {
    //                if (this.gridResult.SelectedRows.Count == 1)
    //                {
    //                    DataGridViewRow row = this.gridResult.SelectedRows[0];
    //                    this.txtDay1.Text = row.Cells[1].Value.ToString();
    //                    this.txtDay2.Text = row.Cells[2].Value.ToString();
    //                    this.txtDay3.Text = row.Cells[3].Value.ToString();
    //                    this.txtDay4.Text = row.Cells[4].Value.ToString();
    //                    this.txtDay5.Text = row.Cells[5].Value.ToString();
    //                    this.txtDay6.Text = row.Cells[6].Value.ToString();
    //                    this.txtDay7.Text = row.Cells[7].Value.ToString();

    //                    this.cboActivityID.Text = row.Cells[0].Value.ToString();

    //                    UpdateTotal();
    //                }
    //            }
    //        }
    //        catch (Exception ex)
    //        {
    //            Logger.WriteLogEntry("Error in gridResult_SelectionChanged", "Error in gridResult_SelectionChanged", ex, Enum.MessageType.Error);
    //        }
    //    }

    //    #region Input validation


    //    private void ValidateKeyPress(object sender, KeyPressEventArgs e)
    //    {
    //        // Verify that the pressed key isn't CTRL or any non-numeric digit
    //        if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
    //        {
    //            e.Handled = true;
    //        }

    //        // If you want, you can allow decimal (float) numbers
    //        if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
    //        {
    //            e.Handled = true;
    //        }
    //    }
    //    private void ValidateNumbersInput(TextBox textBox)
    //    {
    //        try
    //        {
    //            if (textBox.Text.Length > 0)
    //            {
    //                decimal valueDec = decimal.Parse(textBox.Text);
    //                this.UpdateTotal();
    //            }


    //        }
    //        catch (Exception ex)
    //        {
    //            MessageBox.Show("Only numbers are allowed", "Alert", MessageBoxButtons.OK);
    //            textBox.Text = "0.00";
    //            this.UpdateTotal();
    //            Logger.WriteLogEntry("Error in txtDay_Leave" + textBox, "Error in txtDay_Leave", ex, Enum.MessageType.Error);
    //        }

    //    }

    //    private void UpdateTotal()
    //    {
    //        try
    //        {
    //            try
    //            {
    //                decimal total = GetNumberValue(this.txtDay1) + GetNumberValue(this.txtDay2) + GetNumberValue(this.txtDay3) + GetNumberValue(this.txtDay4) + GetNumberValue(this.txtDay5) + GetNumberValue(this.txtDay6) + GetNumberValue(this.txtDay7);
    //                this.lblToal.Text = "Total:" + total + " Hours";
    //                this.lblToal.ForeColor = Color.Green;
    //                if (total > 40)
    //                {
    //                    this.lblToal.ForeColor = Color.Red;
    //                }
    //            }
    //            catch { }

    //        }
    //        catch (Exception ex)
    //        {
    //            Logger.WriteLogEntry("Error in UpdateTotal", "Error in UpdateTotal", ex, Enum.MessageType.Error);
    //        }

    //    }

    //    private decimal GetNumberValue(TextBox textBox)
    //    {
    //        decimal valueDec = 0;
    //        try
    //        {
    //            valueDec = decimal.Parse(textBox.Text);

    //        }
    //        catch { }
    //        {
    //        }

    //        return valueDec;
    //    }


    //    private void txtDay1_Leave(object sender, EventArgs e)
    //    {
    //        ValidateNumbersInput(this.txtDay1);
    //    }
    //    private void txtDay2_Leave(object sender, EventArgs e)
    //    {
    //        ValidateNumbersInput(this.txtDay2);
    //    }
    //    private void txtDay3_Leave(object sender, EventArgs e)
    //    {
    //        ValidateNumbersInput(this.txtDay3);
    //    }
    //    private void txtDay4_Leave(object sender, EventArgs e)
    //    {
    //        ValidateNumbersInput(this.txtDay4);
    //    }
    //    private void txtDay5_Leave(object sender, EventArgs e)
    //    {
    //        ValidateNumbersInput(this.txtDay5);
    //    }
    //    private void txtDay6_Leave(object sender, EventArgs e)
    //    {
    //        ValidateNumbersInput(this.txtDay6);
    //    }
    //    private void txtDay7_Leave(object sender, EventArgs e)
    //    {
    //        ValidateNumbersInput(this.txtDay7);
    //    }

    //    private void txtDay1_KeyPress(object sender, KeyPressEventArgs e)
    //    {
    //        ValidateKeyPress(sender, e);
    //    }

    //    private void txtDay2_KeyPress(object sender, KeyPressEventArgs e)
    //    {
    //        ValidateKeyPress(sender, e);
    //    }

    //    private void txtDay3_KeyPress(object sender, KeyPressEventArgs e)
    //    {
    //        ValidateKeyPress(sender, e);
    //    }

    //    private void txtDay4_KeyPress(object sender, KeyPressEventArgs e)
    //    {
    //        ValidateKeyPress(sender, e);
    //    }

    //    private void txtDay5_KeyPress(object sender, KeyPressEventArgs e)
    //    {
    //        ValidateKeyPress(sender, e);
    //    }

    //    private void txtDay6_KeyPress(object sender, KeyPressEventArgs e)
    //    {
    //        ValidateKeyPress(sender, e);
    //    }

    //    private void txtDay7_KeyPress(object sender, KeyPressEventArgs e)
    //    {
    //        ValidateKeyPress(sender, e);
    //    }
    //    #endregion Input Validation

    //    private void llblCopyLastweekTimesheet_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
    //    {
    //        DialogResult dr = new DialogResult();
    //        dr = MessageBox.Show("This action will copy previous weekend timesheet (i.e " + dtWeekEndingGlobal.AddDays(-7).ToShortDateString() + ") to current weekend timesheet (i.e " + dtWeekEndingGlobal.ToShortDateString() + "). if there are any existing entires in the current weekend that will be deleted. Do you want to continue?", "Please Confirm", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
    //        if (dr == DialogResult.Yes)
    //        {
    //            this.CopyLastWeekTimesheet();
    //        }
    //    }

    //    private void CopyLastWeekTimesheet()
    //    {
    //        try
    //        {
    //            string query = string.Empty;

    //            query = "Exec speDiscCopyTimeSheet @copyWeekEndId = IP_COPYWEEKENDID, @currentWeekEndId = IP_CURRENTWEEKENDID, @currentWeekEndDate = IP_CURRENTWEEKENDDATE, @userName = IPUSERNAME, @CreatedBy = IPCREATEBY";


    //            query = query.Replace("IP_CURRENTWEEKENDDATE", "'" + this.dtWeekEndingGlobal.ToShortDateString() + "'");
    //            query = query.Replace("IP_CURRENTWEEKENDID", "'" + this.dtWeekEndingGlobal.Month.ToString("D2") + this.dtWeekEndingGlobal.Day.ToString("D2") + this.dtWeekEndingGlobal.Year.ToString("D4") + "'");
    //            query = query.Replace("IP_COPYWEEKENDID", "'" + this.dtWeekEndingGlobal.AddDays(-7).Month.ToString("D2") + this.dtWeekEndingGlobal.AddDays(-7).Day.ToString("D2") + this.dtWeekEndingGlobal.AddDays(-7).Year.ToString("D4") + "'");
    //            query = query.Replace("IPUSERNAME", "'" + this.lblPPMUserName.Text + "'");
    //            query = query.Replace("IPCREATEBY", "'" + this.lblLoginUser.Text + "'");

    //            this.ExecuteNonQuery(query);
    //            this.LoadResultGrid();
    //        }
    //        catch (Exception ex)
    //        {
    //            Logger.WriteLogEntry("Error in CopyLastWeekTimesheet", "Error in CopyLastWeekTimesheet", ex, Enum.MessageType.Error);
    //        }

    //    }

    //    private void llblGenerateInvoice_LinkClicked()
    //    {
    //        try
    //        {
    //            string start = string.Empty;
    //            string end = string.Empty;

    //            DateTime dtstart = new DateTime();
    //            DateTime dtend = new DateTime();


    //            //string query = @"SELECT DISTINCT Investigation.Id as CaseID ,Investigation.InvName as SSCCKK_invname,0 Hours,'TISR' + CONVERT(VARCHAR,Investigation.Id) projwebID, 
    //            //                (SELECT LCDPersonDisplayName from dbo.LCDPeople where id = Investigation.LCDSponsorId) as [Primary LCD Requestor] ,
    //            //                (SELECT LCDPersonDisplayName from dbo.LCDPeople where id = Investigation.LCDSponAsistantId) as [Secondary LCD Requestor],Investigation.CostCode as Account ,Investigation.CostBreakDown as [Cost Center] 
    //            //                ,'United States of America'  Location,'' Area
    //            //                from Restores
    //            //                INNER JOIN InvUserMsgTypes  ON InvUserMsgTypes.GroupId = Restores.InvUserGroupId INNER JOIN InvAssignmentUser on InvAssignmentUser.id = InvUserMsgTypes.InvUserId INNER JOIN InvAssignment ON InvAssignment.Id = InvAssignmentUser.InvAssignId 
    //            //                INNER JOIN Investigation ON Investigation.Id = InvAssignment.InvID INNER JOIN InvUserMsgTypeGroup ON InvUserMsgTypes.GroupId = InvUserMsgTypeGroup.Id left JOIN LCDPeople ON Investigation.LCDSponsorId = LCDPeople.Id 
    //            //                INNER JOIN Employees ON InvAssignment.ProjectCordinatorId = Employees.Id 
    //            //                INNER JOIN EDiscoveryMsgTypes ON InvUserMsgTypes.InvUserMsgTypeID = EDiscoveryMsgTypes.Id AND InvUserMsgTypeGroup.MsgTypeId = EDiscoveryMsgTypes.Id 
    //            //                INNER JOIN LCDRequest on LCDRequest.Id = invassignment.LCDRequestId 
    //            //                WHERE Restores.CreatedOn between '" + start+ "' and '" + end + "' or LCDRequest.CreatedOn between '" + start + "' and '" + end + "'";



    //            int year = Convert.ToInt32(this.cboYearView.Text);
    //            if (this.rdoMonthlyView.Checked)
    //            {
    //                dtstart = new DateTime(year, Convert.ToInt32(this.cboMonthView.Text), 1);
    //                dtend = dtstart.AddMonths(1);
    //                start = dtstart.Year + "-" + dtstart.Month + "-1";
    //                end = dtend.Year + "-" + dtend.Month + "-1";
    //            }

    //            if (this.rdoQuerterly.Checked)
    //            {
    //                if (this.cboQuarter.Text.Contains("Q1"))
    //                {
    //                    dtstart = new DateTime(year, 1, 1);
    //                }
    //                if (this.cboQuarter.Text.Contains("Q2"))
    //                {
    //                    dtstart = new DateTime(year, 4, 1);
    //                }
    //                if (this.cboQuarter.Text.Contains("Q3"))
    //                {
    //                    dtstart = new DateTime(year, 7, 1);
    //                }
    //                if (this.cboQuarter.Text.Contains("Q4"))
    //                {
    //                    dtstart = new DateTime(year, 10, 1);
    //                }

    //                dtend = dtstart.AddMonths(3);
    //                start = dtstart.Year + "-" + dtstart.Month + "-1";
    //                end = dtend.Year + "-" + dtend.Month + "-1";
    //            }


    //            if (this.rdoSemiAnnual.Checked)
    //            {
    //                if (this.cboSemiAnnual.Text.Contains("Jan"))
    //                {
    //                    dtstart = new DateTime(year, 1, 1);
    //                }
    //                if (this.cboSemiAnnual.Text.Contains("Dec"))
    //                {
    //                    dtstart = new DateTime(year, 7, 1);
    //                }
    //                dtend = dtstart.AddMonths(6);
    //                start = dtstart.Year + "-" + dtstart.Month + "-1";
    //                end = dtend.Year + "-" + dtend.Month + "-1";
    //            }

    //            if (this.rdoYearly.Checked)
    //            {
    //                dtstart = new DateTime(year, 1, 1);
    //                dtend = dtstart.AddMonths(12);
    //                start = dtstart.Year + "-" + dtstart.Month + "-1";
    //                end = dtend.Year + "-" + dtend.Month + "-1";
    //            }

    //            string query = @"SELECT DISTINCT CONVERT(varchar, Investigation.Id) as CaseID ,Investigation.InvName as SSCCKK_invname,0 Hours,  Investigation.ProjectWebId,
    //                            Pl.LCDPersonDisplayName as [Primary LCD Requestor] ,
    //                            (SELECT LCDPersonDisplayName from dbo.LCDPeople where id = Investigation.LCDSponAsistantId) as [Secondary LCD Requestor],'' as Department, Investigation.CostCode as Account, Investigation.CostBreakDown as [Cost Center] 
    //                            ,bu.businessunit ,'AMER' as Location,''  Comments
    //                            from Restores
    //                            INNER JOIN InvUserMsgTypes  ON InvUserMsgTypes.GroupId = Restores.InvUserGroupId INNER JOIN InvAssignmentUser on InvAssignmentUser.id = InvUserMsgTypes.InvUserId INNER JOIN InvAssignment ON InvAssignment.Id = InvAssignmentUser.InvAssignId 
    //                            INNER JOIN Investigation ON Investigation.Id = InvAssignment.InvID INNER JOIN InvUserMsgTypeGroup ON InvUserMsgTypes.GroupId = InvUserMsgTypeGroup.Id left JOIN LCDPeople ON Investigation.LCDSponsorId = LCDPeople.Id 
    //                            INNER JOIN Employees ON InvAssignment.ProjectCordinatorId = Employees.Id 
    //                            INNER JOIN EDiscoveryMsgTypes ON InvUserMsgTypes.InvUserMsgTypeID = EDiscoveryMsgTypes.Id AND InvUserMsgTypeGroup.MsgTypeId = EDiscoveryMsgTypes.Id 
    //                            INNER JOIN LCDRequest on LCDRequest.Id = invassignment.LCDRequestId 
    //                            LEFT JOIN LCDPeople Pl ON Pl.Id = Investigation.LCDSponsorId
    //                            --LEFT JOIN t_dis_businessunit bu ON bu.CostCode = Investigation.CostBreakDown AND Investigation.CostBreakDown != '' 
    //                            LEFT JOIN t_dis_businessunit bu ON bu.CostCode = (CASE WHEN(CHARINDEX(',', Investigation.CostBreakDown)) > 0 THEN
    //                                LTRIM(RTRIM(SUBSTRING(Investigation.CostBreakDown, 1, CHARINDEX(',', Investigation.CostBreakDown) - 1))) ELSE Investigation.CostBreakDown END) AND Investigation.CostBreakDown != ''";
    //            //WHERE Restores.CreatedOn between '" + start + "' and '" + end + "' or LCDRequest.CreatedOn between '" + start + "' and '" + end + "'" 


    //            DataTable dtMaster = DecryptSQLQuery.LoadDecryptSQLQuery(query, conString);

    //            string querySecondary = @"select ci.*, bu.BusinessUnit  from t_dis_Case_Investigation ci
    //                                      LEFT JOIN t_dis_businessunit bu ON bu.CostCode = ci.Account AND ci.Account != ''";

    //            DataTable dtMasterSecondary = this.LoadDBTableSQL(querySecondary);

    //            DataTable dtHours = GetMonthlyViewTable(false, false, false);

    //            DataTable dtDepartment = null;
    //            if (this.chkIncludeDepartment.Checked)
    //            {
    //                //string queryDepartment = @"SELECT T.RequestorName,dt.Department FROM (
    //                //                        SELECT RequestorName,department DeptCode FROM ( 
    //                //                        SELECT first_name + ' ' + last_name RequestorName,department,ROW_NUMBER() OVER(PARTITION BY first_name,last_name ORDER BY last_updated DESC)RowNo FROM ADS_HEDANI_GAL_TB WHERE first_name IS NOT NULL AND last_name IS NOT NULL
    //                //                        AND first_name + ' ' + last_name  IN (    
    //                //                        SELECT DISTINCT Pl.LCDPersonDisplayName as [Primary LCD Requestor] 
    //                //                                                                        from Restores
    //                //                                                        INNER JOIN InvUserMsgTypes  ON InvUserMsgTypes.GroupId = Restores.InvUserGroupId INNER JOIN InvAssignmentUser on InvAssignmentUser.id = InvUserMsgTypes.InvUserId INNER JOIN InvAssignment ON InvAssignment.Id = InvAssignmentUser.InvAssignId 
    //                //                                                        INNER JOIN Investigation ON Investigation.Id = InvAssignment.InvID INNER JOIN InvUserMsgTypeGroup ON InvUserMsgTypes.GroupId = InvUserMsgTypeGroup.Id left JOIN LCDPeople ON Investigation.LCDSponsorId = LCDPeople.Id 
    //                //                                                        INNER JOIN Employees ON InvAssignment.ProjectCordinatorId = Employees.Id 
    //                //                                                        INNER JOIN EDiscoveryMsgTypes ON InvUserMsgTypes.InvUserMsgTypeID = EDiscoveryMsgTypes.Id AND InvUserMsgTypeGroup.MsgTypeId = EDiscoveryMsgTypes.Id 
    //                //                                                        INNER JOIN LCDRequest on LCDRequest.Id = invassignment.LCDRequestId 
    //                //                                                        LEFT JOIN LCDPeople Pl ON Pl.Id = Investigation.LCDSponsorId ))sT WHERE sT.RowNo = 1 )T INNER JOIN t_edis_Department Dt ON Dt.OECode = T.DeptCode ";
    //                //WHERE Restores.CreatedOn between '" + start + "' and '" + end + "' or LCDRequest.CreatedOn between '" + start + "' and '" + end + "'))sT WHERE sT.RowNo = 1 )T INNER JOIN t_edis_Department Dt ON Dt.OECode = T.DeptCode ";


    //                string queryDepartment = @"SELECT T.RequestorName,dt.Department FROM (
    //                                        SELECT RequestorName,department DeptCode FROM ( 
    //                                        SELECT first_name + ' ' + last_name RequestorName,department,ROW_NUMBER() OVER(PARTITION BY first_name,last_name ORDER BY last_updated DESC)RowNo FROM ADS_HEDANI_GAL_TB WHERE first_name IS NOT NULL AND last_name IS NOT NULL
    //                                        AND first_name + ' ' + last_name  IN (    
    //                                        SELECT DISTINCT Pl.LCDPersonDisplayName as [Primary LCD Requestor] 
    //                                                from Restores
    //                                                INNER JOIN InvUserMsgTypes  ON InvUserMsgTypes.GroupId = Restores.InvUserGroupId INNER JOIN InvAssignmentUser on InvAssignmentUser.id = InvUserMsgTypes.InvUserId INNER JOIN InvAssignment ON InvAssignment.Id = InvAssignmentUser.InvAssignId 
    //                                                INNER JOIN Investigation ON Investigation.Id = InvAssignment.InvID INNER JOIN InvUserMsgTypeGroup ON InvUserMsgTypes.GroupId = InvUserMsgTypeGroup.Id left JOIN LCDPeople ON Investigation.LCDSponsorId = LCDPeople.Id 
    //                                                INNER JOIN Employees ON InvAssignment.ProjectCordinatorId = Employees.Id 
    //                                                INNER JOIN EDiscoveryMsgTypes ON InvUserMsgTypes.InvUserMsgTypeID = EDiscoveryMsgTypes.Id AND InvUserMsgTypeGroup.MsgTypeId = EDiscoveryMsgTypes.Id 
    //                                                INNER JOIN LCDRequest on LCDRequest.Id = invassignment.LCDRequestId 
    //                                                LEFT JOIN LCDPeople Pl ON Pl.Id = Investigation.LCDSponsorId )
    //                                                )sT WHERE sT.RowNo = 1 
    //                                                UNION 
    //                                                SELECT RequestorName,department FROM (
    //                                                                          SELECT first_name + ' ' + last_name RequestorName,department,ROW_NUMBER() OVER(PARTITION BY first_name,last_name ORDER BY last_updated DESC)RowNo FROM ADS_HEDANI_GAL_TB WHERE first_name IS NOT NULL AND last_name IS NOT NULL
    //                                                                          AND first_name + ' ' + last_name  IN (SELECT DISTINCT PrimaryRequestor FROM t_dis_Case_Investigation ))T1 WHERE T1.RowNo = 1
                                                    
    //                                                )T INNER JOIN t_edis_Department Dt ON Dt.OECode = T.DeptCode";

    //                dtDepartment = this.LoadDBTableSQL(queryDepartment);
    //            }


    //            this.gridResult.DataSource = CreateInvoiceReport(dtMaster, dtHours, dtDepartment, dtMasterSecondary);
    //        }
    //        catch (Exception ex)
    //        {
    //            Logger.WriteLogEntry("Error in llblGenerateInvoice_LinkClicked", "Error in llblGenerateInvoice_LinkClicked", ex, Enum.MessageType.Error);
    //        }

    //    }


    //    private DataTable CreateInvoiceReport(DataTable dtMaster, DataTable dtHours, DataTable dtDepartment, DataTable dtMasterSecondary)
    //    {
    //        DataTable dtMasterFinal = null;

    //        try
    //        {
    //            DataRow[] dr = null;
    //            DataRow[] drDept = null;
    //            DataRow drFinal = null;
    //            string dept = string.Empty;
    //            string requester = string.Empty;
    //            int hours = 0;

    //            DataRow drSec = null;
    //            for (int isec = 0; isec < dtMasterSecondary.Rows.Count; isec++)
    //            {
    //                drSec = dtMaster.NewRow();
    //                drSec[0] = dtMasterSecondary.Rows[isec]["CaseID"];
    //                drSec[1] = dtMasterSecondary.Rows[isec]["CaseName"];
    //                drSec[2] = 0;//Hours
    //                drSec[3] = dtMasterSecondary.Rows[isec]["ProjWebID"];
    //                drSec[4] = dtMasterSecondary.Rows[isec]["PrimaryRequestor"];
    //                drSec[5] = dtMasterSecondary.Rows[isec]["SecondaryRequester"];
    //                drSec[6] = "";//Department
    //                drSec[7] = dtMasterSecondary.Rows[isec]["Account"];
    //                drSec[8] = dtMasterSecondary.Rows[isec]["CostCenter"];
    //                drSec[9] = dtMasterSecondary.Rows[isec]["BusinessUnit"];
    //                drSec[10] = "AMER";
    //                drSec[11] = "";//Comments
    //                dtMaster.Rows.Add(drSec);
    //            }

    //            dtMaster.AcceptChanges();



    //            dtMasterFinal = dtMaster.Clone();

    //            for (int i = 0; i < dtMaster.Rows.Count; i++)
    //            {
    //                if (dtDepartment != null)
    //                {
    //                    dept = string.Empty;
    //                    requester = dtMaster.Rows[i]["Primary LCD Requestor"].ToString().Replace("'", "''");
    //                    drDept = dtDepartment.Select("RequestorName = '" + requester + "'");
    //                    if (drDept.Length > 0)
    //                    {
    //                        dept = drDept[0]["Department"].ToString();
    //                    }
    //                }

    //                dr = dtHours.Select("[Activity Id] = '" + dtMaster.Rows[i][0].ToString() + "'");
    //                if (dr.Length > 0)
    //                {
    //                    hours = 0;
    //                    hours = Convert.ToInt32(dr[0]["Hours"]);

    //                    drFinal = dtMasterFinal.NewRow();
    //                    for (int j = 0; j < dtMasterFinal.Columns.Count; j++)
    //                    {
    //                        drFinal[j] = dtMaster.Rows[i][j];
    //                    }
    //                    drFinal["Department"] = dept;
    //                    drFinal["Hours"] = hours;

    //                    dtMasterFinal.Rows.Add(drFinal);
    //                }
    //            }

    //            dtMasterFinal.AcceptChanges();

    //            ArrayList alList = new ArrayList();
    //            alList.Add("Case ID");
    //            alList.Add("Case Name");
    //            alList.Add("Hours");
    //            alList.Add("Project Web Id");
    //            alList.Add("LCD Requestor");
    //            alList.Add("Assistant\\GC Approval");
    //            alList.Add("Department");
    //            alList.Add("Account");
    //            alList.Add("Cost Center");
    //            alList.Add("Business Unit");
    //            alList.Add("Location");
    //            alList.Add("Comments");

    //            for (int j = 0; j < dtMasterFinal.Columns.Count; j++)
    //            {
    //                dtMasterFinal.Columns[j].ColumnName = alList[j].ToString();

    //            }
    //            dtMasterFinal.AcceptChanges();

    //        }
    //        catch (Exception ex)
    //        {
    //            Logger.WriteLogEntry("Error in CreateInvoiceReport", "Error in CreateInvoiceReport", ex, Enum.MessageType.Error);
    //        }
    //        return dtMasterFinal;
    //    }

    //    private void llblExportToExcel_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
    //    {
    //        try
    //        {
    //            if (this.gridResult.DataSource != null)
    //            {
    //                if (this.txtExportPath.Text.Trim().Length > 0)
    //                {

    //                    DataTable dt = (DataTable)this.gridResult.DataSource;
    //                    DataSet ds = new DataSet();
    //                    ds.Tables.Add(dt);
    //                    ExportToExcel.ExportDataExcel(ds, "Table1", this.txtExportPath.Text);

    //                    MessageBox.Show("Success Export To Excel. Please check the file in the given path", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
    //                }
    //                else
    //                {
    //                    MessageBox.Show("File path can not be empty. Please input the file path", "Alert", MessageBoxButtons.OK);
    //                }
    //            }
    //            else
    //            {
    //                MessageBox.Show("Grid results are empty. Unable to generate report", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
    //            }

    //        }
    //        catch (Exception ex)
    //        {
    //            MessageBox.Show("Sorry, unable to generate excel report. Please contact system admin", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
    //            Logger.WriteLogEntry("Error in llblExportToExcel_LinkClicked", "Error in llblExportToExcel_LinkClicked", ex, Enum.MessageType.Error);
    //        }
    //    }
    //    private string GenerateReportQuery(int month, int year, bool currentUserOnly, bool isAbsenceView, int CycleLength, ArrayList alMothList)
    //    {
    //        //int month = 11;
    //        //int year = 2018;
    //        alList = new ArrayList();
    //        DateTime dtStart = new DateTime(year, month, 1);
    //        DateTime dtEnd = new DateTime(year, month, DateTime.DaysInMonth(year, month));

    //        double start = 7 - (int)dtStart.DayOfWeek;
    //        DateTime dtWeekEnding = dtStart.AddDays(start);

    //        //this.onlyZeros = true;
    //        //ConstructQuery(dtWeekEnding, month, currentUserOnly, isAbsenceView);

    //        //dtWeekEnding = dtWeekEnding.AddDays(7);
    //        //this.onlyZeros = true;
    //        //ConstructQuery(dtWeekEnding, month, currentUserOnly, isAbsenceView);

    //        //dtWeekEnding = dtWeekEnding.AddDays(7);
    //        //this.onlyZeros = true;
    //        //ConstructQuery(dtWeekEnding, month, currentUserOnly, isAbsenceView);

    //        //dtWeekEnding = dtWeekEnding.AddDays(7);
    //        //this.onlyZeros = true;
    //        //ConstructQuery(dtWeekEnding, month, currentUserOnly, isAbsenceView);

    //        //dtWeekEnding = dtWeekEnding.AddDays(7);
    //        //this.onlyZeros = true;
    //        //ConstructQuery(dtWeekEnding, month, currentUserOnly, isAbsenceView);

    //        //dtWeekEnding = dtWeekEnding.AddDays(7);
    //        //this.onlyZeros = true;
    //        //ConstructQuery(dtWeekEnding, month, currentUserOnly, isAbsenceView);

    //        for (int cycle = 0; cycle < CycleLength; cycle++)
    //        {
    //            this.onlyZeros = true;
    //            ConstructQuery(dtWeekEnding, alMothList, currentUserOnly, isAbsenceView);
    //            dtWeekEnding = dtWeekEnding.AddDays(7);
    //        }

    //        string ReportQuery = string.Empty;
    //        for (int i = 0; i < alList.Count; i++)
    //        {
    //            ReportQuery = ReportQuery + " " + alList[i];
    //        }

    //        return ReportQuery;
    //    }

    //    ArrayList alList = new ArrayList();
    //    private void ConstructQuery(DateTime dtInput, ArrayList alMothList, bool currentUserOnly, bool isAbsenceView)
    //    {
    //        //invoiceQuery = "SELECT UserName, CaseID as 'Activity Id' "; //TODO
    //        invoiceQuery = "SELECT UserName, CaseID as 'Activity Id' ";

    //        ConstructSubQuery(dtInput.AddDays(-6), alMothList, "Day1");
    //        ConstructSubQuery(dtInput.AddDays(-5), alMothList, "Day2");
    //        ConstructSubQuery(dtInput.AddDays(-4), alMothList, "Day3");
    //        ConstructSubQuery(dtInput.AddDays(-3), alMothList, "Day4");
    //        ConstructSubQuery(dtInput.AddDays(-2), alMothList, "Day5");
    //        ConstructSubQuery(dtInput.AddDays(-1), alMothList, "Day6");
    //        ConstructSubQuery(dtInput.AddDays(0), alMothList, "Day7");

    //        string absString = string.Empty;
    //        if (!isAbsenceView)
    //        {
    //            absString = " caseid not in (select absence_id from t_edis_absence_lookup) and ";
    //        }
    //        else
    //        {
    //            absString = " caseid in (select absence_id from t_edis_absence_lookup) and ";
    //        }

    //        if (currentUserOnly)
    //        {
    //            invoiceQuery = invoiceQuery + " FROM t_edis_timesheet where " + absString + " WeekEnd_ID = " + dtInput.Month.ToString("D2") + dtInput.Day.ToString("D2") + dtInput.Year.ToString("D4") + " and UserName = '" + this.lblPPMUserName.Text + "'";
    //        }
    //        else
    //        {
    //            invoiceQuery = invoiceQuery + " FROM t_edis_timesheet where " + absString + " WeekEnd_ID = " + dtInput.Month.ToString("D2") + dtInput.Day.ToString("D2") + dtInput.Year.ToString("D4");
    //        }

    //        if (!this.onlyZeros)
    //        {
    //            if (alList.Count == 0)
    //            {
    //                alList.Add(invoiceQuery);
    //            }
    //            else
    //            {
    //                alList.Add(" UNION " + invoiceQuery);

    //            }
    //        }
    //        invoiceQuery = string.Empty;
    //    }

    //    string invoiceQuery = string.Empty;
    //    bool onlyZeros = true;

    //    private void ConstructSubQuery(DateTime dtTempInput, ArrayList alMothList, string col)
    //    {

    //        if (alMothList.Contains(dtTempInput.Month))
    //        //if (dtTempInput.Month == monthInput)
    //        {
    //            this.onlyZeros = false;
    //            if (invoiceQuery.Length == 0)
    //            {
    //                invoiceQuery = col;
    //            }
    //            else
    //            {
    //                invoiceQuery = invoiceQuery + "," + col;
    //            }
    //        }
    //        else
    //        {
    //            if (invoiceQuery.Length == 0)
    //            {
    //                invoiceQuery = "'0' as " + col;
    //            }
    //            else
    //            {
    //                invoiceQuery = invoiceQuery + "," + "'0' as " + col;
    //            }
    //        }
    //    }

    //    private void rdoQuerterly_CheckedChanged(object sender, EventArgs e)
    //    {
    //        this.cboQuarter.Enabled = this.rdoQuerterly.Checked;
    //        this.rdoMonthlyView_CheckedChanged(null, null);
    //    }

    //    private void rdoSemiAnnual_CheckedChanged(object sender, EventArgs e)
    //    {
    //        this.cboSemiAnnual.Enabled = this.rdoSemiAnnual.Checked;
    //        this.rdoMonthlyView_CheckedChanged(null, null);

    //    }

    //    private void rdoYearly_CheckedChanged(object sender, EventArgs e)
    //    {
    //        this.rdoMonthlyView_CheckedChanged(null, null);
    //    }

    //    private void Result_Enter(object sender, EventArgs e)
    //    {

    //    }

    //    private void gridResult_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
    //    {
    //        try
    //        {
    //            if (this.rdoWeeklyView.Checked)
    //            {
    //                foreach (DataGridViewRow Myrow in this.gridResult.Rows)
    //                {
    //                    if (Myrow.Cells[0].Value.ToString() == "Total:")
    //                    {
    //                        Myrow.DefaultCellStyle.BackColor = Color.LightGoldenrodYellow;
    //                    }
    //                }
    //                DataGridViewColumn Mycol = this.gridResult.Columns[8];
    //                Mycol.DefaultCellStyle.BackColor = Color.LightGoldenrodYellow;
    //            }
    //        }
    //        catch (Exception ex)
    //        {
    //            Logger.WriteLogEntry("Error in gridResult_CellFormatting", "Error in gridResult_CellFormatting", ex, Enum.MessageType.Error);
    //        }
    //    }

    //    private void llblAddActivity_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
    //    {
    //        AddActivity obj = new AddActivity(this.conString, this.lblLoginUser.Text, this);
    //        obj.ShowDialog();
    //    }

    //    private void lblPSTImport_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
    //    {
    //        PSTImport obj = new PSTImport(this.conString, this.lblLoginUser.Text);
    //        obj.ShowDialog();

    //    }
    //}
}
