﻿namespace DBTableDataCompareTool
{
    partial class DMMasterPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Label lblLoginUser;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DMMasterPage));
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblRegion = new System.Windows.Forms.Label();
            this.lblUserName = new System.Windows.Forms.Label();
            this.lblAuditBanner = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnSave = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lblPSTImport = new System.Windows.Forms.LinkLabel();
            this.llblAddActivity = new System.Windows.Forms.LinkLabel();
            this.lblToal = new System.Windows.Forms.Label();
            this.llblCopyLastweekTimesheet = new System.Windows.Forms.LinkLabel();
            this.chkOveride = new System.Windows.Forms.CheckBox();
            this.btnAllow = new System.Windows.Forms.Button();
            this.cboOverideUser = new System.Windows.Forms.ComboBox();
            this.cboActivityID = new System.Windows.Forms.ComboBox();
            this.lblDay7 = new System.Windows.Forms.Label();
            this.txtDay7 = new System.Windows.Forms.TextBox();
            this.lblDay6 = new System.Windows.Forms.Label();
            this.txtDay6 = new System.Windows.Forms.TextBox();
            this.lblDay5 = new System.Windows.Forms.Label();
            this.txtDay5 = new System.Windows.Forms.TextBox();
            this.lblDay4 = new System.Windows.Forms.Label();
            this.txtDay4 = new System.Windows.Forms.TextBox();
            this.lblDay3 = new System.Windows.Forms.Label();
            this.txtDay3 = new System.Windows.Forms.TextBox();
            this.lblDay2 = new System.Windows.Forms.Label();
            this.txtDay2 = new System.Windows.Forms.TextBox();
            this.lblDay1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.llblNext = new System.Windows.Forms.LinkLabel();
            this.llblPrevious = new System.Windows.Forms.LinkLabel();
            this.lblWeekending = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblPPMUserName = new System.Windows.Forms.Label();
            this.txtDay1 = new System.Windows.Forms.TextBox();
            this.lblName = new System.Windows.Forms.Label();
            this.gridResult = new System.Windows.Forms.DataGridView();
            this.Result = new System.Windows.Forms.GroupBox();
            this.chkIncludeDepartment = new System.Windows.Forms.CheckBox();
            this.btnAbsenceAll = new System.Windows.Forms.Button();
            this.btnAbsenceAllByUser = new System.Windows.Forms.Button();
            this.btnAbsenceByUser = new System.Windows.Forms.Button();
            this.cboSemiAnnual = new System.Windows.Forms.ComboBox();
            this.cboQuarter = new System.Windows.Forms.ComboBox();
            this.rdoYearly = new System.Windows.Forms.RadioButton();
            this.rdoSemiAnnual = new System.Windows.Forms.RadioButton();
            this.rdoQuerterly = new System.Windows.Forms.RadioButton();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnGenerateInvoice = new System.Windows.Forms.Button();
            this.btnRetriveAll = new System.Windows.Forms.Button();
            this.btnRetriveAllUser = new System.Windows.Forms.Button();
            this.btnMonthViewRetrive = new System.Windows.Forms.Button();
            this.cboYearView = new System.Windows.Forms.ComboBox();
            this.cboMonthView = new System.Windows.Forms.ComboBox();
            this.rdoMonthlyView = new System.Windows.Forms.RadioButton();
            this.rdoWeeklyView = new System.Windows.Forms.RadioButton();
            this.label4 = new System.Windows.Forms.Label();
            this.txtExportPath = new System.Windows.Forms.TextBox();
            this.llblExportToExcel = new System.Windows.Forms.LinkLabel();
            lblLoginUser = new System.Windows.Forms.Label();
            this.panel2.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridResult)).BeginInit();
            this.Result.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(lblLoginUser);
            this.panel2.Controls.Add(this.lblRegion);
            this.panel2.Controls.Add(this.lblUserName);
            this.panel2.Controls.Add(this.lblAuditBanner);
            this.panel2.Location = new System.Drawing.Point(151, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(800, 64);
            this.panel2.TabIndex = 54;
            // 
            // lblLoginUser
            // 
            lblLoginUser.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            lblLoginUser.AutoSize = true;
            lblLoginUser.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            lblLoginUser.ForeColor = System.Drawing.Color.Gray;
            lblLoginUser.Location = new System.Drawing.Point(679, 46);
            lblLoginUser.Name = "lblLoginUser";
            lblLoginUser.Size = new System.Drawing.Size(55, 13);
            lblLoginUser.TabIndex = 88;
            lblLoginUser.Text = "LoginUser";
            lblLoginUser.TextAlign = System.Drawing.ContentAlignment.TopRight;
            lblLoginUser.Visible = false;
            // 
            // lblRegion
            // 
            this.lblRegion.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblRegion.AutoSize = true;
            this.lblRegion.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRegion.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.lblRegion.Location = new System.Drawing.Point(490, 23);
            this.lblRegion.Name = "lblRegion";
            this.lblRegion.Size = new System.Drawing.Size(115, 20);
            this.lblRegion.TabIndex = 56;
            this.lblRegion.Text = "PRODUCTION";
            // 
            // lblUserName
            // 
            this.lblUserName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblUserName.AutoSize = true;
            this.lblUserName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUserName.ForeColor = System.Drawing.Color.Gray;
            this.lblUserName.Location = new System.Drawing.Point(735, 28);
            this.lblUserName.Name = "lblUserName";
            this.lblUserName.Size = new System.Drawing.Size(60, 13);
            this.lblUserName.TabIndex = 1;
            this.lblUserName.Text = "User Name";
            this.lblUserName.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblAuditBanner
            // 
            this.lblAuditBanner.AutoSize = true;
            this.lblAuditBanner.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAuditBanner.ForeColor = System.Drawing.Color.Gray;
            this.lblAuditBanner.Location = new System.Drawing.Point(8, 23);
            this.lblAuditBanner.Name = "lblAuditBanner";
            this.lblAuditBanner.Size = new System.Drawing.Size(360, 24);
            this.lblAuditBanner.TabIndex = 0;
            this.lblAuditBanner.Text = "LegalIT - eDiscovery TimeSheet Tool v4.0";
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.Location = new System.Drawing.Point(1, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(148, 64);
            this.panel1.TabIndex = 53;
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(746, 98);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(48, 23);
            this.btnSave.TabIndex = 9;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnImportScreen_Click);
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Gray;
            this.label3.Location = new System.Drawing.Point(208, 646);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(531, 13);
            this.label3.TabIndex = 60;
            this.label3.Text = "Copyright © CREDIT SUISSE GROUP AG and/or its affiliates. All rights reserved. FO" +
    "R INTERNAL USE ONLY ";
            this.label3.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(158, 628);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(673, 13);
            this.label6.TabIndex = 61;
            this.label6.Text = "_________________________________________________________________________________" +
    "______________________________";
            this.label6.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.lblPSTImport);
            this.groupBox2.Controls.Add(this.llblAddActivity);
            this.groupBox2.Controls.Add(this.lblToal);
            this.groupBox2.Controls.Add(this.llblCopyLastweekTimesheet);
            this.groupBox2.Controls.Add(this.chkOveride);
            this.groupBox2.Controls.Add(this.btnAllow);
            this.groupBox2.Controls.Add(this.cboOverideUser);
            this.groupBox2.Controls.Add(this.cboActivityID);
            this.groupBox2.Controls.Add(this.lblDay7);
            this.groupBox2.Controls.Add(this.txtDay7);
            this.groupBox2.Controls.Add(this.btnSave);
            this.groupBox2.Controls.Add(this.lblDay6);
            this.groupBox2.Controls.Add(this.txtDay6);
            this.groupBox2.Controls.Add(this.lblDay5);
            this.groupBox2.Controls.Add(this.txtDay5);
            this.groupBox2.Controls.Add(this.lblDay4);
            this.groupBox2.Controls.Add(this.txtDay4);
            this.groupBox2.Controls.Add(this.lblDay3);
            this.groupBox2.Controls.Add(this.txtDay3);
            this.groupBox2.Controls.Add(this.lblDay2);
            this.groupBox2.Controls.Add(this.txtDay2);
            this.groupBox2.Controls.Add(this.lblDay1);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.llblNext);
            this.groupBox2.Controls.Add(this.llblPrevious);
            this.groupBox2.Controls.Add(this.lblWeekending);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.lblPPMUserName);
            this.groupBox2.Controls.Add(this.txtDay1);
            this.groupBox2.Controls.Add(this.lblName);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.groupBox2.Location = new System.Drawing.Point(3, 71);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(947, 132);
            this.groupBox2.TabIndex = 63;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Input Details";
            // 
            // lblPSTImport
            // 
            this.lblPSTImport.AutoSize = true;
            this.lblPSTImport.Location = new System.Drawing.Point(480, 23);
            this.lblPSTImport.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblPSTImport.Name = "lblPSTImport";
            this.lblPSTImport.Size = new System.Drawing.Size(60, 13);
            this.lblPSTImport.TabIndex = 90;
            this.lblPSTImport.TabStop = true;
            this.lblPSTImport.Text = "PST Import";
            this.lblPSTImport.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lblPSTImport_LinkClicked);
            // 
            // llblAddActivity
            // 
            this.llblAddActivity.AutoSize = true;
            this.llblAddActivity.Location = new System.Drawing.Point(388, 23);
            this.llblAddActivity.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.llblAddActivity.Name = "llblAddActivity";
            this.llblAddActivity.Size = new System.Drawing.Size(63, 13);
            this.llblAddActivity.TabIndex = 89;
            this.llblAddActivity.TabStop = true;
            this.llblAddActivity.Text = "Add Activity";
            this.llblAddActivity.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llblAddActivity_LinkClicked);
            // 
            // lblToal
            // 
            this.lblToal.AutoSize = true;
            this.lblToal.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblToal.Location = new System.Drawing.Point(802, 101);
            this.lblToal.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblToal.Name = "lblToal";
            this.lblToal.Size = new System.Drawing.Size(87, 17);
            this.lblToal.TabIndex = 88;
            this.lblToal.Text = "Total: 0.00";
            // 
            // llblCopyLastweekTimesheet
            // 
            this.llblCopyLastweekTimesheet.AutoSize = true;
            this.llblCopyLastweekTimesheet.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.llblCopyLastweekTimesheet.Location = new System.Drawing.Point(743, 20);
            this.llblCopyLastweekTimesheet.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.llblCopyLastweekTimesheet.Name = "llblCopyLastweekTimesheet";
            this.llblCopyLastweekTimesheet.Size = new System.Drawing.Size(159, 13);
            this.llblCopyLastweekTimesheet.TabIndex = 87;
            this.llblCopyLastweekTimesheet.TabStop = true;
            this.llblCopyLastweekTimesheet.Text = "Copy Previous Week Timesheet";
            this.llblCopyLastweekTimesheet.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llblCopyLastweekTimesheet_LinkClicked);
            // 
            // chkOveride
            // 
            this.chkOveride.AutoSize = true;
            this.chkOveride.Location = new System.Drawing.Point(388, 51);
            this.chkOveride.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.chkOveride.Name = "chkOveride";
            this.chkOveride.Size = new System.Drawing.Size(63, 17);
            this.chkOveride.TabIndex = 86;
            this.chkOveride.Text = "Overide";
            this.chkOveride.UseVisualStyleBackColor = true;
            this.chkOveride.CheckedChanged += new System.EventHandler(this.chkOveride_CheckedChanged);
            // 
            // btnAllow
            // 
            this.btnAllow.Location = new System.Drawing.Point(746, 50);
            this.btnAllow.Name = "btnAllow";
            this.btnAllow.Size = new System.Drawing.Size(48, 23);
            this.btnAllow.TabIndex = 85;
            this.btnAllow.Text = "Allow";
            this.btnAllow.UseVisualStyleBackColor = true;
            this.btnAllow.Click += new System.EventHandler(this.btnAllow_Click);
            // 
            // cboOverideUser
            // 
            this.cboOverideUser.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboOverideUser.FormattingEnabled = true;
            this.cboOverideUser.Location = new System.Drawing.Point(482, 50);
            this.cboOverideUser.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cboOverideUser.Name = "cboOverideUser";
            this.cboOverideUser.Size = new System.Drawing.Size(248, 21);
            this.cboOverideUser.TabIndex = 84;
            this.cboOverideUser.SelectedIndexChanged += new System.EventHandler(this.cboOverideUser_SelectedIndexChanged);
            // 
            // cboActivityID
            // 
            this.cboActivityID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboActivityID.FormattingEnabled = true;
            this.cboActivityID.Location = new System.Drawing.Point(6, 101);
            this.cboActivityID.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cboActivityID.Name = "cboActivityID";
            this.cboActivityID.Size = new System.Drawing.Size(92, 21);
            this.cboActivityID.TabIndex = 1;
            // 
            // lblDay7
            // 
            this.lblDay7.AutoSize = true;
            this.lblDay7.Location = new System.Drawing.Point(671, 84);
            this.lblDay7.Name = "lblDay7";
            this.lblDay7.Size = new System.Drawing.Size(61, 13);
            this.lblDay7.TabIndex = 82;
            this.lblDay7.Text = "Sun, 11/26";
            // 
            // txtDay7
            // 
            this.txtDay7.Location = new System.Drawing.Point(670, 101);
            this.txtDay7.Name = "txtDay7";
            this.txtDay7.Size = new System.Drawing.Size(59, 19);
            this.txtDay7.TabIndex = 8;
            this.txtDay7.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDay7_KeyPress);
            this.txtDay7.Leave += new System.EventHandler(this.txtDay7_Leave);
            // 
            // lblDay6
            // 
            this.lblDay6.AutoSize = true;
            this.lblDay6.Location = new System.Drawing.Point(579, 84);
            this.lblDay6.Name = "lblDay6";
            this.lblDay6.Size = new System.Drawing.Size(58, 13);
            this.lblDay6.TabIndex = 80;
            this.lblDay6.Text = "Sat, 11/26";
            // 
            // txtDay6
            // 
            this.txtDay6.Location = new System.Drawing.Point(576, 101);
            this.txtDay6.Name = "txtDay6";
            this.txtDay6.Size = new System.Drawing.Size(59, 19);
            this.txtDay6.TabIndex = 7;
            this.txtDay6.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDay6_KeyPress);
            this.txtDay6.Leave += new System.EventHandler(this.txtDay6_Leave);
            // 
            // lblDay5
            // 
            this.lblDay5.AutoSize = true;
            this.lblDay5.Location = new System.Drawing.Point(490, 84);
            this.lblDay5.Name = "lblDay5";
            this.lblDay5.Size = new System.Drawing.Size(53, 13);
            this.lblDay5.TabIndex = 78;
            this.lblDay5.Text = "Fri, 11/26";
            // 
            // txtDay5
            // 
            this.txtDay5.Location = new System.Drawing.Point(482, 101);
            this.txtDay5.Name = "txtDay5";
            this.txtDay5.Size = new System.Drawing.Size(59, 19);
            this.txtDay5.TabIndex = 6;
            this.txtDay5.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDay5_KeyPress);
            this.txtDay5.Leave += new System.EventHandler(this.txtDay5_Leave);
            // 
            // lblDay4
            // 
            this.lblDay4.AutoSize = true;
            this.lblDay4.Location = new System.Drawing.Point(395, 84);
            this.lblDay4.Name = "lblDay4";
            this.lblDay4.Size = new System.Drawing.Size(61, 13);
            this.lblDay4.TabIndex = 76;
            this.lblDay4.Text = "Thu, 11/26";
            // 
            // txtDay4
            // 
            this.txtDay4.Location = new System.Drawing.Point(388, 101);
            this.txtDay4.Name = "txtDay4";
            this.txtDay4.Size = new System.Drawing.Size(59, 19);
            this.txtDay4.TabIndex = 5;
            this.txtDay4.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDay4_KeyPress);
            this.txtDay4.Leave += new System.EventHandler(this.txtDay4_Leave);
            // 
            // lblDay3
            // 
            this.lblDay3.AutoSize = true;
            this.lblDay3.Location = new System.Drawing.Point(297, 83);
            this.lblDay3.Name = "lblDay3";
            this.lblDay3.Size = new System.Drawing.Size(65, 13);
            this.lblDay3.TabIndex = 74;
            this.lblDay3.Text = "Wed, 11/26";
            // 
            // txtDay3
            // 
            this.txtDay3.Location = new System.Drawing.Point(295, 102);
            this.txtDay3.Name = "txtDay3";
            this.txtDay3.Size = new System.Drawing.Size(59, 19);
            this.txtDay3.TabIndex = 4;
            this.txtDay3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDay3_KeyPress);
            this.txtDay3.Leave += new System.EventHandler(this.txtDay3_Leave);
            // 
            // lblDay2
            // 
            this.lblDay2.AutoSize = true;
            this.lblDay2.Location = new System.Drawing.Point(202, 83);
            this.lblDay2.Name = "lblDay2";
            this.lblDay2.Size = new System.Drawing.Size(61, 13);
            this.lblDay2.TabIndex = 72;
            this.lblDay2.Text = "Tue, 11/26";
            // 
            // txtDay2
            // 
            this.txtDay2.Location = new System.Drawing.Point(201, 102);
            this.txtDay2.Name = "txtDay2";
            this.txtDay2.Size = new System.Drawing.Size(59, 19);
            this.txtDay2.TabIndex = 3;
            this.txtDay2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDay2_KeyPress);
            this.txtDay2.Leave += new System.EventHandler(this.txtDay2_Leave);
            // 
            // lblDay1
            // 
            this.lblDay1.AutoSize = true;
            this.lblDay1.Location = new System.Drawing.Point(105, 84);
            this.lblDay1.Name = "lblDay1";
            this.lblDay1.Size = new System.Drawing.Size(63, 13);
            this.lblDay1.TabIndex = 70;
            this.lblDay1.Text = "Mon, 11/26";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(20, 83);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 13);
            this.label2.TabIndex = 69;
            this.label2.Text = "ActivityId";
            // 
            // llblNext
            // 
            this.llblNext.AutoSize = true;
            this.llblNext.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.llblNext.Location = new System.Drawing.Point(272, 26);
            this.llblNext.Name = "llblNext";
            this.llblNext.Size = new System.Drawing.Size(38, 13);
            this.llblNext.TabIndex = 68;
            this.llblNext.TabStop = true;
            this.llblNext.Text = "Next >";
            this.llblNext.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llblNext_LinkClicked);
            // 
            // llblPrevious
            // 
            this.llblPrevious.AutoSize = true;
            this.llblPrevious.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.llblPrevious.Location = new System.Drawing.Point(105, 26);
            this.llblPrevious.Name = "llblPrevious";
            this.llblPrevious.Size = new System.Drawing.Size(57, 13);
            this.llblPrevious.TabIndex = 67;
            this.llblPrevious.TabStop = true;
            this.llblPrevious.Text = "< Previous";
            this.llblPrevious.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llblPrevious_LinkClicked);
            // 
            // lblWeekending
            // 
            this.lblWeekending.AutoSize = true;
            this.lblWeekending.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold);
            this.lblWeekending.ForeColor = System.Drawing.Color.Blue;
            this.lblWeekending.Location = new System.Drawing.Point(167, 26);
            this.lblWeekending.Name = "lblWeekending";
            this.lblWeekending.Size = new System.Drawing.Size(105, 13);
            this.lblWeekending.TabIndex = 50;
            this.lblWeekending.Text = "Sun, 11/26/2018";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 13);
            this.label1.TabIndex = 49;
            this.label1.Text = "WeekEnding ";
            // 
            // lblPPMUserName
            // 
            this.lblPPMUserName.AutoSize = true;
            this.lblPPMUserName.Enabled = false;
            this.lblPPMUserName.ForeColor = System.Drawing.Color.Blue;
            this.lblPPMUserName.Location = new System.Drawing.Point(105, 56);
            this.lblPPMUserName.Name = "lblPPMUserName";
            this.lblPPMUserName.Size = new System.Drawing.Size(57, 13);
            this.lblPPMUserName.TabIndex = 48;
            this.lblPPMUserName.Text = "UserName";
            // 
            // txtDay1
            // 
            this.txtDay1.Location = new System.Drawing.Point(107, 102);
            this.txtDay1.Name = "txtDay1";
            this.txtDay1.Size = new System.Drawing.Size(59, 19);
            this.txtDay1.TabIndex = 2;
            this.txtDay1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDay1_KeyPress);
            this.txtDay1.Leave += new System.EventHandler(this.txtDay1_Leave);
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(28, 56);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(29, 13);
            this.lblName.TabIndex = 40;
            this.lblName.Text = "User";
            // 
            // gridResult
            // 
            this.gridResult.AllowUserToAddRows = false;
            this.gridResult.AllowUserToDeleteRows = false;
            this.gridResult.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.gridResult.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridResult.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridResult.Location = new System.Drawing.Point(0, 0);
            this.gridResult.Name = "gridResult";
            this.gridResult.ReadOnly = true;
            this.gridResult.Size = new System.Drawing.Size(938, 297);
            this.gridResult.TabIndex = 64;
            this.gridResult.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.gridResult_CellFormatting);
            this.gridResult.SelectionChanged += new System.EventHandler(this.gridResult_SelectionChanged);
            // 
            // Result
            // 
            this.Result.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Result.Controls.Add(this.chkIncludeDepartment);
            this.Result.Controls.Add(this.btnAbsenceAll);
            this.Result.Controls.Add(this.btnAbsenceAllByUser);
            this.Result.Controls.Add(this.btnAbsenceByUser);
            this.Result.Controls.Add(this.cboSemiAnnual);
            this.Result.Controls.Add(this.cboQuarter);
            this.Result.Controls.Add(this.rdoYearly);
            this.Result.Controls.Add(this.rdoSemiAnnual);
            this.Result.Controls.Add(this.rdoQuerterly);
            this.Result.Controls.Add(this.panel3);
            this.Result.Controls.Add(this.btnGenerateInvoice);
            this.Result.Controls.Add(this.btnRetriveAll);
            this.Result.Controls.Add(this.btnRetriveAllUser);
            this.Result.Controls.Add(this.btnMonthViewRetrive);
            this.Result.Controls.Add(this.cboYearView);
            this.Result.Controls.Add(this.cboMonthView);
            this.Result.Controls.Add(this.rdoMonthlyView);
            this.Result.Controls.Add(this.rdoWeeklyView);
            this.Result.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.Result.Location = new System.Drawing.Point(3, 204);
            this.Result.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Result.Name = "Result";
            this.Result.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Result.Size = new System.Drawing.Size(947, 405);
            this.Result.TabIndex = 65;
            this.Result.TabStop = false;
            this.Result.Text = "Result";
            this.Result.Enter += new System.EventHandler(this.Result_Enter);
            // 
            // chkIncludeDepartment
            // 
            this.chkIncludeDepartment.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.chkIncludeDepartment.AutoSize = true;
            this.chkIncludeDepartment.Location = new System.Drawing.Point(826, 20);
            this.chkIncludeDepartment.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.chkIncludeDepartment.Name = "chkIncludeDepartment";
            this.chkIncludeDepartment.Size = new System.Drawing.Size(119, 17);
            this.chkIncludeDepartment.TabIndex = 18;
            this.chkIncludeDepartment.Text = "Include Department";
            this.chkIncludeDepartment.UseVisualStyleBackColor = true;
            // 
            // btnAbsenceAll
            // 
            this.btnAbsenceAll.Location = new System.Drawing.Point(660, 63);
            this.btnAbsenceAll.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnAbsenceAll.Name = "btnAbsenceAll";
            this.btnAbsenceAll.Size = new System.Drawing.Size(90, 21);
            this.btnAbsenceAll.TabIndex = 17;
            this.btnAbsenceAll.Text = "AbsenceAll";
            this.btnAbsenceAll.UseVisualStyleBackColor = true;
            this.btnAbsenceAll.Click += new System.EventHandler(this.btnAbsenceAll_Click);
            // 
            // btnAbsenceAllByUser
            // 
            this.btnAbsenceAllByUser.Location = new System.Drawing.Point(548, 64);
            this.btnAbsenceAllByUser.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnAbsenceAllByUser.Name = "btnAbsenceAllByUser";
            this.btnAbsenceAllByUser.Size = new System.Drawing.Size(105, 21);
            this.btnAbsenceAllByUser.TabIndex = 16;
            this.btnAbsenceAllByUser.Text = "AbsenceAll-ByUser";
            this.btnAbsenceAllByUser.UseVisualStyleBackColor = true;
            this.btnAbsenceAllByUser.Click += new System.EventHandler(this.btnAbsenceAllByUser_Click);
            // 
            // btnAbsenceByUser
            // 
            this.btnAbsenceByUser.Location = new System.Drawing.Point(434, 63);
            this.btnAbsenceByUser.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnAbsenceByUser.Name = "btnAbsenceByUser";
            this.btnAbsenceByUser.Size = new System.Drawing.Size(105, 21);
            this.btnAbsenceByUser.TabIndex = 15;
            this.btnAbsenceByUser.Text = "Absence-ByUser";
            this.btnAbsenceByUser.UseVisualStyleBackColor = true;
            this.btnAbsenceByUser.Click += new System.EventHandler(this.btnAbsenceByUser_Click);
            // 
            // cboSemiAnnual
            // 
            this.cboSemiAnnual.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSemiAnnual.FormattingEnabled = true;
            this.cboSemiAnnual.Items.AddRange(new object[] {
            "1st half: Jan To Jun",
            "2nd half: Jul To Dec"});
            this.cboSemiAnnual.Location = new System.Drawing.Point(217, 63);
            this.cboSemiAnnual.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cboSemiAnnual.Name = "cboSemiAnnual";
            this.cboSemiAnnual.Size = new System.Drawing.Size(92, 21);
            this.cboSemiAnnual.TabIndex = 14;
            // 
            // cboQuarter
            // 
            this.cboQuarter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboQuarter.FormattingEnabled = true;
            this.cboQuarter.Items.AddRange(new object[] {
            "Q1: Jan To Mar",
            "Q2: Apr To Jun",
            "Q3: Jul To Sep",
            "Q4: Oct To Dec"});
            this.cboQuarter.Location = new System.Drawing.Point(217, 40);
            this.cboQuarter.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cboQuarter.Name = "cboQuarter";
            this.cboQuarter.Size = new System.Drawing.Size(92, 21);
            this.cboQuarter.TabIndex = 13;
            // 
            // rdoYearly
            // 
            this.rdoYearly.AutoSize = true;
            this.rdoYearly.Location = new System.Drawing.Point(107, 79);
            this.rdoYearly.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.rdoYearly.Name = "rdoYearly";
            this.rdoYearly.Size = new System.Drawing.Size(58, 17);
            this.rdoYearly.TabIndex = 12;
            this.rdoYearly.Text = "Annual";
            this.rdoYearly.UseVisualStyleBackColor = true;
            this.rdoYearly.CheckedChanged += new System.EventHandler(this.rdoYearly_CheckedChanged);
            // 
            // rdoSemiAnnual
            // 
            this.rdoSemiAnnual.AutoSize = true;
            this.rdoSemiAnnual.Location = new System.Drawing.Point(107, 59);
            this.rdoSemiAnnual.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.rdoSemiAnnual.Name = "rdoSemiAnnual";
            this.rdoSemiAnnual.Size = new System.Drawing.Size(84, 17);
            this.rdoSemiAnnual.TabIndex = 11;
            this.rdoSemiAnnual.Text = "Semi-Annual";
            this.rdoSemiAnnual.UseVisualStyleBackColor = true;
            this.rdoSemiAnnual.CheckedChanged += new System.EventHandler(this.rdoSemiAnnual_CheckedChanged);
            // 
            // rdoQuerterly
            // 
            this.rdoQuerterly.AutoSize = true;
            this.rdoQuerterly.Location = new System.Drawing.Point(107, 40);
            this.rdoQuerterly.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.rdoQuerterly.Name = "rdoQuerterly";
            this.rdoQuerterly.Size = new System.Drawing.Size(67, 17);
            this.rdoQuerterly.TabIndex = 10;
            this.rdoQuerterly.Text = "Quarterly";
            this.rdoQuerterly.UseVisualStyleBackColor = true;
            this.rdoQuerterly.CheckedChanged += new System.EventHandler(this.rdoQuerterly_CheckedChanged);
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.Controls.Add(this.gridResult);
            this.panel3.Location = new System.Drawing.Point(5, 102);
            this.panel3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(938, 297);
            this.panel3.TabIndex = 9;
            // 
            // btnGenerateInvoice
            // 
            this.btnGenerateInvoice.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnGenerateInvoice.Location = new System.Drawing.Point(830, 45);
            this.btnGenerateInvoice.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnGenerateInvoice.Name = "btnGenerateInvoice";
            this.btnGenerateInvoice.Size = new System.Drawing.Size(111, 21);
            this.btnGenerateInvoice.TabIndex = 8;
            this.btnGenerateInvoice.Text = "Generate Invoice";
            this.btnGenerateInvoice.UseVisualStyleBackColor = true;
            this.btnGenerateInvoice.Click += new System.EventHandler(this.btnGenerateInvoice_Click);
            // 
            // btnRetriveAll
            // 
            this.btnRetriveAll.Location = new System.Drawing.Point(660, 18);
            this.btnRetriveAll.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnRetriveAll.Name = "btnRetriveAll";
            this.btnRetriveAll.Size = new System.Drawing.Size(90, 21);
            this.btnRetriveAll.TabIndex = 7;
            this.btnRetriveAll.Text = "RetrieveAll";
            this.btnRetriveAll.UseVisualStyleBackColor = true;
            this.btnRetriveAll.Click += new System.EventHandler(this.btnRetriveAll_Click);
            // 
            // btnRetriveAllUser
            // 
            this.btnRetriveAllUser.Location = new System.Drawing.Point(548, 18);
            this.btnRetriveAllUser.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnRetriveAllUser.Name = "btnRetriveAllUser";
            this.btnRetriveAllUser.Size = new System.Drawing.Size(105, 21);
            this.btnRetriveAllUser.TabIndex = 6;
            this.btnRetriveAllUser.Text = "RetrieveAll-ByUser";
            this.btnRetriveAllUser.UseVisualStyleBackColor = true;
            this.btnRetriveAllUser.Click += new System.EventHandler(this.btnRetriveAllUser_Click);
            // 
            // btnMonthViewRetrive
            // 
            this.btnMonthViewRetrive.Location = new System.Drawing.Point(434, 18);
            this.btnMonthViewRetrive.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnMonthViewRetrive.Name = "btnMonthViewRetrive";
            this.btnMonthViewRetrive.Size = new System.Drawing.Size(105, 21);
            this.btnMonthViewRetrive.TabIndex = 4;
            this.btnMonthViewRetrive.Text = "Retrieve-ByUser";
            this.btnMonthViewRetrive.UseVisualStyleBackColor = true;
            this.btnMonthViewRetrive.Click += new System.EventHandler(this.btnMonthViewRetrive_Click);
            // 
            // cboYearView
            // 
            this.cboYearView.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboYearView.FormattingEnabled = true;
            this.cboYearView.Location = new System.Drawing.Point(323, 18);
            this.cboYearView.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cboYearView.Name = "cboYearView";
            this.cboYearView.Size = new System.Drawing.Size(92, 21);
            this.cboYearView.TabIndex = 3;
            // 
            // cboMonthView
            // 
            this.cboMonthView.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboMonthView.FormattingEnabled = true;
            this.cboMonthView.Location = new System.Drawing.Point(217, 18);
            this.cboMonthView.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cboMonthView.Name = "cboMonthView";
            this.cboMonthView.Size = new System.Drawing.Size(92, 21);
            this.cboMonthView.TabIndex = 2;
            // 
            // rdoMonthlyView
            // 
            this.rdoMonthlyView.AutoSize = true;
            this.rdoMonthlyView.Location = new System.Drawing.Point(107, 20);
            this.rdoMonthlyView.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.rdoMonthlyView.Name = "rdoMonthlyView";
            this.rdoMonthlyView.Size = new System.Drawing.Size(88, 17);
            this.rdoMonthlyView.TabIndex = 1;
            this.rdoMonthlyView.Text = "Monthly View";
            this.rdoMonthlyView.UseVisualStyleBackColor = true;
            this.rdoMonthlyView.CheckedChanged += new System.EventHandler(this.rdoMonthlyView_CheckedChanged);
            // 
            // rdoWeeklyView
            // 
            this.rdoWeeklyView.AutoSize = true;
            this.rdoWeeklyView.Checked = true;
            this.rdoWeeklyView.Location = new System.Drawing.Point(13, 20);
            this.rdoWeeklyView.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.rdoWeeklyView.Name = "rdoWeeklyView";
            this.rdoWeeklyView.Size = new System.Drawing.Size(87, 17);
            this.rdoWeeklyView.TabIndex = 0;
            this.rdoWeeklyView.TabStop = true;
            this.rdoWeeklyView.Text = "Weekly View";
            this.rdoWeeklyView.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(17, 617);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(38, 13);
            this.label4.TabIndex = 69;
            this.label4.Text = "Path : ";
            // 
            // txtExportPath
            // 
            this.txtExportPath.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtExportPath.Location = new System.Drawing.Point(50, 614);
            this.txtExportPath.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtExportPath.Name = "txtExportPath";
            this.txtExportPath.Size = new System.Drawing.Size(798, 20);
            this.txtExportPath.TabIndex = 70;
            // 
            // llblExportToExcel
            // 
            this.llblExportToExcel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.llblExportToExcel.AutoSize = true;
            this.llblExportToExcel.Location = new System.Drawing.Point(877, 614);
            this.llblExportToExcel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.llblExportToExcel.Name = "llblExportToExcel";
            this.llblExportToExcel.Size = new System.Drawing.Size(76, 13);
            this.llblExportToExcel.TabIndex = 71;
            this.llblExportToExcel.TabStop = true;
            this.llblExportToExcel.Text = "ExportToExcel";
            this.llblExportToExcel.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llblExportToExcel_LinkClicked);
            // 
            // DMMasterPage
            // 
            this.AcceptButton = this.btnSave;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(953, 668);
            this.Controls.Add(this.llblExportToExcel);
            this.Controls.Add(this.txtExportPath);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Result);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "DMMasterPage";
            this.Text = "LegalITeDiscoveryImportTool";
            this.Load += new System.EventHandler(this.DMMasterPage_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridResult)).EndInit();
            this.Result.ResumeLayout(false);
            this.Result.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblUserName;
        private System.Windows.Forms.Label lblAuditBanner;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblRegion;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtDay1;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblWeekending;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblPPMUserName;
        private System.Windows.Forms.LinkLabel llblNext;
        private System.Windows.Forms.LinkLabel llblPrevious;
        private System.Windows.Forms.ComboBox cboActivityID;
        private System.Windows.Forms.Label lblDay7;
        private System.Windows.Forms.TextBox txtDay7;
        private System.Windows.Forms.Label lblDay6;
        private System.Windows.Forms.TextBox txtDay6;
        private System.Windows.Forms.Label lblDay5;
        private System.Windows.Forms.TextBox txtDay5;
        private System.Windows.Forms.Label lblDay4;
        private System.Windows.Forms.TextBox txtDay4;
        private System.Windows.Forms.Label lblDay3;
        private System.Windows.Forms.TextBox txtDay3;
        private System.Windows.Forms.Label lblDay2;
        private System.Windows.Forms.TextBox txtDay2;
        private System.Windows.Forms.Label lblDay1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView gridResult;
        private System.Windows.Forms.GroupBox Result;
        private System.Windows.Forms.RadioButton rdoMonthlyView;
        private System.Windows.Forms.RadioButton rdoWeeklyView;
        private System.Windows.Forms.ComboBox cboYearView;
        private System.Windows.Forms.ComboBox cboMonthView;
        private System.Windows.Forms.Button btnMonthViewRetrive;
        private System.Windows.Forms.ComboBox cboOverideUser;
        private System.Windows.Forms.CheckBox chkOveride;
        private System.Windows.Forms.Button btnAllow;
        private System.Windows.Forms.LinkLabel llblCopyLastweekTimesheet;
        private System.Windows.Forms.Label lblToal;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtExportPath;
        private System.Windows.Forms.LinkLabel llblExportToExcel;
        private System.Windows.Forms.Button btnGenerateInvoice;
        private System.Windows.Forms.Button btnRetriveAll;
        private System.Windows.Forms.Button btnRetriveAllUser;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.ComboBox cboQuarter;
        private System.Windows.Forms.RadioButton rdoYearly;
        private System.Windows.Forms.RadioButton rdoSemiAnnual;
        private System.Windows.Forms.RadioButton rdoQuerterly;
        private System.Windows.Forms.ComboBox cboSemiAnnual;
        private System.Windows.Forms.Button btnAbsenceAll;
        private System.Windows.Forms.Button btnAbsenceAllByUser;
        private System.Windows.Forms.Button btnAbsenceByUser;
        private System.Windows.Forms.CheckBox chkIncludeDepartment;
        private System.Windows.Forms.LinkLabel llblAddActivity;
        private System.Windows.Forms.LinkLabel lblPSTImport;
    }
}