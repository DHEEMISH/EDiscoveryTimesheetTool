﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace eDiscoverTimeSheet_V1._0.Models.LoginModel
{
    public class Response
    {

        public string Status { set; get; }
        public string Message { set; get; }


        public const string ValidStatus = "Valid";
        public const string InvalidStatus = "Invalid";

    }
}