﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace eDiscoverTimeSheet_V1._0.Models.LoginModel
{
    public class Dashboard
    {
        #region Properties
        public int Id { get; set; }
        public string DomainLogin { get; set; }
    
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }

        public bool isSuperUser { get; set; }
        public string RoleName { get; set; }
        public string DisplayName { get; set; }
         public string RoleDisplay { get; set; }

        public string OfficalEmail { get; set; }

        #endregion
    }
}