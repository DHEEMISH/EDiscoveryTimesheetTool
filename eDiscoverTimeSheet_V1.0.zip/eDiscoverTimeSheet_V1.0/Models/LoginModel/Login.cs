﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using eDiscoverTimeSheet_V1._0.eDiscoveryCommonDTO;
using System.Web.Http;
using System.Data;
using DBOperation.DAL;
using System.Configuration;

namespace eDiscoverTimeSheet_V1._0.Models.LoginModel
{
    public class Login
    {
        //  IDBLoad DBLOAD=new DBLoad();
        public static string GetEnvironemnt
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["Environment"];
            }
        }


        eDiscoveryWorkFlowTempDBEntities DB = new eDiscoveryWorkFlowTempDBEntities();



        //public string IsSuperUser()
        //{
        //    Dashboard resultObj = new Dashboard();
        //    string LoginUser="USER";
        //    string userName = System.Security.Principal.WindowsIdentity.GetCurrent().Name;
        //    try
        //    {
        //        var Obj = DB.t_edis_UserRole.Where(x => x.UserName.Equals(userName.ToLower())).Select(x => new Dashboard() { RoleName = x.RoleName });
        //        if (!(Obj.FirstOrDefault() == null))
        //        {
        //            LoginUser = Obj.FirstOrDefault().RoleName;
        //        }
        //        resultObj.isSuperUser = (LoginUser == "ADMIN");
        //        string env = ConfigurationManager.AppSettings["Environment"];
        //        resultObj.DisplayName = resultObj.isSuperUser ? env + "-ADMIN" : env + "-USER";
        //    }
        //    catch (Exception ex)
        //    {
        //    }
        //    return resultObj.DisplayName;
        //}

        public  static Dashboard CheckLogin(string DomainLogin,int pass)
        {
           Dashboard resultObj = new Dashboard();
            eDiscoveryWorkFlowTempDBEntities DB = new eDiscoveryWorkFlowTempDBEntities();
            string userName = System.Security.Principal.WindowsIdentity.GetCurrent().Name;
            string userDoaminAlias = userName.ToString();
            string[] parts = userDoaminAlias.Split(new char[] { '\\' });
            userName = parts[1];



            if (userDoaminAlias.ToLower().StartsWith("csfb") || userDoaminAlias.ToLower().StartsWith("gbladhedani") || userName.Length > 20)
            {
                // If the Logged in Users domain is GBLADHEDANI or CSFB check only the alias 
                // This allows the user to login in from both domains without any problem
                // userName = userName.Substring(userName.Length - 20);

                string userAlias = userDoaminAlias.Substring(userDoaminAlias.LastIndexOf("\\") + 1);

                //  var Obj = DB.LoginTables.GroupJoin(DB.t_edis_UserRole, x => x.DomainLogin, y => y.UserName, (x, y) => new { x.DomainLogin, y }).Where(x => x.DomainLogin.ToLower().EndsWith(userAlias.ToLower()));

                //  using (eDiscoveryWorkFlowTempDBEntities DB = new eDiscoveryWorkFlowTempDBEntities())
                /// {

                var Obj = DB.Employees
               .Join(DB.LoginTables,
                     emp => emp.PublicDoaminAlias,
                    LoginTbles => LoginTbles.DomainLogin,
                     (emp, LoginTbles) => new { emp, LoginTbles })
               .Join(DB.t_edis_UserRole,
                     empo => empo.emp.PublicDoaminAlias,
                     userrole => userrole.UserName,

                     (empo, userrole) => new { empo, userrole }).Where(x => x.empo.LoginTbles.DomainLogin.ToLower().EndsWith(userAlias.ToLower()))
               .Select(z => new
               {
                   DomainLogin = z.empo.LoginTbles.DomainLogin,
                   PublicDoaminAlias = z.empo.emp.PublicDoaminAlias,
                   Displayname = z.empo.emp.DisplayName,
                 pass= z.empo.LoginTbles.Id,
                       OfficeEMAIL = z.empo.emp.OfficeEmail,
                       UserName = z.userrole.UserName,
                       RoleName = z.userrole.RoleName
                   }).ToList();



                    if (Obj.FirstOrDefault() != null)
                    {
                     var row = Obj.FirstOrDefault();
                   // resultObj.DomainLogin = userAlias;
                    resultObj.DomainLogin = row.DomainLogin;
                    string[] dl= resultObj.DomainLogin.Split(new char[] { '\\' });
                    userName = dl[1];
                    resultObj.Id = pass;
                    resultObj.DomainLogin = userName;
                    resultObj.RoleName = row.RoleName;
                    resultObj.DisplayName = row.Displayname;
                        //   resultObj.DisplayName = "Grant, Christine (MICL 781) CWR";
                        resultObj.OfficalEmail = row.OfficeEMAIL;


                        if (resultObj.RoleName == "ADMIN")
                        { 
                            resultObj.isSuperUser = true;
                        }


                    }
               // }
                  
              
            }
            string env = ConfigurationManager.AppSettings["Environment"];
            resultObj.RoleDisplay = resultObj.isSuperUser ? env + "-ADMIN" : env + "-USER";
            //  return resultObj;
            return resultObj;
        }


     

    }
}

