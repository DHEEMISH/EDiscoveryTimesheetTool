﻿using DBOperation;
using DBOperation.DAL;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using eDiscoverTimeSheet_V1._0.eDiscoveryCommonDTO;
using System.Data.SqlClient;

namespace eDiscoverTimeSheet_V1._0.Models.LoginModel
{

   

    public class Activity
    {

        TimesheetActivity tsv = new TimesheetActivity();
        eDiscoveryWorkFlowTempDBEntities DB = new eDiscoveryWorkFlowTempDBEntities();
        //string conString = EncryptionUtility.Decrypt(ConfigurationManager.AppSettings[ConfigurationManager.AppSettings["Environment"] + "_ConnectionString"]);
        string ApplyActivityIdFilter = ConfigurationManager.AppSettings["ApplyActivityIdFilter"];
        //Logger.WriteLogEntry("conString:" + conString, "conString", Enum.MessageType.Information);
        //Logger.WriteLogEntry("Run User Name:" + this.lblUserName.Text, "Run User Name", Enum.MessageType.Information);


        string userName = System.Security.Principal.WindowsIdentity.GetCurrent().Name;
        DateTime dtWeekEndingGlobal = DateTime.Now;
        IDBLoad DBLoad;
        public Activity()
        {
            DBLoad = new DBLoad();
            //  DBLoad = new OracleDBLoad();
        }

    



        public DataTable LoadWeekEnding()
        {
           
            DataTable dt = null;
            try
            {
                double start = 7 - (int)DateTime.Now.DayOfWeek;
                DateTime dtWeekEnding = DateTime.Now.AddDays(start);

                dtWeekEndingGlobal = dtWeekEnding;
                dt =  SetWeekEndingFormat(tsv);
            }
            catch (Exception ex)
            {
                Logger.WriteLogEntry("Error in LoadWeekEnding", "Error in LoadWeekEnding", ex, DBOperation.Enum.MessageType.Error);
            }
            return dt;
        }


        public DataTable SetWeekEndingFormat(TimesheetActivity tsv)
        {
            DataTable table = new DataTable("Loadweekendending");
            DataTable dtCloned = null;
            try
            {
                tsv.lblWEEKENDID = dtWeekEndingGlobal.DayOfWeek.ToString().Substring(0, 3) + "," + dtWeekEndingGlobal.Month + "/" + dtWeekEndingGlobal.Day + "/" + dtWeekEndingGlobal.Year;
                tsv.lblDAY1= dtWeekEndingGlobal.AddDays(0).DayOfWeek.ToString().Substring(0, 3) + "," + dtWeekEndingGlobal.AddDays(0).Month.ToString() + "/" + dtWeekEndingGlobal.AddDays(0).Day.ToString();
                tsv.lblDAY2 = dtWeekEndingGlobal.AddDays(-1).DayOfWeek.ToString().Substring(0, 3) + "," + dtWeekEndingGlobal.AddDays(-1).Month.ToString() + "/" + dtWeekEndingGlobal.AddDays(-1).Day.ToString();
                tsv.lblDAY3 = dtWeekEndingGlobal.AddDays(-2).DayOfWeek.ToString().Substring(0, 3) + "," + dtWeekEndingGlobal.AddDays(-2).Month.ToString() + "/" + dtWeekEndingGlobal.AddDays(-2).Day.ToString();
                tsv.lblDAY4 = dtWeekEndingGlobal.AddDays(-3).DayOfWeek.ToString().Substring(0, 3) + "," + dtWeekEndingGlobal.AddDays(-3).Month.ToString() + "/" + dtWeekEndingGlobal.AddDays(-3).Day.ToString();
                tsv.lblDAY5 = dtWeekEndingGlobal.AddDays(-4).DayOfWeek.ToString().Substring(0, 3) + "," + dtWeekEndingGlobal.AddDays(-4).Month.ToString() + "/" + dtWeekEndingGlobal.AddDays(-4).Day.ToString();
                tsv.lblDAY6 = dtWeekEndingGlobal.AddDays(-5).DayOfWeek.ToString().Substring(0, 3) + "," + dtWeekEndingGlobal.AddDays(-5).Month.ToString() + "/" + dtWeekEndingGlobal.AddDays(-5).Day.ToString();
                tsv.lblDAY7 = dtWeekEndingGlobal.AddDays(-6).DayOfWeek.ToString().Substring(0, 3) + "," + dtWeekEndingGlobal.AddDays(-6).Month.ToString() + "/" + dtWeekEndingGlobal.AddDays(-6).Day.ToString();


                table.Rows.Add(tsv.lblDAY1);
                table.Rows.Add(tsv.lblDAY2);
                table.Rows.Add(tsv.lblDAY3);
                table.Rows.Add(tsv.lblDAY4);
                table.Rows.Add(tsv.lblDAY5);
                table.Rows.Add(tsv.lblDAY6);
                table.Rows.Add(tsv.lblDAY7);
                table.Rows.Add(tsv.lblWEEKENDID);
                 dtCloned = table.Clone();
            }
            catch (Exception ex)
            {
                Logger.WriteLogEntry("Error in SetWeekEndingFormat", "Error in SetWeekEndingFormat", ex, DBOperation.Enum.MessageType.Error);
            }
            return dtCloned;
        }
       
        public DataTable LoadActivityId(bool activityfilter)
        {
           
            DataTable activitydata = new DataTable();
            try
            {

                string start = string.Empty;
                string end = string.Empty;

                DateTime dtend = this.dtWeekEndingGlobal.AddMonths(1);
                DateTime dtstart = dtend.AddMonths(-3);


                start = dtstart.Year + "-" + dtstart.Month + "-1";
                end = dtend.Year + "-" + dtend.Month + "-1";

                string query = string.Empty;

                if (activityfilter)
                {
                    query = @"  select absence_Id as CaseID from t_edis_absence_lookup 
                                union
                                SELECT DISTINCT CONVERT(varchar, Investigation.Id) as CaseID FROM Restores
                                INNER JOIN InvUserMsgTypes  ON InvUserMsgTypes.GroupId = Restores.InvUserGroupId INNER JOIN InvAssignmentUser on InvAssignmentUser.id = InvUserMsgTypes.InvUserId INNER JOIN InvAssignment ON InvAssignment.Id = InvAssignmentUser.InvAssignId 
                                INNER JOIN Investigation ON Investigation.Id = InvAssignment.InvID INNER JOIN InvUserMsgTypeGroup ON InvUserMsgTypes.GroupId = InvUserMsgTypeGroup.Id left JOIN LCDPeople ON Investigation.LCDSponsorId = LCDPeople.Id 
                                INNER JOIN Employees ON InvAssignment.ProjectCordinatorId = Employees.Id 
                                INNER JOIN EDiscoveryMsgTypes ON InvUserMsgTypes.InvUserMsgTypeID = EDiscoveryMsgTypes.Id AND InvUserMsgTypeGroup.MsgTypeId = EDiscoveryMsgTypes.Id 
                                INNER JOIN LCDRequest on LCDRequest.Id = invassignment.LCDRequestId 
                                WHERE (Restores.CreatedOn between '" + start + "' and '" + end + "' or LCDRequest.CreatedOn between '" + start + "' and '" + end + @"')
                                union
                                select CaseID from t_dis_Case_Investigation
                                order by CaseID desc";



                }
                else
                {
                    query = @"
                                select absence_Id as CaseID from t_edis_absence_lookup 
                                union
                                SELECT DISTINCT CONVERT(varchar, Investigation.Id) as CaseID FROM Restores
                                INNER JOIN InvUserMsgTypes  ON InvUserMsgTypes.GroupId = Restores.InvUserGroupId INNER JOIN InvAssignmentUser on InvAssignmentUser.id = InvUserMsgTypes.InvUserId INNER JOIN InvAssignment ON InvAssignment.Id = InvAssignmentUser.InvAssignId 
                                INNER JOIN Investigation ON Investigation.Id = InvAssignment.InvID INNER JOIN InvUserMsgTypeGroup ON InvUserMsgTypes.GroupId = InvUserMsgTypeGroup.Id left JOIN LCDPeople ON Investigation.LCDSponsorId = LCDPeople.Id 
                                INNER JOIN Employees ON InvAssignment.ProjectCordinatorId = Employees.Id 
                                INNER JOIN EDiscoveryMsgTypes ON InvUserMsgTypes.InvUserMsgTypeID = EDiscoveryMsgTypes.Id AND InvUserMsgTypeGroup.MsgTypeId = EDiscoveryMsgTypes.Id 
                                INNER JOIN LCDRequest on LCDRequest.Id = invassignment.LCDRequestId 
                                union
                                select CaseID from t_dis_Case_Investigation
                                order by CaseID desc";
                }


                activitydata = DBLoad.LoadDBTableSQL(query);
            }
            catch (Exception ex)
            {
                // result = false;
                //Logger.WriteLogEntry("Error in LoadActivityId", "Error in LoadActivityId", ex, Response.Message);
            }
            return activitydata;
        }


        public DataTable LoadOverideUser()
        {
            DataTable dt = null;
            try
            {

                string query = @"select PublicDoaminAlias as USERS from Employees where isactive = 1";

               dt=  DBLoad.LoadDBTableSQL(query);

                // this.lblPPMUserName.Text = System.Security.Principal.WindowsIdentity.GetCurrent().Name;
               // this.LoadActivityId();
                this.LoadResultGrid();
            }


            catch (Exception ex)
            {
                //  Logger.WriteLogEntry("Error in LoadOverideUser", "Error in LoadOverideUser", ex, Enum.MessageType.Error);
            }
            return dt;
        }


        bool isSuperUser = false;
        private bool IsSuperUser()
        {
            try
            {
                string query = @"select RoleName from dbo.t_edis_UserRole where USERNAME = '" + userName+ "'";

                DataTable dtTable = DBLoad.LoadDBTableSQL(query);
                if (dtTable.Rows.Count > 0)
                {
                    string LoginUser = dtTable.Rows[0][0].ToString();
                    isSuperUser = (LoginUser == "ADMIN");
                }

            }
            catch (Exception ex)
            {
                Logger.WriteLogEntry("Error in IsSuperUser", "Error in IsSuperUser", ex, DBOperation.Enum.MessageType.Error);
               
            }
            return isSuperUser;
        }


        private void llblNext_LinkClicked()
        {
            try
            {
                dtWeekEndingGlobal = dtWeekEndingGlobal.AddDays(7);
                SetWeekEndingFormat(tsv);
                LoadResultGrid();
               // LoadActivityId();
            }
            catch (Exception ex)
            {
                Logger.WriteLogEntry("Error in llblNext_LinkClicked", "Error in llblNext_LinkClicked", ex, DBOperation.Enum.MessageType.Error);

            }

        }

        private void llblPrevious_LinkClicked()
        {
            TimesheetActivity tsv = new TimesheetActivity();
            try
            {
                dtWeekEndingGlobal = dtWeekEndingGlobal.AddDays(-7);
                SetWeekEndingFormat(tsv);
                LoadResultGrid();
               // LoadActivityId();
            }
            catch (Exception ex)
            {
                Logger.WriteLogEntry("Error in llblPrevious_LinkClicked", "Error in llblPrevious_LinkClicked", ex, DBOperation.Enum.MessageType.Error);

            }

        }

        public DataTable LoadResultGrid()
        {
            TimesheetActivity tsv = new TimesheetActivity();
            DataTable dt = null;
            try
            {


             dt=   PopulateWeeklyTotal(tsv);

            }
            catch (Exception ex)
            {
                // Logger.WriteLogEntry("Error in LoadResultGrid", "Error in LoadResultGrid", ex, Enum.MessageType.Error);
            }
            return dt;
        }

        public DataTable PopulateWeeklyTotal(TimesheetActivity tsv)
        {
            DataTable dtTable = null;
            try
            {

                dtTable = DBLoad.LoadDBTableSQL(@"SELECT CaseID as 'Activity Id', Day1 AS '" +tsv.lblDAY1.Replace(",", " | ") + "', Day2 AS '" + tsv.lblDAY2.Replace(",", " | ") + "', Day3 AS '" + tsv.lblDAY3.Replace(",", " | ") + "',Day4 AS '" + tsv.lblDAY4.Replace(",", " | ") + "',Day5 AS '" + tsv.lblDAY5.Replace(",", " | ") + "',Day6 AS '" + tsv.lblDAY6.Replace(",", " | ") + "',Day7 AS '" + tsv.lblDAY7.Replace(",", " | ") + "', (Day1 + Day2 + Day3 + Day4 + Day5 + Day6 + Day7) as 'Total', CreatedBy as 'LastUpdateBy', CreatedDate as 'LastUpdateDate' from  T_EDIS_TIMESHEET where WeekEnd_ID = " + this.dtWeekEndingGlobal.Month.ToString("D2") + this.dtWeekEndingGlobal.Day.ToString("D2") + this.dtWeekEndingGlobal.Year.ToString("D4") + " and UserName = '" + userName + "'");
               // string query = @"SELECT CaseID as 'Activity Id' ,Day1 AS (Mon |),Day2 AS (Tue |),Day3 AS (Wed |),Day4 AS (Thu |),Day5 AS (Fri |),Day6 AS (Sat |),Day7 AS (Sun |),, CreatedBy as 'LastUpdateBy', CreatedDate as 'LastUpdateDate' from  T_EDIS_TIMESHEET where WeekEnd_ID = "
                   // + this.dtWeekEndingGlobal.Month.ToString("D2") + this.dtWeekEndingGlobal.Day.ToString("D2") + this.dtWeekEndingGlobal.Year.ToString("D4") + " and UserName = '" + userName + "'";

             //   dtTable = DBLoad.LoadDBTableSQL(query);
                if (dtTable.Rows.Count > 0)
                {
                    DataRow dr = null;
                    dr = dtTable.NewRow();
                    double day1 = 0;
                    double day2 = 0;
                    double day3 = 0;
                    double day4 = 0;
                    double day5 = 0;
                    double day6 = 0;
                    double day7 = 0;
                    double Total = 0;
                    for (int i = 0; i < dtTable.Rows.Count; i++)
                    {
                        day1 = day1 + Convert.ToDouble(dtTable.Rows[i][1]);
                        day2 = day2 + Convert.ToDouble(dtTable.Rows[i][2]);
                        day3 = day3 + Convert.ToDouble(dtTable.Rows[i][3]);
                        day4 = day4 + Convert.ToDouble(dtTable.Rows[i][4]);
                        day5 = day5 + Convert.ToDouble(dtTable.Rows[i][5]);
                        day6 = day6 + Convert.ToDouble(dtTable.Rows[i][6]);
                        day7 = day7 + Convert.ToDouble(dtTable.Rows[i][7]);
                        Total = Total + Convert.ToDouble(dtTable.Rows[i][8]);
                    }
                    dr[0] = "Total:";
                    dr[1] = day1;
                    dr[2] = day2;
                    dr[3] = day3;
                    dr[4] = day4;
                    dr[5] = day5;
                    dr[6] = day6;
                    dr[7] = day7;
                    dr[8] = Total;
                    dr[9] = "eDis-Timesheet Tool";
                    dr[10] = DateTime.Now;

                    dtTable.Rows.Add(dr);
                    dtTable.AcceptChanges();
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLogEntry("Error in PopulateWeeklyTotal", "Error in PopulateWeeklyTotal", ex, DBOperation.Enum.MessageType.Error);
            }

            return dtTable;

        }
        public DataTable GenerateInvoice(ResultView rv)
        {
            DataTable dtcreate = null;

            Regex SelectRegex = new Regex(@"[0-9]+%", RegexOptions.Compiled);
            try
            {
                string start = string.Empty;
                string end = string.Empty;
                string cboYearView = "";
                //string cboMonthView = "";
                //string cboQuarter = "";
                //string cboSemiAnnual = "";
                //bool rdoSemiAnnual = false;
                //bool rdoMonthlyView = false;
                //bool rdoQuerterly = false;
                //bool rdoYearly = false;
                bool chkIncludeDepartment = false;
                DateTime dtstart = new DateTime();
                DateTime dtend = new DateTime();





                int year = Convert.ToInt32(cboYearView);
                if (rv.rdoMonthlyView)
                {
                    dtstart = new DateTime(year, Convert.ToInt32(rv.cboMonthView), 1);
                    dtend = dtstart.AddMonths(1);
                    start = dtstart.Year + "-" + dtstart.Month + "-1";
                    end = dtend.Year + "-" + dtend.Month + "-1";
                }

                if (rv.rdoQuerterly)
                {
                    if (rv.cboQuarter.StartsWith("Q1"))
                    {
                        dtstart = new DateTime(year, 1, 1);
                    }
                    if (rv.cboQuarter.StartsWith("Q2"))
                    {
                        dtstart = new DateTime(year, 4, 1);
                    }
                    if (rv.cboQuarter.StartsWith("Q3"))
                    {
                        dtstart = new DateTime(year, 7, 1);
                    }
                    if (rv.cboQuarter.StartsWith("Q4"))
                    {
                        dtstart = new DateTime(year, 10, 1);
                    }

                    dtend = dtstart.AddMonths(3);
                    start = dtstart.Year + "-" + dtstart.Month + "-1";
                    end = dtend.Year + "-" + dtend.Month + "-1";
                }


                if (rv.rdoSemiAnnual)
                {
                    if (rv.cboSemiAnnual.Contains("Jan"))
                    {
                        dtstart = new DateTime(year, 1, 1);
                    }
                    if (rv.cboSemiAnnual.Contains("Dec"))
                    {
                        dtstart = new DateTime(year, 7, 1);
                    }
                    dtend = dtstart.AddMonths(6);
                    start = dtstart.Year + "-" + dtstart.Month + "-1";
                    end = dtend.Year + "-" + dtend.Month + "-1";
                }

                if (rv.rdoYearly)
                {
                    dtstart = new DateTime(year, 1, 1);
                    dtend = dtstart.AddMonths(12);
                    start = dtstart.Year + "-" + dtstart.Month + "-1";
                    end = dtend.Year + "-" + dtend.Month + "-1";
                }

                string query = @"SELECT DISTINCT CONVERT(varchar, Investigation.Id) as CaseID ,Investigation.InvName as SSCCKK_invname,0 Hours,  Investigation.ProjectWebId,
                                Pl.LCDPersonDisplayName as [Primary LCD Requestor] ,
                                (SELECT LCDPersonDisplayName from dbo.LCDPeople where id = Investigation.LCDSponAsistantId) as [Secondary LCD Requestor],'' as Department, Investigation.CostCode as Account, Investigation.CostBreakDown as [Cost Center] 
                                ,bu.businessunit ,'AMER' as Location,''  Comments
                                from Restores
                                INNER JOIN InvUserMsgTypes  ON InvUserMsgTypes.GroupId = Restores.InvUserGroupId INNER JOIN InvAssignmentUser on InvAssignmentUser.id = InvUserMsgTypes.InvUserId INNER JOIN InvAssignment ON InvAssignment.Id = InvAssignmentUser.InvAssignId 
                                INNER JOIN Investigation ON Investigation.Id = InvAssignment.InvID INNER JOIN InvUserMsgTypeGroup ON InvUserMsgTypes.GroupId = InvUserMsgTypeGroup.Id left JOIN LCDPeople ON Investigation.LCDSponsorId = LCDPeople.Id 
                                INNER JOIN Employees ON InvAssignment.ProjectCordinatorId = Employees.Id 
                                INNER JOIN EDiscoveryMsgTypes ON InvUserMsgTypes.InvUserMsgTypeID = EDiscoveryMsgTypes.Id AND InvUserMsgTypeGroup.MsgTypeId = EDiscoveryMsgTypes.Id 
                                INNER JOIN LCDRequest on LCDRequest.Id = invassignment.LCDRequestId 
                                LEFT JOIN LCDPeople Pl ON Pl.Id = Investigation.LCDSponsorId
                                --LEFT JOIN t_dis_businessunit bu ON bu.CostCode = Investigation.CostBreakDown AND Investigation.CostBreakDown != '' 
                                LEFT JOIN t_dis_businessunit bu ON bu.CostCode = (CASE WHEN(CHARINDEX(',', Investigation.CostBreakDown)) > 0 THEN
                                    LTRIM(RTRIM(SUBSTRING(Investigation.CostBreakDown, 1, CHARINDEX(',', Investigation.CostBreakDown) - 1))) ELSE Investigation.CostBreakDown END) AND Investigation.CostBreakDown != '';

                                --WHERE Restores.CreatedOn between '" + start + "' and '" + end + "' or LCDRequest.CreatedOn between '" + start + "' and '" + end + "'";

                DataTable dtMaster = DecryptSQLQuery.LoadDecryptSQLQuery(query,DBLoad.GetWFConnectionString());



                string querySecondary = @"select ci.*, bu.BusinessUnit  from t_dis_Case_Investigation ci
                                          LEFT JOIN t_dis_businessunit bu ON bu.CostCode = ci.Account AND ci.Account != ''";

                DataTable dtMasterSecondary = DBLoad.LoadDBTableSQL(querySecondary);

                DataTable dtHours = GetMonthlyViewTable(false, false, false,rv);

                DataTable dtDepartment = null;
                if (chkIncludeDepartment)
                {
                    //string queryDepartment = @"SELECT T.RequestorName,dt.Department FROM (
                    //                        SELECT RequestorName,department DeptCode FROM ( 
                    //                        SELECT first_name + ' ' + last_name RequestorName,department,ROW_NUMBER() OVER(PARTITION BY first_name,last_name ORDER BY last_updated DESC)RowNo FROM ADS_HEDANI_GAL_TB WHERE first_name IS NOT NULL AND last_name IS NOT NULL
                    //                        AND first_name + ' ' + last_name  IN (    
                    //                        SELECT DISTINCT Pl.LCDPersonDisplayName as [Primary LCD Requestor] 
                    //                                                                        from Restores
                    //                                                        INNER JOIN InvUserMsgTypes  ON InvUserMsgTypes.GroupId = Restores.InvUserGroupId INNER JOIN InvAssignmentUser on InvAssignmentUser.id = InvUserMsgTypes.InvUserId INNER JOIN InvAssignment ON InvAssignment.Id = InvAssignmentUser.InvAssignId 
                    //                                                        INNER JOIN Investigation ON Investigation.Id = InvAssignment.InvID INNER JOIN InvUserMsgTypeGroup ON InvUserMsgTypes.GroupId = InvUserMsgTypeGroup.Id left JOIN LCDPeople ON Investigation.LCDSponsorId = LCDPeople.Id 
                    //                                                        INNER JOIN Employees ON InvAssignment.ProjectCordinatorId = Employees.Id 
                    //                                                        INNER JOIN EDiscoveryMsgTypes ON InvUserMsgTypes.InvUserMsgTypeID = EDiscoveryMsgTypes.Id AND InvUserMsgTypeGroup.MsgTypeId = EDiscoveryMsgTypes.Id 
                    //                                                        INNER JOIN LCDRequest on LCDRequest.Id = invassignment.LCDRequestId 
                    //                                                        LEFT JOIN LCDPeople Pl ON Pl.Id = Investigation.LCDSponsorId ))sT WHERE sT.RowNo = 1 )T INNER JOIN t_edis_Department Dt ON Dt.OECode = T.DeptCode ";
                    //WHERE Restores.CreatedOn between '" + start + "' and '" + end + "' or LCDRequest.CreatedOn between '" + start + "' and '" + end + "'))sT WHERE sT.RowNo = 1 )T INNER JOIN t_edis_Department Dt ON Dt.OECode = T.DeptCode ";


                    string queryDepartment = @"SELECT T.RequestorName,dt.Department FROM (
                                            SELECT RequestorName,department DeptCode FROM ( 
                                            SELECT first_name + ' ' + last_name RequestorName,department,ROW_NUMBER() OVER(PARTITION BY first_name,last_name ORDER BY last_updated DESC)RowNo FROM ADS_HEDANI_GAL_TB WHERE first_name IS NOT NULL AND last_name IS NOT NULL
                                            AND first_name + ' ' + last_name  IN (    
                                            SELECT DISTINCT Pl.LCDPersonDisplayName as [Primary LCD Requestor] 
                                                    from Restores
                                                    INNER JOIN InvUserMsgTypes  ON InvUserMsgTypes.GroupId = Restores.InvUserGroupId INNER JOIN InvAssignmentUser on InvAssignmentUser.id = InvUserMsgTypes.InvUserId INNER JOIN InvAssignment ON InvAssignment.Id = InvAssignmentUser.InvAssignId 
                                                    INNER JOIN Investigation ON Investigation.Id = InvAssignment.InvID INNER JOIN InvUserMsgTypeGroup ON InvUserMsgTypes.GroupId = InvUserMsgTypeGroup.Id left JOIN LCDPeople ON Investigation.LCDSponsorId = LCDPeople.Id 
                                                    INNER JOIN Employees ON InvAssignment.ProjectCordinatorId = Employees.Id 
                                                    INNER JOIN EDiscoveryMsgTypes ON InvUserMsgTypes.InvUserMsgTypeID = EDiscoveryMsgTypes.Id AND InvUserMsgTypeGroup.MsgTypeId = EDiscoveryMsgTypes.Id 
                                                    INNER JOIN LCDRequest on LCDRequest.Id = invassignment.LCDRequestId 
                                                    LEFT JOIN LCDPeople Pl ON Pl.Id = Investigation.LCDSponsorId )
                                                    )sT WHERE sT.RowNo = 1 
                                                    UNION 
                                                    SELECT RequestorName,department FROM (
                                                                              SELECT first_name + ' ' + last_name RequestorName,department,ROW_NUMBER() OVER(PARTITION BY first_name,last_name ORDER BY last_updated DESC)RowNo FROM ADS_HEDANI_GAL_TB WHERE first_name IS NOT NULL AND last_name IS NOT NULL
                                                                              AND first_name + ' ' + last_name  IN (SELECT DISTINCT PrimaryRequestor FROM t_dis_Case_Investigation ))T1 WHERE T1.RowNo = 1
                                                    
                                                    )T INNER JOIN t_edis_Department Dt ON Dt.OECode = T.DeptCode";

                    dtDepartment = DBLoad.LoadDBTableSQL(queryDepartment);
                }

                 dtcreate = CreateInvoiceReport(dtMaster, dtHours, dtDepartment, dtMasterSecondary);


                //   this.gridResult.DataSource = CreateInvoiceReport(dtMaster, dtHours, dtDepartment, dtMasterSecondary);
            }
            catch (Exception ex)
            {
                Logger.WriteLogEntry("Error in llblGenerateInvoice_LinkClicked", "Error in llblGenerateInvoice_LinkClicked", ex, DBOperation.Enum.MessageType.Error);
               
            }
            return dtcreate;

        }


        private void LoadMonthDropDown()
        {
            try
            {
                string query = @"Select distinct month(WeekEndDate) as MONTHNUMBER from T_EDIS_TIMESHEET order by MONTHNUMBER";

                     DBLoad.LoadDBTableSQL(query);
               

               

                string queryYear = @"Select distinct YEAR(WeekEndDate) AS YEARNUMBER from T_EDIS_TIMESHEET order by YEARNUMBER desc";

                DBLoad.LoadDBTableSQL(queryYear);
                


            }
            catch (Exception ex)
            {
                Logger.WriteLogEntry("Error in LoadActivityId", "Error in LoadActivityId", ex, DBOperation.Enum.MessageType.Error);
            }

        }


        private DataTable LoadMonthlyView(bool currentUserOnly, bool isUserbasedPull, bool isAbsenceView,ResultView rv)
        {
            DataTable dt = null;
            try
            {
           dt=   GetMonthlyViewTable(currentUserOnly, isUserbasedPull, isAbsenceView,rv); ;
            }
            catch (Exception ex)
            {
                Logger.WriteLogEntry("Error in LoadResultGrid", "Error in LoadResultGrid", ex, DBOperation.Enum.MessageType.Error);
            }
            return dt;
        }
        public void AddRecord()
        {
            try
            {
               
                string query = string.Empty;

                query = "Exec speDiscTimeSheet @weekendDate = IP_WEEKENDDATE, @weekendId = IPWEEKENDID, @caseId = IPCASEID, @userName = IPUSERNAME, @day1 = IPDAY1 , @day2 = IPDAY2, @day3 = IPDAY3, @day4 = IPDAY4, @day5 = IPDAY5, @day6 = IPDAY6, @day7 = IPDAY7, @CreatedBy = IPCREATEBY";
                query = query.Replace("IP_WEEKENDDATE", "'" + this.dtWeekEndingGlobal.ToShortDateString() + "'");
                query = query.Replace("IPWEEKENDID", "'" + this.dtWeekEndingGlobal.Month.ToString("D2") + this.dtWeekEndingGlobal.Day.ToString("D2") + this.dtWeekEndingGlobal.Year.ToString("D4") + "'");
                query = query.Replace("IPCASEID", "'");
                query = query.Replace("IPUSERNAME", "'");
                query = query.Replace("IPDAY1", "'");
                query = query.Replace("IPDAY2", "'");
                query = query.Replace("IPDAY3", "'");
                query = query.Replace("IPDAY4", "'");
                query = query.Replace("IPDAY5", "'");
                query = query.Replace("IPDAY6", "'");
                query = query.Replace("IPDAY7", "'");
                query = query.Replace("IPCREATEBY", "'");
                DBLoad.ExecuteNonQuery(query);
                this.LoadResultGrid();

            }
            catch (Exception ex)
            {
                Logger.WriteLogEntry("Error in AddRecord", "Error in AddRecord", ex, DBOperation.Enum.MessageType.Error);
            }

        }


        private void CopyLastWeekTimesheet()
        {
            try
            {
                string query = string.Empty;

                query = "Exec speDiscCopyTimeSheet @copyWeekEndId = IP_COPYWEEKENDID, @currentWeekEndId = IP_CURRENTWEEKENDID, @currentWeekEndDate = IP_CURRENTWEEKENDDATE, @userName = IPUSERNAME, @CreatedBy = IPCREATEBY";


                query = query.Replace("IP_CURRENTWEEKENDDATE", "'" + this.dtWeekEndingGlobal.ToShortDateString() + "'");
                query = query.Replace("IP_CURRENTWEEKENDID", "'" + this.dtWeekEndingGlobal.Month.ToString("D2") + this.dtWeekEndingGlobal.Day.ToString("D2") + this.dtWeekEndingGlobal.Year.ToString("D4") + "'");
                query = query.Replace("IP_COPYWEEKENDID", "'" + this.dtWeekEndingGlobal.AddDays(-7).Month.ToString("D2") + this.dtWeekEndingGlobal.AddDays(-7).Day.ToString("D2") + this.dtWeekEndingGlobal.AddDays(-7).Year.ToString("D4") + "'");
                query = query.Replace("IPUSERNAME", "'" + userName+ "'");
                query = query.Replace("IPCREATEBY", "'" + userName + "'");

                DBLoad.ExecuteNonQuery(query);
                this.LoadResultGrid();
            }
            catch (Exception ex)
            {
                Logger.WriteLogEntry("Error in CopyLastWeekTimesheet", "Error in CopyLastWeekTimesheet", ex, DBOperation.Enum.MessageType.Error);
               
            }

        }
        private void UpdateTotal()
        {
            try
            {
                try
                {
                  //  decimal total = GetNumberValue(this.txtDay1) + GetNumberValue(this.txtDay2) + GetNumberValue(this.txtDay3) + GetNumberValue(this.txtDay4) + GetNumberValue(this.txtDay5) + GetNumberValue(this.txtDay6) + GetNumberValue(this.txtDay7);
                    //this.lblToal.Text = "Total:" + total + " Hours";
                   // this.lblToal.ForeColor = Color.Green;
                    //if (total > 40)
                    //{
                    //   // this.lblToal.ForeColor = Color.Red;
                    //}
                }
                catch { }

            }
            catch (Exception ex)
            {
                Logger.WriteLogEntry("Error in UpdateTotal", "Error in UpdateTotal", ex, DBOperation.Enum.MessageType.Error);
            }

        }

        //private decimal GetNumberValue(TextBox textBox)
        //{
        //    decimal valueDec = 0;
        //    try
        //    {
        //        valueDec = decimal.Parse(textBox.Text);

        //    }
        //    catch { }
        //    {
        //    }

        //    return valueDec;
        //}

        private DataTable GetMonthlyViewTable(bool currentUserOnly, bool isUserbasedPull, bool isAbsenceView,ResultView rv)
        {

            //string quater1 = "Q1";
            //string quater2 = "Q2";
            //string quater3 = "Q3";
            //string quater4 = "Q4";
            int CycleLength = 0;


            //string cboSemiAnnual = "Jan";
            
            //string cboYearView="";
            //string cboMonthView= "";

            //bool rdoSemiAnnual = false;

            //bool rdoYearly = false;
            DataTable dtTable = null;
            try
            {
                int month = 0;
                int year = 0;
                ArrayList alMothList = new ArrayList();

                //    year = Convert.ToInt32(this.cboYearView.Text);

                year = Convert.ToInt32(rv.cboYearView);
                //  if (this.rdoMonthlyView.Checked)
                // {
                // month = Convert.ToInt32(this.cboMonthView.Text);

                month = Convert.ToInt32(rv.cboMonthView);
                alMothList.Add(month);
                CycleLength = 6;
                // }

                if (rv.rdoQuerterly==true)
                {
                    CycleLength = 15;
                    if (rv.cboQuarter.StartsWith("Q1"))
                    {
                        month = 1;
                    }
                    if (rv.cboQuarter.StartsWith("Q2"))
                    {
                        month = 4;
                    }
                    if (rv.cboQuarter.StartsWith("Q3"))
                    {
                        month = 7;
                    }
                    if (rv.cboQuarter.StartsWith("Q4"))
                    {
                        month = 10;
                    }
                    for (int i = 0; i < 3; i++)
                    {
                        alMothList.Add(month + i);
                    }

                }

                if (rv.rdoSemiAnnual==true)
                {
                    CycleLength = 30;
                    if (rv.cboSemiAnnual.Contains("Jan"))
                    {
                        month = 1;
                    }
                    if (rv.cboSemiAnnual.Contains("Dec"))
                    {
                        month = 7;
                    }
                    for (int i = 0; i < 6; i++)
                    {
                        alMothList.Add(month + i);
                    }
                }

                if (rv.rdoYearly==true)
                {
                    CycleLength = 55;
                    month = 1;
                    for (int i = 0; i < 12; i++)
                    {
                        alMothList.Add(month + i);
                    }
                }


                string query = "select UserName, [Activity Id], SUM(Day1 + Day2+ Day3+ Day4+ Day5+ Day6+ Day7) as Hours from (";
                query = query + GenerateReportQuery(month, year, currentUserOnly, isAbsenceView, CycleLength, alMothList) + " ) a group by UserName, [Activity Id]";

                //string query = "select UserName, WeekEnd_ID, WeekEndDate, [Activity Id], Day1 + Day2+ Day3+ Day4+ Day5+ Day6+ Day7 as Hours from (";
                //query = query + GenerateReportQuery(month, year, currentUserOnly, isAbsenceView, CycleLength, alMothList) + " ) a ";


                if (!isUserbasedPull)
                {
                    query = query.Replace("UserName,", "");
                }

                dtTable = DBLoad.LoadDBTableSQL(query);

            }
            catch (Exception ex)
            {
                Logger.WriteLogEntry("Error in GetMonthlyViewTable", "Error in GetMonthlyViewTable", ex, DBOperation.Enum.MessageType.Error);
            }
            return dtTable;
        }


        private string GenerateReportQuery(int month, int year, bool currentUserOnly, bool isAbsenceView, int CycleLength, ArrayList alMothList)
        {
            //int month = 11;
            //int year = 2018;
            alList = new ArrayList();
            DateTime dtStart = new DateTime(year, month, 1);
            DateTime dtEnd = new DateTime(year, month, DateTime.DaysInMonth(year, month));

            double start = 7 - (int)dtStart.DayOfWeek;
            DateTime dtWeekEnding = dtStart.AddDays(start);

            //this.onlyZeros = true;
            //ConstructQuery(dtWeekEnding, month, currentUserOnly, isAbsenceView);

            //dtWeekEnding = dtWeekEnding.AddDays(7);
            //this.onlyZeros = true;
            //ConstructQuery(dtWeekEnding, month, currentUserOnly, isAbsenceView);

            //dtWeekEnding = dtWeekEnding.AddDays(7);
            //this.onlyZeros = true;
            //ConstructQuery(dtWeekEnding, month, currentUserOnly, isAbsenceView);

            //dtWeekEnding = dtWeekEnding.AddDays(7);
            //this.onlyZeros = true;
            //ConstructQuery(dtWeekEnding, month, currentUserOnly, isAbsenceView);

            //dtWeekEnding = dtWeekEnding.AddDays(7);
            //this.onlyZeros = true;
            //ConstructQuery(dtWeekEnding, month, currentUserOnly, isAbsenceView);

            //dtWeekEnding = dtWeekEnding.AddDays(7);
            //this.onlyZeros = true;
            //ConstructQuery(dtWeekEnding, month, currentUserOnly, isAbsenceView);

            for (int cycle = 0; cycle < CycleLength; cycle++)
            {
                this.onlyZeros = true;
                ConstructQuery(dtWeekEnding, alMothList, currentUserOnly, isAbsenceView);
                dtWeekEnding = dtWeekEnding.AddDays(7);
            }

            string ReportQuery = string.Empty;
            for (int i = 0; i < alList.Count; i++)
            {
                ReportQuery = ReportQuery + " " + alList[i];
            }

            return ReportQuery;
        }


        string invoiceQuery = string.Empty;
        bool onlyZeros = true;
        ArrayList alList = new ArrayList();
        private void ConstructQuery(DateTime dtInput, ArrayList alMothList, bool currentUserOnly, bool isAbsenceView)
        {
            //invoiceQuery = "SELECT UserName, CaseID as 'Activity Id' "; //TODO
            invoiceQuery = "SELECT UserName, CaseID as 'Activity Id' ";

            ConstructSubQuery(dtInput.AddDays(-6), alMothList, "Day1");
            ConstructSubQuery(dtInput.AddDays(-5), alMothList, "Day2");
            ConstructSubQuery(dtInput.AddDays(-4), alMothList, "Day3");
            ConstructSubQuery(dtInput.AddDays(-3), alMothList, "Day4");
            ConstructSubQuery(dtInput.AddDays(-2), alMothList, "Day5");
            ConstructSubQuery(dtInput.AddDays(-1), alMothList, "Day6");
            ConstructSubQuery(dtInput.AddDays(0), alMothList, "Day7");

            string absString = string.Empty;
            if (!isAbsenceView)
            {
                absString = " caseid not in (select absence_id from t_edis_absence_lookup) and ";
            }
            else
            {
                absString = " caseid in (select absence_id from t_edis_absence_lookup) and ";
            }

            if (currentUserOnly)
            {
                invoiceQuery = invoiceQuery + " FROM t_edis_timesheet where " + absString + " WeekEnd_ID = " + dtInput.Month.ToString("D2") + dtInput.Day.ToString("D2") + dtInput.Year.ToString("D4") + " and UserName = '" + userName + "'";
            }
            else
            {
                invoiceQuery = invoiceQuery + " FROM t_edis_timesheet where " + absString + " WeekEnd_ID = " + dtInput.Month.ToString("D2") + dtInput.Day.ToString("D2") + dtInput.Year.ToString("D4");
            }

            if (!this.onlyZeros)
            {
                if (alList.Count == 0)
                {
                    alList.Add(invoiceQuery);
                }
                else
                {
                    alList.Add(" UNION " + invoiceQuery);

                }
            }
            invoiceQuery = string.Empty;
        }

        private void ConstructSubQuery(DateTime dtTempInput, ArrayList alMothList, string col)
        {

            if (alMothList.Contains(dtTempInput.Month))
            //if (dtTempInput.Month == monthInput)
            {
                this.onlyZeros = false;
                if (invoiceQuery.Length == 0)
                {
                    invoiceQuery = col;
                }
                else
                {
                    invoiceQuery = invoiceQuery + "," + col;
                }
            }
            else
            {
                if (invoiceQuery.Length == 0)
                {
                    invoiceQuery = "'0' as " + col;
                }
                else
                {
                    invoiceQuery = invoiceQuery + "," + "'0' as " + col;
                }
            }
        }




        private DataTable CreateInvoiceReport(DataTable dtMaster, DataTable dtHours, DataTable dtDepartment, DataTable dtMasterSecondary)
        {
            Regex SelectRegex = new Regex(@"[0-9]+%", RegexOptions.Compiled);
            DataTable dtMasterFinal = null;

            try
            {
                DataRow[] dr = null;
                DataRow[] drDept = null;
                DataRow drFinal = null;
                string dept = string.Empty;
                string requester = string.Empty;

                string replacevalue = string.Empty;
                int hours = 0;

                DataRow drSec = null;
                for (int isec = 0; isec < dtMasterSecondary.Rows.Count; isec++)
                {
                    drSec = dtMaster.NewRow();
                    drSec[0] = dtMasterSecondary.Rows[isec]["CaseID"];
                    drSec[1] = dtMasterSecondary.Rows[isec]["CaseName"];
                    drSec[2] = 0;//Hours
                    drSec[3] = dtMasterSecondary.Rows[isec]["ProjWebID"];
                    drSec[4] = dtMasterSecondary.Rows[isec]["PrimaryRequestor"];
                    drSec[5] = dtMasterSecondary.Rows[isec]["SecondaryRequester"];
                    drSec[6] = "";//Department
                    drSec[7] = dtMasterSecondary.Rows[isec]["Account"];
                    drSec[8] = dtMasterSecondary.Rows[isec]["CostCenter"];
                    replacevalue = Regex.Replace(drSec[8].ToString(), SelectRegex.ToString(), ",");
                    drSec[8] = replacevalue;
                    drSec[9] = dtMasterSecondary.Rows[isec]["BusinessUnit"];
                    drSec[10] = "AMER";
                    drSec[11] = "";//Comments
                    dtMaster.Rows.Add(drSec);
                }



                ////  Dheeraj-- Omit % value from the COST CENTER
                //for (int i = 0; i < dtMaster.Rows.Count; i++)
                //{

                //    dtMaster.Rows[i]["CostCenter"] = Regex.Replace(dtMaster.dr[8]["CostCenter"].ToString(), SelectRegex.ToString(), ",");

                //}


                dtMaster.AcceptChanges();



                dtMasterFinal = dtMaster.Clone();

                for (int i = 0; i < dtMaster.Rows.Count; i++)
                {
                    if (dtDepartment != null)
                    {
                        dept = string.Empty;
                        requester = dtMaster.Rows[i]["Primary LCD Requestor"].ToString().Replace("'", "''");
                        drDept = dtDepartment.Select("RequestorName = '" + requester + "'");
                        if (drDept.Length > 0)
                        {
                            dept = drDept[0]["Department"].ToString();
                        }
                    }

                    dr = dtHours.Select("[Activity Id] = '" + dtMaster.Rows[i][0].ToString() + "'");
                    if (dr.Length > 0)
                    {
                        hours = 0;
                        hours = Convert.ToInt32(dr[0]["Hours"]);

                        drFinal = dtMasterFinal.NewRow();
                        for (int j = 0; j < dtMasterFinal.Columns.Count; j++)
                        {
                            drFinal[j] = dtMaster.Rows[i][j];
                        }
                        drFinal["Department"] = dept;
                        drFinal["Hours"] = hours;

                        dtMasterFinal.Rows.Add(drFinal);
                    }
                }

                dtMasterFinal.AcceptChanges();

                ArrayList alList = new ArrayList();
                alList.Add("Case ID");
                alList.Add("Case Name");
                alList.Add("Hours");
                alList.Add("Project Web Id");
                alList.Add("LCD Requestor");
                alList.Add("Assistant\\GC Approval");
                alList.Add("Department");
                alList.Add("Account");
                alList.Add("Cost Center");
                alList.Add("Business Unit");
                alList.Add("Location");
                alList.Add("Comments");

                for (int j = 0; j < dtMasterFinal.Columns.Count; j++)
                {
                    dtMasterFinal.Columns[j].ColumnName = alList[j].ToString();


                }




            }
            catch (Exception ex)
            {
                Logger.WriteLogEntry("Error in CreateInvoiceReport", "Error in CreateInvoiceReport", ex, DBOperation.Enum.MessageType.Error);



            }
            return dtMasterFinal;
        }


        private void TimesheetExportToExcel()
        {
            Regex SelectRegex = new Regex(@"[0-9]+%");



            try
            {
                // if (this.gridResult.DataSource != null)
                // {
                //  if (this.txtExportPath.Text.Trim().Length > 0)
                // {
                DataTable dt = null;
                //  DataTable dt = (DataTable)this.gridResult.DataSource;
                //  DataSet ds = new DataSet();
                //  ds.Tables.Add(dt);
                DataRow drSec = null;
                for (int isec = 0; isec < dt.Rows.Count; isec++)
                {
                    drSec = dt.NewRow();
                    drSec[0] = dt.Rows[isec]["CaseID"];
                    drSec[1] = dt.Rows[isec]["CaseName"];
                    drSec[2] = 0;//Hours
                    drSec[3] = dt.Rows[isec]["ProjWebID"];
                    drSec[4] = dt.Rows[isec]["PrimaryRequestor"];
                    drSec[5] = dt.Rows[isec]["SecondaryRequester"];
                    drSec[6] = "";//Department
                    drSec[7] = dt.Rows[isec]["Account"];
                    drSec[8] = dt.Rows[isec]["CostCenter"];
                    var value = Regex.Replace(drSec[8].ToString(), SelectRegex.ToString(), ",");
                    drSec[8] = value;
                    drSec[9] = dt.Rows[isec]["BusinessUnit"];
                    drSec[10] = "AMER";
                    drSec[11] = "";//Comments
                    dt.Rows.Add(drSec);
                }

                DataSet ds = new DataSet();
                ds.Tables.Add(dt);
                
                    ExportToExcel.ExportDataExcel(ds, "Table1", "");
                // ExportToExcel.ExportDataExcel(ds, "Table1", this.txtExportPath.Text);

                //MessageBox.Show("Success Export To Excel. Please check the file in the given path", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                //   }
                // else
                // {
                //MessageBox.Show("File path can not be empty. Please input the file path", "Alert", MessageBoxButtons.OK);
                // }
                //  }
                //else
                //{
                //    MessageBox.Show("Grid results are empty. Unable to generate report", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                //}

            }
            catch (Exception ex)
            {
                //MessageBox.Show("Sorry, unable to generate excel report. Please contact system admin", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Logger.WriteLogEntry("Error in llblExportToExcel_LinkClicked", "Error in llblExportToExcel_LinkClicked", ex, DBOperation.Enum.MessageType.Error);
            }
        }

        
        //public DataTable createrecord(TimesheetActivity tsa)
        //{
        //    string query;
        //    try
        //    {

        //        eDiscoveryWorkFlowTempDBEntities db = new eDiscoveryWorkFlowTempDBEntities();
        //        t_edis_TimeSheet Em = new t_edis_TimeSheet();
        //         query  = "Exec speDiscTimeSheet @weekendDate = IP_WEEKENDDATE, @weekendId = IPWEEKENDID, @caseId = IPCASEID, @userName = IPUSERNAME, @day1 = IPDAY1 , @day2 = IPDAY2, @day3 = IPDAY3, @day4 = IPDAY4, @day5 = IPDAY5, @day6 = IPDAY6, @day7 = IPDAY7, @CreatedBy = IPCREATEBY";
        //        query = query.Replace(tsa.IP_WEEKENDDATE, "'" + this.dtWeekEndingGlobal.ToShortDateString() + "'");
        //        query = query.Replace(tsa.IPWEEKENDID, "'" + this.dtWeekEndingGlobal.Month.ToString("D2") + this.dtWeekEndingGlobal.Day.ToString("D2") + this.dtWeekEndingGlobal.Year.ToString("D4") + "'");       
        //        query = tsa.IPCASEID;
        //        query =tsa.IPUSERNAME;
        //        Em.Day1 = tsa.IPDAY2.GetType()();
        //        Em.Day2 = tsa.IPDAY3.ToString();
        //        Em.Day3 = tsa.IPDAY4.ToString();
        //        Em.Day4 = tsa.IPDAY5.ToString();
        //        Em.Day5 = tsa.IPDAY6.ToString();
        //        Em.Day6 = tsa.IPDAY7.ToString();
        //        Em.Day7 = tsa.IPDAY2.ToString();
        //        Em.Day2 = tsa.IPCREATEBY.ToString();
        //        db.t_edis_TimeSheet.Add(Em);
        //      db.SaveChanges();
        //      //  DataTable dt = 
        //        DBLoad.ExecuteNonQuery(query);
        //        this.LoadResultGrid();
        //    }
            
        //    catch (Exception)
        //    {

        //        throw;
        //    }
        //    return q;
        //}


        //private void AddRecord(TimesheetActivity tsv)
        //{
        //    int result;


        //    try
        //    {
        //        using (SqlConnection con = new SqlConnection())
        //        {
        //            con.ConnectionString = conString;

        //            string query = @" IF NOT EXISTS (SELECT 1 FROM t_edis_TimeSheet WHERE WeekEnd_ID = @WeekEndID AND CaseID = @CaseID AND UserName = @UserName)
        //           INSERT INTO t_edis_TimeSheet (WeekEndDate,WeekEnd_ID,CaseID,UserName,Day1,Day2,Day3,Day4,Day5,Day6,Day7,CreatedBy) 
        //     VALUES  (@WeekEndDate,@WeekEndID,@CaseID,@UserName,@Day1,@Day2,@Day3,@Day4,@Day5,@Day6,@Day7,@CreatedBy)
        //             ELSE
        //          UPDATE t_edis_TimeSheet SET Day1 = @Day1,Day2 = @Day2,Day3 = @Day3,Day4 = @Day4,Day5 = @Day5,Day6 = @Day6,Day7 = @Day7,CreatedBy = @CreatedBy,CreatedDate = GETDATE()  WHERE WeekEnd_ID = @WeekEndID AND CaseID =  @CaseID AND UserName = @UserName";

        //            SqlCommand command = new SqlCommand(query, con);
        //            command.Parameters.AddWithValue("@CaseID", tsv.IPCASEID);
        //            command.Parameters.AddWithValue("@UserName", tsv.IPUSERNAME);
        //            command.Parameters.AddWithValue("@userCreatedBy", userName);
        //            command.Parameters.AddWithValue("@userCreatedDate", DateTime.Now);
        //            con.Open();
        //            result = DBLoad.ExecuteNonQuery(query);
        //            con.Close();

        //            if (result < 0)
        //            {
        //                lblmessage.Visible = true;
        //                lblmessage.Text = "Record is already Exist";
        //                lblmessage.ForeColor = Color.Red;


        //            }
        //            else
        //            {
        //              //  lblmessage.Visible = true;
        //              //  lblmessage.Text = "Admin right added successfully!!";

        //               // lblmessage.ForeColor = Color.ForestGreen;
        //            }

        //        }






        //        catch (Exception ex)
        //    {
        //        Logger.WriteLogEntry("Error in AddRecord", "Error in AddRecord", ex, Enum.MessageType.Error);
        //    }
        //}
    }
}