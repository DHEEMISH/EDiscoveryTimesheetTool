﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Collections;
using System.Configuration;
using System.ComponentModel;
using System.Data;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using Microsoft.Office.Interop;
using System.Data.SqlClient;

namespace DBTableDataCompareTool
{
    class DecryptSQLQuery
    {

        public static DataTable LoadDecryptSQLQuery(string queryName, string conString)
        {
            try
            {
                SqlConnection conn = new SqlConnection();
                conn.ConnectionString = conString;

                if (!queryName.ToUpper().Contains("LIKE"))
                {
                    DataTable dtResult = FetchBasicQuery(queryName, conn);
                    return dtResult;
                }
                else
                {
                    string[] parts = queryName.Split(new string[] { ConfigurationManager.AppSettings["WhereClauseKey"] }, StringSplitOptions.None);
                    if (parts.Length == 1)
                    {
                        FetchBasicQuery(queryName, conn);
                    }
                    else
                    {

                        queryName = queryName.Replace("\n", " ");
                        queryName = queryName.Replace("\r", " ");
                        queryName = queryName.Replace("\t", " ");

                        string[] partsWithEmpty = queryName.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries);
                        string queryNameStringLike = string.Empty;


                        for (int i = 0; i < partsWithEmpty.Length; i++)
                        {
                            if (queryNameStringLike.Length == 0)
                            {
                                queryNameStringLike = partsWithEmpty[i];
                            }
                            else
                            {
                                queryNameStringLike = queryNameStringLike + " " + partsWithEmpty[i];
                            }

                        }


                        ArrayList alFilerList = new ArrayList();

                        bool isLikeEncryptted = false;
                        partsWithEmpty = queryNameStringLike.Split(new string[] { " " }, StringSplitOptions.None);
                        for (int j = 0; j < partsWithEmpty.Length; j++)
                        {
                            if (partsWithEmpty[j].ToUpper().Equals("LIKE"))
                            {
                                if (partsWithEmpty[j + 1].Contains(ConfigurationManager.AppSettings["WhereClauseKey"]))
                                {

                                    if (!partsWithEmpty[j - 1].ToUpper().Trim().Equals("NOT"))
                                    {

                                        alFilerList.Add(partsWithEmpty[j - 2]); // Join condition
                                        alFilerList.Add(ConfigurationManager.AppSettings["SelectClauseKey"] + "ColumnAlaisLike" + j); // Column Name
                                        alFilerList.Add(partsWithEmpty[j + 1]); // Value
                                        alFilerList.Add(" LIKE "); // key word


                                        partsWithEmpty[j] = " = ";
                                        partsWithEmpty[j + 1] = partsWithEmpty[j - 1];
                                        partsWithEmpty[0] = partsWithEmpty[0] + " " + partsWithEmpty[j + 1] + " as " + ConfigurationManager.AppSettings["SelectClauseKey"] + "ColumnAlaisLike" + j + ",";


                                        partsWithEmpty[j] = " ";
                                        partsWithEmpty[j + 1] = "";
                                        partsWithEmpty[j - 1] = "";
                                        partsWithEmpty[j - 2] = ""; //Condition


                                        isLikeEncryptted = true;
                                    }
                                    else
                                    {
                                        alFilerList.Add(partsWithEmpty[j - 3]); // Join condition
                                        alFilerList.Add(ConfigurationManager.AppSettings["SelectClauseKey"] + "ColumnAlaisLike" + j); // Column Name
                                        alFilerList.Add(partsWithEmpty[j + 1]); // Value
                                        alFilerList.Add(" NOT LIKE "); // key word


                                        partsWithEmpty[j] = " = ";
                                        partsWithEmpty[j + 1] = partsWithEmpty[j - 2];
                                        partsWithEmpty[0] = partsWithEmpty[0] + " " + partsWithEmpty[j + 1] + " as " + ConfigurationManager.AppSettings["SelectClauseKey"] + "ColumnAlaisLike" + j + ",";


                                        partsWithEmpty[j] = " ";
                                        partsWithEmpty[j + 1] = "";
                                        partsWithEmpty[j - 2] = "";
                                        partsWithEmpty[j - 1] = ""; // NOT
                                        partsWithEmpty[j - 3] = ""; // Condition

                                        isLikeEncryptted = true;
                                    }
                                }
                            }
                        }


                        if (isLikeEncryptted)
                        {
                            string queryNameStringFinal = string.Empty;
                            for (int k = 0; k < partsWithEmpty.Length; k++)
                            {
                                if (queryNameStringLike.Length == 0)
                                {
                                    queryNameStringFinal = partsWithEmpty[k];
                                }
                                else
                                {
                                    queryNameStringFinal = queryNameStringFinal + " " + partsWithEmpty[k];
                                }
                            }
                            DataTable dtFinal = FetchLikeQuery(queryNameStringFinal, conn);
                            DataTable dtResult = ApplyFilter(dtFinal, alFilerList);
                            return dtResult;
                        }
                        else
                        {
                            DataTable dtResult = FetchBasicQuery(queryName, conn);
                            return dtResult;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLogEntry("Error in LoadDecryptSQLQuery", "Error in LoadDecryptSQLQuery", ex, Enum.MessageType.Error);
            }
            return null;
        }

        private static DataTable ApplyFilter(DataTable dtFinal, ArrayList alFilerList)
        {
            string FilterString = " ";
            string JoinCondt = "";
            string colName = "";
            string colValue = "";
            string KeyWord = "";

            ArrayList alListColName = new ArrayList();



            for (int i = 0; i < alFilerList.Count; i = i + 4)
            {
                JoinCondt = Convert.ToString(alFilerList[i]);

                colName = Convert.ToString(alFilerList[i + 1]);
                colValue = Convert.ToString(alFilerList[i + 2]);
                KeyWord = Convert.ToString(alFilerList[i + 3]);

                colValue = colValue.Replace(ConfigurationManager.AppSettings["WhereClauseKey"], "");

                colName = colName.Replace(ConfigurationManager.AppSettings["SelectClauseKey"], "");

                alListColName.Add(colName);

                if (JoinCondt.ToUpper().Trim() == "AND" || JoinCondt.ToUpper().Trim() == "OR")
                {
                    JoinCondt = JoinCondt.ToUpper();
                }
                else
                {
                    JoinCondt = "AND";
                }

                if (FilterString.Trim().Length == 0)
                {

                    FilterString = colName + KeyWord + colValue + " ";
                }
                else
                {
                    FilterString = FilterString + " " + JoinCondt + " " + colName + KeyWord + colValue + " ";
                }

                dtFinal.DefaultView.RowFilter = FilterString;

                DataTable dtTabbleFinal = CreateTable(dtFinal, dtFinal.DefaultView);

                for (int j = 0; j < alListColName.Count; j++)
                {

                    dtTabbleFinal.Columns.Remove(alListColName[j].ToString());
                }

            }


            return dtFinal;
        }


        private static DataTable CreateTable(DataTable dtTabble, DataView dvFilter)
        {
            DataTable dtTabbleFinal = dtTabble.Clone();
            try
            {

                string colName = string.Empty;

                for (int i = 0; i < dvFilter.Count; i++)
                {

                    DataRow dr = dtTabbleFinal.NewRow();


                    for (int j = 0; j < dtTabble.Columns.Count; j++)
                    {
                        colName = dtTabble.Columns[j].ColumnName;
                        dr[j] = dvFilter[i][j];
                    }

                    dtTabbleFinal.Rows.Add(dr);

                }

                dtTabbleFinal.AcceptChanges();
            }
            catch (Exception ex)
            {
                Logger.WriteLogEntry("Error in CreateTableWithDecryptRecords", "Error in CreateTableWithDecryptRecords", ex, Enum.MessageType.Error);
            }


            return dtTabbleFinal;
        }


        private static DataTable FetchLikeQuery(string queryName, SqlConnection conn)
        {
            string[] parts = queryName.Split(new string[] { ConfigurationManager.AppSettings["WhereClauseKey"] }, StringSplitOptions.None);


            for (int i1 = 1; i1 < parts.Length; i1 = i1 + 2)
            {
                parts[i1] = EncryptionUtility.Encrypt(parts[i1]);
            }
            string queryNameString = string.Empty;

            for (int i2 = 0; i2 < parts.Length; i2++)
            {
                queryNameString = queryNameString + parts[i2];
            }

            if (queryNameString.Length == 0)
            {
                queryNameString = queryName;
            }

            conn.Open();
            SqlDataAdapter adapter = new SqlDataAdapter(queryNameString, conn);

            DataTable dtEncryptTable = new DataTable();
            adapter.Fill(dtEncryptTable);

            DataTable dtDecryptTable = null;
            dtDecryptTable = new DataTable();

            string colName = string.Empty;
            for (int i = 0; i < dtEncryptTable.Columns.Count; i++)
            {
                colName = dtEncryptTable.Columns[i].ColumnName;
                if (colName.StartsWith(ConfigurationManager.AppSettings["SelectClauseKey"]))
                {
                    colName = colName.Replace(ConfigurationManager.AppSettings["SelectClauseKey"], string.Empty);
                    dtDecryptTable.Columns.Add(colName, dtEncryptTable.Columns[i].DataType);
                }
                else
                {
                    dtDecryptTable.Columns.Add(colName, dtEncryptTable.Columns[i].DataType);
                }
            }

            DataTable dtFinal = CreateTableWithDecryptRecords(dtEncryptTable, dtDecryptTable);


            return dtFinal;


        }



        private static DataTable FetchBasicQuery(string queryName, SqlConnection conn)
        {
            string[] parts = queryName.Split(new string[] { ConfigurationManager.AppSettings["WhereClauseKey"] }, StringSplitOptions.None);


            for (int i1 = 1; i1 < parts.Length; i1 = i1 + 2)
            {
                parts[i1] = EncryptionUtility.Encrypt(parts[i1]);
            }
            string queryNameString = string.Empty;

            for (int i2 = 0; i2 < parts.Length; i2++)
            {
                queryNameString = queryNameString + parts[i2];
            }

            if (queryNameString.Length == 0)
            {
                queryNameString = queryName;
            }

            conn.Open();
            SqlDataAdapter adapter = new SqlDataAdapter(queryNameString, conn);

            DataTable dtEncryptTable = new DataTable();
            adapter.Fill(dtEncryptTable);

            DataTable dtDecryptTable = null;
            dtDecryptTable = new DataTable();

            string colName = string.Empty;
            for (int i = 0; i < dtEncryptTable.Columns.Count; i++)
            {
                colName = dtEncryptTable.Columns[i].ColumnName;
                if (colName.StartsWith(ConfigurationManager.AppSettings["SelectClauseKey"]))
                {
                    colName = colName.Replace(ConfigurationManager.AppSettings["SelectClauseKey"], string.Empty);
                    dtDecryptTable.Columns.Add(colName, dtEncryptTable.Columns[i].DataType);
                }
                else
                {
                    dtDecryptTable.Columns.Add(colName, dtEncryptTable.Columns[i].DataType);
                }
            }

            DataTable dtFinal = CreateTableWithDecryptRecords(dtEncryptTable, dtDecryptTable);

            return dtFinal;
        }


        private static DataTable CreateTableWithDecryptRecords(DataTable dtEncryptTable, DataTable dtDecryptTable)
        {
            try
            {
                string colName = string.Empty;

                for (int i = 0; i < dtEncryptTable.Rows.Count; i++)
                {

                    DataRow dr = dtDecryptTable.NewRow();


                    for (int j = 0; j < dtEncryptTable.Columns.Count; j++)
                    {
                        colName = dtEncryptTable.Columns[j].ColumnName;
                        if (colName.StartsWith(ConfigurationManager.AppSettings["SelectClauseKey"]))
                        {
                            dr[j] = EncryptionUtility.Decrypt(Convert.ToString(dtEncryptTable.Rows[i][j]));

                        }
                        else
                        {
                            dr[j] = dtEncryptTable.Rows[i][j];
                        }
                    }

                    dtDecryptTable.Rows.Add(dr);

                }

                dtDecryptTable.AcceptChanges();
            }
            catch (Exception ex)
            {
                Logger.WriteLogEntry("Error in CreateTableWithDecryptRecords", "Error in CreateTableWithDecryptRecords", ex, Enum.MessageType.Error);
            }


            return dtDecryptTable;
        }
    }
}
