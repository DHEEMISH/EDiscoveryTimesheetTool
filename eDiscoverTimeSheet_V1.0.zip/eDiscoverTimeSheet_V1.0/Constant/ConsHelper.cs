﻿using System;
using System.Collections.Generic;

using System.Linq;
using System.Web;

namespace eDiscoverTimeSheet_V1._0.Models.LoginModel
{
    public class ConsHelper
    {

        private static string _ValidStatus = "Valid";
        private static string _InvalidStatus = "Invalid";
        private static string _Message = "Valid User";
        public  static string ValidStatus { get { return _ValidStatus; } }
        public static string InvalidStatus { get { return _InvalidStatus; } }
        public static string Message { get { return _Message; } }

    }
}