﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using eDiscoverTimeSheet_V1._0.Models.LoginModel;
using eDiscoverTimeSheet_V1._0.Models;
using eDiscoverTimeSheet_V1._0.eDiscoveryCommonDTO;
using System.Configuration;
using System.IO;
using System.Text;
using System.Data;
using Newtonsoft.Json;
using eDiscoverTimeSheet_V1._0.Filters;
using System.Net.Http;
using System.Web.Http;
using System.Threading;
using System.Net;

namespace eDiscoverTimeSheet_V1._0.Controllers
{
 //   [System.Web.Http.Authorize]
    public class LoginController : ApiController
    {

    //    GET: Login
       [CustomAttribute]
       [System.Web.Http.Route("Api/Login/UserLogin")]
      // [System.Web.Http.ActionName("UserLogin")]
       [System.Web.Http.HttpPost]
       [AuthenticationAttributeFilter]
        public HttpResponseMessage UserLogin(Dashboard db)
        {
            try
            {
                    string userName = System.Security.Principal.WindowsIdentity.GetCurrent().Name;
                    string userDoaminAlias = userName.ToString();
                    string[] parts = userDoaminAlias.Split(new char[] { '\\' });
                    int pass = 5000;
                    userName = parts[1];
           

                    if (userName == Thread.CurrentPrincipal.Identity.Name)
                    {
                        Dashboard loginresult = new Dashboard();
                        loginresult = Login.CheckLogin(userName, pass);

                        return Request.CreateResponse(HttpStatusCode.OK, loginresult);

                    }
            }
            catch (Exception ex)
            {
                // Log exception code goes here  
                  return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex.ToString());  
            }
   
            return Request.CreateResponse(HttpStatusCode.BadRequest);


        }

        // [System.Web.Http.HttpPost]
        //[System.Web.Http.Route("Api/Login/UserLogin")]
        // [CustomAttribute]      
        // public JsonResult UserLogin(Dashboard reqOb)
        // {
        //     string userName = System.Security.Principal.WindowsIdentity.GetCurrent().Name;
        //     string userDoaminAlias = userName.ToString();
        //     string[] parts = userDoaminAlias.Split(new char[] { '\\' });
        //     userName = parts[1];

        //     Dashboard loginresult = new Dashboard();
        //     Login lg = new Login();
        //     loginresult = Login.CheckLogin(userName);
        //     //string userresult = lg.IsSuperUser();
        //     //loginresult.DomainLogin = userresult;
        //     //result.Add(loginresult.ToString());

        //     JsonResult data = loginresult == null ? Json(new { Status = ConsHelper.InvalidStatus, Message = "Value is null" }) : Json(JsonConvert.SerializeObject(loginresult));
        //     data.JsonRequestBehavior = JsonRequestBehavior.AllowGet;
        //     //  HttpContext.Response.AddHeader("Access-Control-Allow-Origin", "*");
        //     //HttpContext.Response.AddHeader("Content-Type", "application/json");
        //     return data;
        // }
    }
}



