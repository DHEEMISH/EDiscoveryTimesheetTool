﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using eDiscoverTimeSheet_V1._0.Models.LoginModel;
using System.Data;
using eDiscoverTimeSheet_V1._0.eDiscoveryCommonDTO;
using Newtonsoft.Json.Serialization;
using Newtonsoft.Json.Linq;
//using Newtonsoft.Json;
using eDiscoverTimeSheet_V1._0.Filters;
using System.Web.Http;
using eDiscoverTimeSheet_V1._0.Models;
using System.Net;
using DBOperation;
using System.Data.Entity.Core.Objects;
using Newtonsoft.Json;

namespace eDiscoverTimeSheet_V1._0.Controllers
{
    
    [System.Web.Http.RoutePrefix("Api/Activity")]
    public class ActivityController : Controller
    {
        eDiscoveryWorkFlowTempDBEntities db = new eDiscoveryWorkFlowTempDBEntities();
        TimesheetActivity tsa = new TimesheetActivity();
       
        Activity ac = new Activity();
        
        // GET: Activity
        //public ActionResult Index()
        //{
        //    return View();
        //}

        [CustomAttribute]
        [System.Web.Http.HttpGet]
         public JsonResult LoadDashboardDetails(bool? overridefilter)
        {
            DataSet ds = new DataSet();
            try
            {
              //  DataTable activitydata = ac.LoadActivityId(true);

                //DataTable loadweekdata = ac.LoadWeekEnding();
                DataTable loaduser = ac.LoadOverideUser();
                loaduser.TableName = "OverRideUser";
              //  activitydata.TableName = "ActivityId";
                DataTable loadresult = ac.LoadResultGrid();
              //  DataTable createrecord = ac.createrecord(tsa);

              //  ds.Tables.Add(activitydata);
                ds.Tables.Add(loaduser);
                // ds.Tables.Add(loadresult);
                // ds.Tables.Add(loadweekdata);

                //  ac.createrecord(tsv);
             
            }

            catch(Exception ex)
            {

                Logger.WriteLogEntry("Information : ", " Error Occure while loading records ", ex, DBOperation.Enum.MessageType.Error);
                string error = ex.ToString();
            }

            JsonResult data = ds == null ? Json(new { Status = ConsHelper.InvalidStatus, Message = "Value is null" }) : Json(JsonConvert.SerializeObject(ds));
            data.JsonRequestBehavior = JsonRequestBehavior.AllowGet;
         //   HttpContext.Response.AddHeader("Access-Control-Allow-Origin", "*");
           // HttpContext.Response.AddHeader("Content-Type", "application/json");
            return data;
        }



        [CustomAttribute]
        [System.Web.Http.HttpGet]
        public JsonResult LoadActivityId(bool? activityfilter)
        {
            bool filter = activityfilter == null ?  true: !((bool)activityfilter);
            DataTable activitydata = new DataTable();
            DataSet ds = new DataSet();
            try
            {
                 activitydata = ac.LoadActivityId(filter);
                activitydata.TableName = "ActivityId";

            }

            catch (Exception ex)
            {
                Logger.WriteLogEntry("Information : ", " Error Occure while loading records ", ex, DBOperation.Enum.MessageType.Error);
                string error = ex.ToString();
            }

            JsonResult data = activitydata == null ? Json(new { Status = ConsHelper.InvalidStatus, Message = "Value is null" }) : Json(JsonConvert.SerializeObject(activitydata));
            data.JsonRequestBehavior = JsonRequestBehavior.AllowGet;
        //    HttpContext.Response.AddHeader("Access-Control-Allow-Origin", "*");
           // HttpContext.Response.AddHeader("Content-Type", "application/json");
            return data;
        }

        [System.Web.Mvc.HttpPost]
        [System.Web.Http.Route("InsertHours")]
        public JsonResult PostHours(TimesheetActivity data)
        {

            //  bool returnValue = true;

            try
            {
                if (!ModelState.IsValid)
                {
                    try
                    {


                        var objlm = new t_edis_TimeSheet();
                        objlm.Day1 = data.IPDAY1;
                        objlm.Day2 = data.IPDAY2;
                        objlm.Day3 = data.IPDAY3;
                        objlm.Day4 = data.IPDAY4;
                        objlm.Day5 = data.IPDAY5;
                        objlm.Day6 = data.IPDAY6;

                        objlm.Day7 = data.IPDAY7;
                        db.t_edis_TimeSheet.Add(objlm);
                        Logger.WriteLogEntry("Started InsertIntoDB...", "Started InsertIntoDB...", DBOperation.Enum.MessageType.Information);

                        db.SaveChanges();
                        Logger.WriteLogEntry("Completed InsertIntoDB.", "Completed InsertIntoDB.", DBOperation.Enum.MessageType.Information);
                    }
                    catch (Exception ex)
                    {

                        Logger.WriteLogEntry("Information : ", " Error Occure while inserting the Record ", ex, DBOperation.Enum.MessageType.Error);
                    }
                }

                else
                {
                    try
                    {

                        if (data == null)
                        {
                            Logger.WriteLogEntry("data is empty .", "Completed Data process.", DBOperation.Enum.MessageType.Information);
                            // return BadRequest("Invalid data.");

                        }
  
                    }
                    catch (Exception ex)
                    {
                        
                        Logger.WriteLogEntry("Information : ", " Error Occure while vaildating the Record ", ex, DBOperation.Enum.MessageType.Error);
                    }

                }

            }
            catch (Exception ex)
            {
               
                Logger.WriteLogEntry("Information : ", " Error Occure while vaildating the Record ", ex, DBOperation.Enum.MessageType.Error);
            }


            return Json(data);

        }


       

        [System.Web.Http.HttpPatch]
        [System.Web.Http.Route("UpdateHours")]
        public JsonResult UpdateHours(TimesheetActivity data)
        {

          
            var objlm = db.t_edis_TimeSheet.Where(s => s.CaseID == data.IPCASEID).ToList().FirstOrDefault();
            if (!ModelState.IsValid)
            {
                try
                {

                    if (objlm.CaseID!=null)
                    {
                       
                        objlm.Day1 = data.IPDAY1;
                        objlm.Day2 = data.IPDAY2;
                        objlm.Day3 = data.IPDAY3;
                        objlm.Day4 = data.IPDAY4;
                        objlm.Day5 = data.IPDAY5;
                        objlm.Day6 = data.IPDAY6;
                        objlm.Day7 = data.IPDAY7;
                    }
                   
                    Logger.WriteLogEntry("Started UpdateIntoDB...", "Started UpdateIntoDB...", DBOperation.Enum.MessageType.Information);

                    db.SaveChanges();
                    Logger.WriteLogEntry("Completed UpdateIntoDB.", "Completed UpdateIntoDB.", DBOperation.Enum.MessageType.Information);
                }
                catch (Exception ex)
                {
                   
                    Logger.WriteLogEntry("Information : ", " Error Occure while inserting the Record ", ex, DBOperation.Enum.MessageType.Error);
                }
            }
          

            return data == null ? Json(new { Status = ConsHelper.InvalidStatus, Message = "Error while validating the records " }) : Json(data);

        }




        [System.Web.Http.HttpDelete]
        [System.Web.Http.Route("DeleteHours")]
        public JsonResult DeleteHours(TimesheetActivity data)
        {


            var objlm = db.t_edis_TimeSheet.Where(s => s.CaseID == data.IPCASEID).ToList().FirstOrDefault();
            if (!ModelState.IsValid)
            {
                try
                {

                    if (objlm.CaseID != null)
                    {

                        db.t_edis_TimeSheet.Remove(objlm);
                        Logger.WriteLogEntry("Status...", "Started Deleting record...", DBOperation.Enum.MessageType.Information);
                        db.SaveChanges();

                       

                        Logger.WriteLogEntry("Completed DeleteIntoDB.", "Completed DeleteIntoDB.", DBOperation.Enum.MessageType.Information);
                    }
                }
                catch (Exception ex)
                {
                    // returnValue = false;
                    Logger.WriteLogEntry("Information : ", " Error Occure while Delete the Record ", ex, DBOperation.Enum.MessageType.Error);
                }
            }

            return data == null ? Json(new { Status = ConsHelper.InvalidStatus, Message = "Error while deleting records" }) : Json(data);

        }



        [CustomAttribute]
        [System.Web.Mvc.HttpGet]
        public JsonResult LoadReports()
        {
            ResultView rv = new ResultView();
            DataTable data = null;
            try
            {
                Logger.WriteLogEntry("Status...", "Started Loading Report...", DBOperation.Enum.MessageType.Information);
                data = ac.GenerateInvoice(rv);
                Logger.WriteLogEntry("Status...", "Completed Loading Report...", DBOperation.Enum.MessageType.Information);
            }

            catch (Exception ex)
            {

                Logger.WriteLogEntry("Information : ", " Error Occure while Generating the report ", ex, DBOperation.Enum.MessageType.Error);
                string error = ex.ToString();
            }

            return data == null ? Json(new { Status = ConsHelper.InvalidStatus, Message = "Error while loading report" }) : Json(data);

        }

        protected override void ExecuteCore()
        {
            throw new NotImplementedException();
        }
    }




}
