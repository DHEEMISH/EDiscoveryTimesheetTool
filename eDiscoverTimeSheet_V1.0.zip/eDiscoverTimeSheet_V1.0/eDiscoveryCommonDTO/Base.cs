﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace eDiscoverTimeSheet_V1._0.eDiscoveryCommonDTO
{
    public abstract class Base
    {
        public Boolean IsActive { get; set; }
        public Boolean IsDeleted { get; set; }
        public int CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public int ModifiedBy { get; set; }
        public DateTime ModifiedOn { get; set; }

      

        public abstract bool IsValid();

    }
}