﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace eDiscoverTimeSheet_V1._0.eDiscoveryCommonDTO
{
    public class ResultView
    {


        public string cboYearView { get; set; }
        public string cboMonthView { get; set; }
        public string cboQuarter { get; set; }
        public string cboSemiAnnual { get; set; }
        public bool rdoSemiAnnual { get; set; }
        public bool rdoMonthlyView { get; set; }
        public bool rdoQuerterly { get; set; }
        public bool rdoYearly { get; set; }

        public bool chkIncludeDepartment
        { get; set; }

        public bool RetriveByUser { get; set; }
        public bool RetriveByAllUser { get; set; }
        public bool RetriveAll { get; set; }
        public bool AbsenceByByUser { get; set; }
        public bool AbsenceByAllUser { get; set; }

        public bool AbsenceAll
        {
            get; set;
        }


        public bool chkOveride
        {
            get;
            set;
        }
    }
}