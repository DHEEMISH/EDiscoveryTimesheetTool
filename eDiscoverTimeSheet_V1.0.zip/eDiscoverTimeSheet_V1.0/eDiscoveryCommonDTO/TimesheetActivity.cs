﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace eDiscoverTimeSheet_V1._0.eDiscoveryCommonDTO
{
    public class TimesheetActivity
    {
        public decimal IPDAY1 { get; set; }
        public decimal IPDAY2 { get; set; }
        public decimal IPDAY3 { get; set; }
        public decimal IPDAY4 { get; set; }
        public decimal IPDAY5 { get; set; }
        public decimal IPDAY6 { get; set; }
        public decimal IPDAY7 { get; set; }
        public string IPCREATEBY { get; set; }
        public string IP_WEEKENDDATE { get; set; }
        public string IPWEEKENDID { get; set; }
        public string IPCASEID { get; set; }
        public string IPUSERNAME { get; set; }



        public string lblDAY1 { get; set; }
        public string lblDAY2 { get; set; }
        public string lblDAY3 { get; set; }
        public string lblDAY4 { get; set; }
        public string lblDAY5 { get; set; }
        public string lblDAY6 { get; set; }
        public string lblDAY7 { get; set; }
        public string lblCREATEBY { get; set; }
        public string lbl_WEEKENDDATE { get; set; }

        public string lblWEEKENDID { get; set; }
    }

}