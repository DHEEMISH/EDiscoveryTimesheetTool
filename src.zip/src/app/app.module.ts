import { BrowserModule } from '@angular/platform-browser';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { HttpClientModule } from '@angular/common/http';
import { Routes, RouterModule } from '@angular/router';  
import { FormsModule ,ReactiveFormsModule } from '@angular/forms';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { GlobalService } from './Services/Globalservice';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatSelectModule} from '@angular/material/select';
import {MatRadioModule} from '@angular/material/radio';
import {MatCheckboxModule} from '@angular/material/checkbox';
import {MatCardModule} from '@angular/material/card';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatTableModule} from '@angular/material/table';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import {MatSortModule} from '@angular/material/sort';
import {MatPaginatorModule} from '@angular/material/paginator';
import { DashboardInputDetailsComponent } from './dashboard/dashboard-input-details/dashboard-input-details.component';
import { MatButtonModule } from '@angular/material';
import { DashboardActvityDataComponent } from './dashboard/dashboard-actvity-data/dashboard-actvity-data.component';
import {MatInputModule} from '@angular/material/input';
import { DashboardResultComponent } from './dashboard/dashboard-result/dashboard-result.component';
import { DropdownElementComponent } from './dropdown-element/dropdown-element.component';
//import { DashboardTimeSpendComponent } from './dashboard/dashboard-time-spend/dashboard-time-spend.component';
const approutes: Routes = [  
  {path:'',component:LoginComponent},  
  {path:'dashboard',component:DashboardComponent } 
  
]; 

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    DashboardComponent,
    HeaderComponent,
    FooterComponent,
    DashboardInputDetailsComponent,
    DashboardActvityDataComponent,
    DashboardResultComponent,
    DropdownElementComponent
    //DashboardTimeSpendComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    MatRadioModule,
    ReactiveFormsModule,
  MatCheckboxModule,
  MatCardModule,
  MatFormFieldModule,
  MatTableModule,
  MatButtonModule,
  MatProgressSpinnerModule,
  MatSortModule,
  MatPaginatorModule,
  MatInputModule,
  MatSelectModule,
 // MatPaginator,
  
    RouterModule.forRoot(approutes),
  
    BrowserAnimationsModule
  ],
  bootstrap: [AppComponent],
  providers:[GlobalService],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class AppModule { }
