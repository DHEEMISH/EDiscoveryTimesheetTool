export interface OverRide {  
    OverRideUser;
    ActivityId: string;
    WeeklyDataview ;
    
  
}  

export interface OptionType{
    feildName: string;
    optionArray: string[];
    editable?: boolean;
}