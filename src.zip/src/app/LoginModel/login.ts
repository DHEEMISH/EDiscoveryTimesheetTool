export interface Result {  
      Id:number;
      DomainLogin:string ;
      LoginPersonTypeId ;
      PersonRefrenceId ;
      FirstName ;
      LastName ;
      StartDate ;
      EndDate ;
      isSuperUser ;
      RoleName ;
      DisplayName ;
      OfficeEmail;
    
}  