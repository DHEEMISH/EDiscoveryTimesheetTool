export interface ActivityId {
    Day1 ;  
    Day2 ;  
    Day3 ;  
    Day4;  
    Day5;  
    Day6 ;  
    Day7 ; 
   

}