import { Component, OnInit, Input } from '@angular/core';
import { OptionType } from '../DashboardModel/Overrideuser';

@Component({
  selector: 'app-dropdown-element',
  templateUrl: './dropdown-element.component.html',
  styleUrls: ['./dropdown-element.component.css']
})
export class DropdownElementComponent implements OnInit {
  @Input() options:OptionType;
  constructor() { }

  ngOnInit(): void {
   
  }

}