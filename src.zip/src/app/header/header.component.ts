import { Component, OnInit } from '@angular/core';
import { GlobalService } from '../Services/Globalservice';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  username="";
  email="";
  displayname="";
  Role ="";
  constructor(private globalService:GlobalService)
  {

  }

  ngOnInit() {
    this.globalService.SessionDataReceivedEvent.subscribe((data)=>{
      this.username=data.DomainLogin;
      this.email=data.OfficalEmail;
      this.displayname=data.DisplayName;
      this.Role=data.RoleDisplay;
    });

  }

}
