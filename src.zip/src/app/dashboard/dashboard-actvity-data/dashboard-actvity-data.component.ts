import { OptionType } from './../../DashboardModel/Overrideuser';
import { ActivityId } from './../../ActivityModel/activity';
import { Component, OnInit } from '@angular/core';
import {MatInputModule} from '@angular/material/input';
@Component({
  selector: 'app-dashboard-actvity-data',
  templateUrl: './dashboard-actvity-data.component.html',
  styleUrls: ['./dashboard-actvity-data.component.css']
})
export class DashboardActvityDataComponent implements OnInit {
  value: string;

  ActivityId: OptionType;
  constructor() 
  {


   }

  ngOnInit() 
  {
    this.ActivityId ={
      feildName: 'Activity Id',
      optionArray: ['101','102','103'],
      editable: true
    };
    this.value = 'Hours';
   
  }

}
