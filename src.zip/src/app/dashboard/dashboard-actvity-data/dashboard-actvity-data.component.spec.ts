import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DashboardActvityDataComponent } from './dashboard-actvity-data.component';

describe('DashboardActvityDataComponent', () => {
  let component: DashboardActvityDataComponent;
  let fixture: ComponentFixture<DashboardActvityDataComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DashboardActvityDataComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DashboardActvityDataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
