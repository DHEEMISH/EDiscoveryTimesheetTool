import { TestBed } from '@angular/core/testing';

import { Time.SpendService } from './time.spend.service';

describe('Time.SpendService', () => {
  let service: Time.SpendService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(Time.SpendService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
