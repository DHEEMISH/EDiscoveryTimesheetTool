import { OptionType } from './../DashboardModel/Overrideuser';
import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { ActivityService } from '../Services/activity.service';
import { NgForm, FormBuilder, FormGroup, Validators, FormControl ,FormArray} from '@angular/forms';
import { FormsModule } from '@angular/forms';  
import { OverRide } from '../DashboardModel/Overrideuser';
import { LoginService } from '../Services/login.service';
import {Result} from '../LoginModel/login';
import { GlobalService } from '../Services/Globalservice';
import { PageEvent, MatPaginatorIntl, MatPaginator } from '@angular/material/paginator';
import {SelectionModel} from '@angular/cdk/collections';
import { MatTableDataSource } from '@angular/material/table';
import {MatSort} from '@angular/material/sort';

//import {MatTableDataSource} from '@angular/material/table';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit 
{

  //test=new FormControl();
  ActivityIds: string;
   ActivtyOpts: any = []; 
  OverrideOpts: any = [];
  errorMessage:string; 
  ActivityFilter:boolean=false;
  OverrideFilter:boolean=false;
   loginusername : string;
  name: string;
   number;
  weight: number;
  symbol: string;
  
  //displayedColumns: string[] = ['position', 'name', 'weight', 'symbol','symbol','symbol','symbol','symbol','symbol','symbol','symbol','symbol','symbol','symbol','symbol','symbol'];
displayedColumns: string[] = ['position', 'name', 'weight', 'symbol'];
  
  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: true}) sort: MatSort;
  form: FormGroup;
  optionClass: OptionType;

 



   // MatPaginator Inputs
  //  length = 100;
  //  pageSize = 10;
  //  pageSizeOptions: number[] = [5, 10, 25, 100];

  
  constructor(private actservice:ActivityService,private formBuilder: FormBuilder) 
  {
    // this.form = this.formBuilder.group({
    //   orders: []
    // });
}


  ELEMENT_DATA = [
  {  name: 'Hydrogen', weight: 1.0079, symbol: 'H'},
  {  name: 'Hydrogen', weight: 1.0079, symbol: 'H'},
    {  name: 'Hydrogen', weight: 1.0079, symbol: 'H'},
  {  name: 'Helium', weight: 4.0026, symbol: 'He'},
  {  name: 'Lithium', weight: 6.941, symbol: 'Li'},
  {  name: 'Beryllium', weight: 9.0122, symbol: 'Be'},
  { name: 'Boron', weight: 10.811, symbol: 'B'},
  {  name: 'Carbon', weight: 12.0107, symbol: 'C'},
  {  name: 'Nitrogen', weight: 14.0067, symbol: 'N'},
  {  name: 'Oxygen', weight: 15.9994, symbol: 'O'},
  {  name: 'Fluorine', weight: 18.9984, symbol: 'F'},
  { name: 'Neon', weight: 20.1797, symbol: 'Ne'},
  {  name: 'Hydrogen', weight: 1.0079, symbol: 'H'},
  {  name: 'Helium', weight: 4.0026, symbol: 'He'},
  {  name: 'Lithium', weight: 6.941, symbol: 'Li'},
  {  name: 'Beryllium', weight: 9.0122, symbol: 'Be'},
  {  name: 'Boron', weight: 10.811, symbol: 'B'},
  {  name: 'Carbon', weight: 12.0107, symbol: 'C'},
  {  name: 'Nitrogen', weight: 14.0067, symbol: 'N'},
  {  name: 'Oxygen', weight: 15.9994, symbol: 'O'},
  {  name: 'Fluorine', weight: 18.9984, symbol: 'F'},
  {  name: 'Neon', weight: 20.1797, symbol: 'Ne'}
];
  
dataSource = new MatTableDataSource(this.ELEMENT_DATA);


ngOnInit()
{

  this.dataSource.sort = this.sort;
  this.dataSource.paginator = this.paginator;
 this.actservice.getDashboardData().subscribe(data=>{
 let DashBoardData:OverRide=JSON.parse(data)
   this.getDashboarddetails(DashBoardData.ActivityId);
   this.getoverrideuser(DashBoardData.OverRideUser);  
   console.log(data);
   console.log(DashBoardData);
 
 });
 this.optionClass= {
   feildName: 'Monthly',
   optionArray: ['Jan','Feb','March']
 }

}


getDashboarddetails(ActvityDashBoardDetails)
{
 this.ActivtyOpts=ActvityDashBoardDetails;
console.log(ActvityDashBoardDetails)
}

activityFilterChanged()
{
this.actservice.getactivitydata(this.ActivityFilter).subscribe(data=>{
this.ActivtyOpts=JSON.parse(data)
})
}



getoverrideuser(OverrideDetails)
{
(this.OverrideOpts=OverrideDetails) 
console.log(OverrideDetails)
}







}