import { OptionType } from './../../DashboardModel/Overrideuser';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard-input-details',
  templateUrl: './dashboard-input-details.component.html',
  styleUrls: ['./dashboard-input-details.component.css']
})
export class DashboardInputDetailsComponent implements OnInit {
overrideuser : OptionType;
  constructor() { }

  ngOnInit() 
  {
    this.overrideuser ={
      feildName: 'Users',
      optionArray: ['Roger Marquez','Craig Hines','Stanley Batey']
    };
  }

}
