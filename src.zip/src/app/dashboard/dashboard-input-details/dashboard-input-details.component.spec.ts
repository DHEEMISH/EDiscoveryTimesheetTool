import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DashboardInputDetailsComponent } from './dashboard-input-details.component';

describe('DashboardInputDetailsComponent', () => {
  let component: DashboardInputDetailsComponent;
  let fixture: ComponentFixture<DashboardInputDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DashboardInputDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DashboardInputDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
