import { Component, OnInit, SecurityContext, ViewChild, ElementRef, Input } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from '../Services/login.service';
import { FormsModule } from '@angular/forms';
import { Result } from '../LoginModel/login';
import { NgForm, FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  errorMessage: string;
  userDetail: Result = {} as Result;
  Username:  any  =  [];
  @ViewChild('f') form: ElementRef;
  @Input() loginusername: any  =  [];
  loginForm: FormGroup;
  message: string;
  returnUrl: string;
  userdomainname: string;
  constructor(private router: Router, private LoginService: LoginService) {


  }
  ngOnInit() {
    //this.userLogin();

  }
  userLogin() {
    let form: FormData = new FormData(this.form.nativeElement)
    this.LoginService.GetLoginUserName(form).subscribe(
      data => {                                      

        if (JSON.parse(data).message) {

          this.errorMessage = JSON.parse(data).message;
        }
        else {
          this.router.navigate(['/dashboard']);
        }
      },
      error => {
        this.errorMessage = error.message;
      });
  };



}
