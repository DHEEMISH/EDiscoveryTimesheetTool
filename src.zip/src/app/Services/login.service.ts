import { Injectable,EventEmitter } from '@angular/core';  
import {HttpClient} from '@angular/common/http';  
import {HttpHeaders} from '@angular/common/http'; 
//import {login} from './LoginModel/login' 
import { from, Observable, observable } from 'rxjs';  

import { Result } from '../LoginModel/login';
import { GlobalService } from '../Services/Globalservice';
@Injectable({  
  providedIn: 'root'  
})  
export class LoginService {  
  Url :string;  
  userdata : string;
  //token : string;  
  header : any;  
  Selecteduser : string;
  constructor(private http : HttpClient,private globalService:GlobalService) {   
    this.Url = ' http://localhost:51523/Api/Login/UserLogin';  


    
  }  
  Login(userDetail)
  {  
     //var a =this.Url+'UserLogin';  
   return this.http.post<any>(this.Url,userDetail);
  }


  GetLoginUserName(LoginName) 
  {
      let Username: any;
     
      if (Username = sessionStorage.getItem(this.Url)) 
      {
       
          return new Observable<string>(observer => {
          observer.next(JSON.parse(Username));
        });
       
      } 
      else 
      {
        return new  Observable<string>(observer=>{ 
     this.Login(LoginName).subscribe(data=>{
          let Loginusername : Result=JSON.parse(data)
        sessionStorage.setItem('User',JSON.stringify(Loginusername));
        this.globalService.emitSessionEvent(Loginusername);
        observer.next(JSON.stringify(Loginusername));
     });
    });      
        
      }
  }
  


  
};

  

  


