import { Injectable } from '@angular/core';
import { TimespendHours } from '../ActivityModel/TimespendHours';

import { Observable } from 'rxjs';
import { HttpHeaders, HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class TimespendService {
timespendhoursURL: string;
  constructor(private http : HttpClient)
   {   
    
    this.timespendhoursURL = ' http://localhost:51523/activity/Addrecord'; 
  } 


  Insertimespend(timespendhours: TimespendHours): Observable<TimespendHours> {  
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json'}) };
   
    return this.http.post<TimespendHours>(this.timespendhoursURL + '/Addrecord/',  
    timespendhours, httpOptions);  
  }
  
}
