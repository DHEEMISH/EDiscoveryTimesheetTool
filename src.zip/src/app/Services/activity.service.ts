import { Injectable } from '@angular/core';  
import {HttpClient, HttpParams} from '@angular/common/http';  
import {HttpHeaders} from '@angular/common/http'; 
//import {login} from './LoginModel/login' 
import { from, Observable } from 'rxjs';  
import { Result } from '../LoginModel/login';
@Injectable({  
  providedIn: 'root'  
})  
export class ActivityService {  
 dashBoardUrl :string;
 activityURL:string
  userdata : string;

  //token : string;  
  header : any;  
  constructor(private http : HttpClient)
   {   
    this.dashBoardUrl = ' http://localhost:51523/activity/LoadDashboardDetails';  
    this.activityURL = ' http://localhost:51523/activity/LoadActivityId'; 
  }  


  getDashboardData(overridedata?: boolean)
  {
    return this.http.get<any>(this.dashBoardUrl)
    //+"?overridefilter="+overridedata.toString());  
  }


  getactivitydata(activitydetails?:boolean)
  {
    activitydetails=activitydetails || false;
    //return this.http.get<any>(this.activityURL);
    return this.http.get<any>(this.activityURL+"?activityfilter="+activitydetails.toString()); 
  }
   

 

}