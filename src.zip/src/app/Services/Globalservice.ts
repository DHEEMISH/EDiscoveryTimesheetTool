import { Injectable,EventEmitter } from '@angular/core';  
import {HttpClient, HttpParams} from '@angular/common/http';  
import {HttpHeaders} from '@angular/common/http'; 
//import {login} from './LoginModel/login' 
import { from, Observable } from 'rxjs';  
import { LoginService } from './login.service';

import { Result } from '../LoginModel/login';
@Injectable({  
  providedIn: 'root'  
})  
export class GlobalService {  

    SessionDataReceivedEvent= new EventEmitter<Result>();
  constructor()
   {   

  }  


 
  emitSessionEvent(result : Result)
  {
    // this.userdata.push(result);
      this.SessionDataReceivedEvent.emit(result);
  }
}