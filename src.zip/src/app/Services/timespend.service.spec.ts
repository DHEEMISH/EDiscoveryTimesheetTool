import { TestBed } from '@angular/core/testing';

import { TimespendService } from './timespend.service';

describe('TimespendService', () => {
  let service: TimespendService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(TimespendService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
