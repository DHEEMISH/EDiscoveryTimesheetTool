import { Component } from '@angular/core';
import { GlobalService } from './Services/Globalservice';
import { Result } from './LoginModel/login';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
  
})
export class AppComponent {
  username="";
  email="";
  displayname="";
  Role ="";
  EventSessionusers : any = [];
  constructor(private globalService:GlobalService)
  {

  }
  ngOnInit()
  {
 
  }
  title = 'EDiscoveryTimeSheet';
}